package dev.alexroper.chunkoptimizer.legacy.hook;

import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionChecker;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionResult;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Iterator;

public final class LegacyWorldGuardProtectionHook implements ProtectionChecker {
    private final OptimizerLogger logger;
    private boolean warnedFailure;

    public LegacyWorldGuardProtectionHook(OptimizerLogger logger) {
        this.logger = logger;
    }

    @Override
    public String getName() {
        return "worldguard";
    }

    @Override
    public ProtectionResult check(ChunkKey key) {
        Plugin worldGuard = Bukkit.getPluginManager().getPlugin("WorldGuard");
        if (worldGuard == null || !worldGuard.isEnabled()) {
            return ProtectionResult.unprotected();
        }

        World world = Bukkit.getWorld(key.getWorld());
        if (world == null) {
            return ProtectionResult.protectedChunk("WorldGuard world unavailable");
        }

        try {
            Boolean modern = checkWorldGuard7(world, key);
            if (modern != null) {
                return modern ? ProtectionResult.protectedChunk("WorldGuard region") : ProtectionResult.unprotected();
            }

            Boolean legacy = checkWorldGuard6(worldGuard, world, key);
            if (legacy != null) {
                return legacy ? ProtectionResult.protectedChunk("WorldGuard region") : ProtectionResult.unprotected();
            }
        } catch (Throwable throwable) {
            warnOnce("WorldGuard protection lookup failed. All scanned chunks will be treated as protected until the hook works.", throwable);
            return ProtectionResult.unknown("WorldGuard hook failed");
        }

        warnOnce("Unsupported WorldGuard API detected. All scanned chunks will be treated as protected.", null);
        return ProtectionResult.unknown("WorldGuard hook unavailable");
    }

    private Boolean checkWorldGuard7(World world, ChunkKey key) throws Exception {
        Class<?> worldGuardClass;
        try {
            worldGuardClass = Class.forName("com.sk89q.worldguard.WorldGuard");
        } catch (ClassNotFoundException ignored) {
            return null;
        }

        Object worldGuard = worldGuardClass.getMethod("getInstance").invoke(null);
        Object platform = worldGuardClass.getMethod("getPlatform").invoke(worldGuard);
        Object container = platform.getClass().getMethod("getRegionContainer").invoke(platform);
        Class<?> bukkitAdapterClass = Class.forName("com.sk89q.worldedit.bukkit.BukkitAdapter");
        Object adaptedWorld = bukkitAdapterClass.getMethod("adapt", World.class).invoke(null, world);
        Class<?> worldEditWorldClass = Class.forName("com.sk89q.worldedit.world.World");
        Object regionManager = container.getClass().getMethod("get", worldEditWorldClass).invoke(container, adaptedWorld);
        if (regionManager == null) {
            return false;
        }

        Class<?> vectorClass = Class.forName("com.sk89q.worldedit.math.BlockVector3");
        Object min = createStaticVector(vectorClass, minBlockX(key), 0, minBlockZ(key));
        Object max = createStaticVector(vectorClass, maxBlockX(key), Math.max(0, world.getMaxHeight() - 1), maxBlockZ(key));
        Class<?> protectedRegionClass = Class.forName("com.sk89q.worldguard.protection.regions.ProtectedRegion");
        Class<?> cuboidClass = Class.forName("com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion");
        Constructor<?> constructor = cuboidClass.getConstructor(String.class, vectorClass, vectorClass);
        Object probe = constructor.newInstance("__chunkoptimizer_probe", min, max);
        return hasApplicableRegions(regionManager, protectedRegionClass, probe);
    }

    private Boolean checkWorldGuard6(Plugin worldGuard, World world, ChunkKey key) throws Exception {
        Class<?> pluginClass;
        try {
            pluginClass = Class.forName("com.sk89q.worldguard.bukkit.WorldGuardPlugin");
        } catch (ClassNotFoundException ignored) {
            return null;
        }
        if (!pluginClass.isInstance(worldGuard)) {
            return null;
        }

        Object regionManager = pluginClass.getMethod("getRegionManager", World.class).invoke(worldGuard, world);
        if (regionManager == null) {
            return false;
        }

        Class<?> vectorClass = Class.forName("com.sk89q.worldedit.BlockVector");
        Object min = createConstructedVector(vectorClass, minBlockX(key), 0, minBlockZ(key));
        Object max = createConstructedVector(vectorClass, maxBlockX(key), Math.max(0, world.getMaxHeight() - 1), maxBlockZ(key));
        Class<?> protectedRegionClass = Class.forName("com.sk89q.worldguard.protection.regions.ProtectedRegion");
        Class<?> cuboidClass = Class.forName("com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion");
        Constructor<?> constructor = cuboidClass.getConstructor(String.class, vectorClass, vectorClass);
        Object probe = constructor.newInstance("__chunkoptimizer_probe", min, max);
        return hasApplicableRegions(regionManager, protectedRegionClass, probe);
    }

    private boolean hasApplicableRegions(Object regionManager, Class<?> protectedRegionClass, Object probe) throws Exception {
        Object applicableRegions = regionManager.getClass()
                .getMethod("getApplicableRegions", protectedRegionClass)
                .invoke(regionManager, probe);
        if (applicableRegions == null) {
            return false;
        }

        try {
            Object size = applicableRegions.getClass().getMethod("size").invoke(applicableRegions);
            if (size instanceof Number) {
                return ((Number) size).intValue() > 0;
            }
        } catch (NoSuchMethodException ignored) {
            // Older WorldGuard sets are commonly iterable instead of sized.
        }

        if (applicableRegions instanceof Iterable) {
            Iterator<?> iterator = ((Iterable<?>) applicableRegions).iterator();
            return iterator.hasNext();
        }
        return false;
    }

    private Object createStaticVector(Class<?> vectorClass, int x, int y, int z) throws Exception {
        for (Method method : vectorClass.getMethods()) {
            if (Modifier.isStatic(method.getModifiers())
                    && "at".equals(method.getName())
                    && method.getParameterTypes().length == 3) {
                return method.invoke(null, convert(method.getParameterTypes()[0], x), convert(method.getParameterTypes()[1], y), convert(method.getParameterTypes()[2], z));
            }
        }
        throw new NoSuchMethodException("No compatible BlockVector3.at method");
    }

    private Object createConstructedVector(Class<?> vectorClass, int x, int y, int z) throws Exception {
        for (Constructor<?> constructor : vectorClass.getConstructors()) {
            if (constructor.getParameterTypes().length == 3) {
                Class<?>[] types = constructor.getParameterTypes();
                return constructor.newInstance(convert(types[0], x), convert(types[1], y), convert(types[2], z));
            }
        }
        throw new NoSuchMethodException("No compatible BlockVector constructor");
    }

    private Object convert(Class<?> type, int value) {
        if (type == Integer.TYPE || type == Integer.class) {
            return Integer.valueOf(value);
        }
        if (type == Double.TYPE || type == Double.class) {
            return Double.valueOf(value);
        }
        if (type == Float.TYPE || type == Float.class) {
            return Float.valueOf(value);
        }
        if (type == Long.TYPE || type == Long.class) {
            return Long.valueOf(value);
        }
        return Integer.valueOf(value);
    }

    private int minBlockX(ChunkKey key) {
        return key.getX() << 4;
    }

    private int maxBlockX(ChunkKey key) {
        return (key.getX() << 4) + 15;
    }

    private int minBlockZ(ChunkKey key) {
        return key.getZ() << 4;
    }

    private int maxBlockZ(ChunkKey key) {
        return (key.getZ() << 4) + 15;
    }

    private void warnOnce(String message, Throwable throwable) {
        if (warnedFailure) {
            return;
        }
        warnedFailure = true;
        if (throwable == null) {
            logger.warn(message);
        } else {
            logger.warn(message, throwable);
        }
    }
}
