package dev.alexroper.chunkoptimizer.legacy.adapter;

import dev.alexroper.chunkoptimizer.core.scheduler.ScheduledTaskHandle;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

public final class LegacySchedulerAdapter implements SchedulerAdapter {
    private static final long MILLIS_PER_TICK = 50L;

    private final JavaPlugin plugin;

    public LegacySchedulerAdapter(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void runAsync(Runnable runnable) {
        Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
    }

    @Override
    public void runSync(Runnable runnable) {
        if (Bukkit.isPrimaryThread()) {
            runnable.run();
            return;
        }
        Bukkit.getScheduler().runTask(plugin, runnable);
    }

    @Override
    public boolean isPrimaryThread() {
        return Bukkit.isPrimaryThread();
    }

    @Override
    public ScheduledTaskHandle runRepeatingAsync(Runnable runnable, long initialDelayMillis, long periodMillis) {
        long initialDelayTicks = Math.max(1L, initialDelayMillis / MILLIS_PER_TICK);
        long periodTicks = Math.max(1L, periodMillis / MILLIS_PER_TICK);
        BukkitTask task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, runnable, initialDelayTicks, periodTicks);
        return task::cancel;
    }
}
