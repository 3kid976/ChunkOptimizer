package dev.alexroper.chunkoptimizer.legacy.adapter;

import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.legacy.ChunkOptimizerLegacyPlugin;

import java.util.logging.Level;

public final class LegacyOptimizerLogger implements OptimizerLogger {
    private final ChunkOptimizerLegacyPlugin plugin;

    public LegacyOptimizerLogger(ChunkOptimizerLegacyPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void info(String message) {
        plugin.getLogger().info(message);
    }

    @Override
    public void warn(String message) {
        plugin.getLogger().warning(message);
    }

    @Override
    public void warn(String message, Throwable throwable) {
        plugin.getLogger().log(Level.WARNING, message, throwable);
    }

    @Override
    public void error(String message, Throwable throwable) {
        plugin.getLogger().log(Level.SEVERE, message, throwable);
    }

    @Override
    public void debug(String message) {
        if (plugin.isOptimizerDebugMode()) {
            plugin.getLogger().info("[debug] " + message);
        }
    }
}
