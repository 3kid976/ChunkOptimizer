package dev.alexroper.chunkoptimizer.legacy.adapter;

import dev.alexroper.chunkoptimizer.bukkit.config.BukkitConfigLoader;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import org.bukkit.plugin.java.JavaPlugin;

public final class LegacyConfigLoader {
    private LegacyConfigLoader() {
    }

    public static OptimizerConfig load(JavaPlugin plugin) {
        return BukkitConfigLoader.load(plugin);
    }
}
