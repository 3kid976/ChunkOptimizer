package dev.alexroper.chunkoptimizer.legacy.adapter;

import dev.alexroper.chunkoptimizer.core.api.ChunkAccess;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public final class LegacyChunkAccess implements ChunkAccess {
    @Override
    public boolean isWorldAvailable(String worldName) {
        return Bukkit.getWorld(worldName) != null;
    }

    @Override
    public boolean isEndWorld(String worldName) {
        World world = Bukkit.getWorld(worldName);
        return world != null && world.getEnvironment() == World.Environment.THE_END;
    }

    @Override
    public boolean isChunkLoaded(ChunkKey key) {
        World world = Bukkit.getWorld(key.getWorld());
        return world != null && world.isChunkLoaded(key.getX(), key.getZ());
    }

    @Override
    public boolean isSpawnProtected(ChunkKey key, int radiusChunks) {
        if (radiusChunks <= 0) {
            return false;
        }
        World world = Bukkit.getWorld(key.getWorld());
        if (world == null) {
            return true;
        }
        Location spawn = world.getSpawnLocation();
        int spawnChunkX = spawn.getBlockX() >> 4;
        int spawnChunkZ = spawn.getBlockZ() >> 4;
        return Math.abs(key.getX() - spawnChunkX) <= radiusChunks
                && Math.abs(key.getZ() - spawnChunkZ) <= radiusChunks;
    }

    @Override
    public int countOnlinePlayersNear(ChunkKey key, int radiusChunks) {
        if (radiusChunks <= 0) {
            return 0;
        }
        World world = Bukkit.getWorld(key.getWorld());
        if (world == null) {
            return 0;
        }
        int count = 0;
        for (Player player : world.getPlayers()) {
            Location location = player.getLocation();
            int playerChunkX = location.getBlockX() >> 4;
            int playerChunkZ = location.getBlockZ() >> 4;
            if (Math.abs(playerChunkX - key.getX()) <= radiusChunks
                    && Math.abs(playerChunkZ - key.getZ()) <= radiusChunks) {
                count++;
            }
        }
        return count;
    }

    @Override
    public double getRecentTps() {
        double tps = invokeTps(Bukkit.class, null);
        if (tps >= 0.0D) {
            return tps;
        }
        return invokeTps(Bukkit.getServer().getClass(), Bukkit.getServer());
    }

    @Override
    public Collection<String> getLoadedWorldNames() {
        List<String> names = new ArrayList<String>();
        for (World world : Bukkit.getWorlds()) {
            names.add(world.getName());
        }
        return names;
    }

    private double invokeTps(Class<?> owner, Object target) {
        try {
            Method method = owner.getMethod("getTPS");
            Object value = method.invoke(target);
            if (value instanceof double[] && ((double[]) value).length > 0) {
                return ((double[]) value)[0];
            }
        } catch (Throwable ignored) {
            // Legacy Spigot does not expose TPS through Bukkit.
        }
        return -1.0D;
    }
}
