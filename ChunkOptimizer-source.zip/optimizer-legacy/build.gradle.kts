plugins {
    java
    id("com.gradleup.shadow")
}

java {
    sourceCompatibility = JavaVersion.VERSION_1_8
    targetCompatibility = JavaVersion.VERSION_1_8
}

dependencies {
    implementation(project(":optimizer-core"))
    implementation(project(":optimizer-bukkit"))
    implementation("org.slf4j:slf4j-nop:1.7.36")
    compileOnly("org.spigotmc:spigot-api:1.12.2-R0.1-SNAPSHOT")
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(8)
    options.encoding = "UTF-8"
    options.compilerArgs.add("-Xlint:-options")
}

tasks.processResources {
    filteringCharset = "UTF-8"
    filesMatching("plugin.yml") {
        expand("version" to project.version)
    }
}

tasks.shadowJar {
    archiveFileName.set("Optimizer-Legacy.jar")
    relocate("org.slf4j", "dev.alexroper.chunkoptimizer.libs.slf4j")
    mergeServiceFiles()
}

tasks.build {
    dependsOn(tasks.shadowJar)
}
