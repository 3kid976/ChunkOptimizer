plugins {
    java
    id("com.gradleup.shadow")
}

java {
    sourceCompatibility = JavaVersion.VERSION_21
    targetCompatibility = JavaVersion.VERSION_21
}

dependencies {
    implementation(project(":optimizer-core"))
    implementation(project(":optimizer-bukkit"))
    implementation("org.xerial:sqlite-jdbc:3.46.1.3")
    implementation("org.slf4j:slf4j-nop:2.0.16")
    compileOnly("io.papermc.paper:paper-api:1.21.11-R0.1-SNAPSHOT")
}

tasks.withType<JavaCompile>().configureEach {
    options.release.set(21)
    options.encoding = "UTF-8"
}

tasks.processResources {
    filteringCharset = "UTF-8"
    filesMatching("plugin.yml") {
        expand("version" to project.version)
    }
}

tasks.shadowJar {
    archiveFileName.set("Optimizer-Modern.jar")
    relocate("org.slf4j", "dev.alexroper.chunkoptimizer.libs.slf4j")
    mergeServiceFiles()
}

tasks.build {
    dependsOn(tasks.shadowJar)
}
