package dev.alexroper.chunkoptimizer.modern.adapter;

import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.modern.ChunkOptimizerModernPlugin;

import java.util.logging.Level;

public final class ModernOptimizerLogger implements OptimizerLogger {
    private final ChunkOptimizerModernPlugin plugin;

    public ModernOptimizerLogger(ChunkOptimizerModernPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void info(String message) {
        plugin.getLogger().info(message);
    }

    @Override
    public void warn(String message) {
        plugin.getLogger().warning(message);
    }

    @Override
    public void warn(String message, Throwable throwable) {
        plugin.getLogger().log(Level.WARNING, message, throwable);
    }

    @Override
    public void error(String message, Throwable throwable) {
        plugin.getLogger().log(Level.SEVERE, message, throwable);
    }

    @Override
    public void debug(String message) {
        if (plugin.isOptimizerDebugMode()) {
            plugin.getLogger().info("[debug] " + message);
        }
    }
}
