package dev.alexroper.chunkoptimizer.modern.adapter;

import dev.alexroper.chunkoptimizer.core.scheduler.ScheduledTaskHandle;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;
import org.bukkit.Bukkit;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitTask;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

public final class ModernSchedulerAdapter implements SchedulerAdapter {
    private static final long MILLIS_PER_TICK = 50L;

    private final JavaPlugin plugin;

    public ModernSchedulerAdapter(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void runAsync(Runnable runnable) {
        if (!tryPaperRunNow(runnable)) {
            Bukkit.getScheduler().runTaskAsynchronously(plugin, runnable);
        }
    }

    @Override
    public void runSync(Runnable runnable) {
        if (Bukkit.isPrimaryThread()) {
            runnable.run();
            return;
        }
        Bukkit.getScheduler().runTask(plugin, runnable);
    }

    @Override
    public boolean isPrimaryThread() {
        return Bukkit.isPrimaryThread();
    }

    @Override
    public ScheduledTaskHandle runRepeatingAsync(Runnable runnable, long initialDelayMillis, long periodMillis) {
        ScheduledTaskHandle paperTask = tryPaperRepeating(runnable, initialDelayMillis, periodMillis);
        if (paperTask != null) {
            return paperTask;
        }

        long initialDelayTicks = Math.max(1L, initialDelayMillis / MILLIS_PER_TICK);
        long periodTicks = Math.max(1L, periodMillis / MILLIS_PER_TICK);
        BukkitTask task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, runnable, initialDelayTicks, periodTicks);
        return task::cancel;
    }

    private boolean tryPaperRunNow(Runnable runnable) {
        try {
            Object asyncScheduler = Bukkit.class.getMethod("getAsyncScheduler").invoke(null);
            Method runNow = asyncScheduler.getClass().getMethod("runNow", Plugin.class, Consumer.class);
            Consumer<Object> consumer = ignored -> runnable.run();
            runNow.invoke(asyncScheduler, plugin, consumer);
            return true;
        } catch (ReflectiveOperationException | LinkageError e) {
            return false;
        }
    }

    private ScheduledTaskHandle tryPaperRepeating(Runnable runnable, long initialDelayMillis, long periodMillis) {
        try {
            Object asyncScheduler = Bukkit.class.getMethod("getAsyncScheduler").invoke(null);
            Method runAtFixedRate = asyncScheduler.getClass().getMethod(
                    "runAtFixedRate",
                    Plugin.class,
                    Consumer.class,
                    Long.TYPE,
                    Long.TYPE,
                    TimeUnit.class);
            Consumer<Object> consumer = ignored -> runnable.run();
            Object scheduledTask = runAtFixedRate.invoke(
                    asyncScheduler,
                    plugin,
                    consumer,
                    Math.max(1L, initialDelayMillis),
                    Math.max(1L, periodMillis),
                    TimeUnit.MILLISECONDS);
            return () -> cancelPaperTask(scheduledTask);
        } catch (ReflectiveOperationException | LinkageError e) {
            return null;
        }
    }

    private void cancelPaperTask(Object scheduledTask) {
        if (scheduledTask == null) {
            return;
        }
        try {
            scheduledTask.getClass().getMethod("cancel").invoke(scheduledTask);
        } catch (IllegalAccessException | InvocationTargetException | NoSuchMethodException ignored) {
            // Bukkit fallback tasks are handled separately; a stale Paper task is harmless during shutdown.
        }
    }
}
