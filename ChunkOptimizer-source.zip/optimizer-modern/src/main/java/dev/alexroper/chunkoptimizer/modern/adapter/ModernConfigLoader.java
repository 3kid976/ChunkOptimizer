package dev.alexroper.chunkoptimizer.modern.adapter;

import dev.alexroper.chunkoptimizer.bukkit.config.BukkitConfigLoader;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import org.bukkit.plugin.java.JavaPlugin;

public final class ModernConfigLoader {
    private ModernConfigLoader() {
    }

    public static OptimizerConfig load(JavaPlugin plugin) {
        return BukkitConfigLoader.load(plugin);
    }
}
