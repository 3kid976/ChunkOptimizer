package dev.alexroper.chunkoptimizer.modern.hook;

import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionChecker;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionResult;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.UUID;

public final class ModernLandsProtectionHook implements ProtectionChecker {
    private static final String[] INTEGRATION_CLASSES = new String[] {
            "me.angeschossen.lands.api.LandsIntegration",
            "me.angeschossen.lands.api.integration.LandsIntegration"
    };

    private final JavaPlugin plugin;
    private final OptimizerLogger logger;
    private Object integration;
    private boolean integrationAttempted;
    private boolean warnedFailure;

    public ModernLandsProtectionHook(JavaPlugin plugin, OptimizerLogger logger) {
        this.plugin = plugin;
        this.logger = logger;
    }

    @Override
    public String getName() {
        return "lands";
    }

    @Override
    public ProtectionResult check(ChunkKey key) {
        Plugin lands = Bukkit.getPluginManager().getPlugin("Lands");
        if (lands == null || !lands.isEnabled()) {
            return ProtectionResult.unprotected();
        }

        World world = Bukkit.getWorld(key.getWorld());
        if (world == null) {
            return ProtectionResult.protectedChunk("Lands world unavailable");
        }

        try {
            Object landsIntegration = getIntegration();
            if (landsIntegration == null) {
                warnOnce("Unsupported Lands API detected. All scanned chunks will be treated as protected.", null);
                return ProtectionResult.unknown("Lands hook unavailable");
            }
            Boolean claimed = inspectKnownMethods(landsIntegration, world, key);
            if (claimed == null) {
                warnOnce("No compatible Lands claim lookup method was found. All scanned chunks will be treated as protected.", null);
                return ProtectionResult.unknown("Lands hook unavailable");
            }
            return claimed ? ProtectionResult.protectedChunk("Lands claim") : ProtectionResult.unprotected();
        } catch (Throwable throwable) {
            warnOnce("Lands protection lookup failed. All scanned chunks will be treated as protected until the hook works.", throwable);
            return ProtectionResult.unknown("Lands hook failed");
        }
    }

    private Object getIntegration() throws Exception {
        if (integrationAttempted) {
            return integration;
        }
        integrationAttempted = true;

        for (String className : INTEGRATION_CLASSES) {
            Class<?> integrationClass;
            try {
                integrationClass = Class.forName(className);
            } catch (ClassNotFoundException ignored) {
                continue;
            }

            for (Method method : integrationClass.getMethods()) {
                if (Modifier.isStatic(method.getModifiers())
                        && ("of".equals(method.getName()) || "get".equals(method.getName()))
                        && method.getParameterTypes().length == 1
                        && method.getParameterTypes()[0].isAssignableFrom(JavaPlugin.class)) {
                    integration = method.invoke(null, plugin);
                    return integration;
                }
            }
        }
        return null;
    }

    private Boolean inspectKnownMethods(Object landsIntegration, World world, ChunkKey key) throws Exception {
        Location center = new Location(world, (key.getX() << 4) + 8.0D, Math.max(64.0D, world.getMinHeight()), (key.getZ() << 4) + 8.0D);
        LookupResult result = invokeLocationLookup(landsIntegration, "getUnloadedArea", center);
        if (result.isChecked()) {
            return Boolean.valueOf(result.isClaimed());
        }

        result = invokeLocationLookup(landsIntegration, "getAreaUnloaded", center);
        if (result.isChecked()) {
            return Boolean.valueOf(result.isClaimed());
        }

        result = invokeChunkLookup(landsIntegration, "getLandByUnloadedChunk", world, key);
        if (result.isChecked()) {
            return Boolean.valueOf(result.isClaimed());
        }

        if (!world.isChunkLoaded(key.getX(), key.getZ())) {
            return null;
        }

        result = invokeLocationLookup(landsIntegration, "getArea", center);
        if (result.isChecked()) {
            return Boolean.valueOf(result.isClaimed());
        }

        result = invokeChunkLookup(landsIntegration, "getLandByChunk", world, key);
        if (result.isChecked()) {
            return Boolean.valueOf(result.isClaimed());
        }

        return null;
    }

    private LookupResult invokeLocationLookup(Object landsIntegration, String methodName, Location location) throws Exception {
        for (Method method : landsIntegration.getClass().getMethods()) {
            if (!methodName.equals(method.getName())) {
                continue;
            }

            Class<?>[] types = method.getParameterTypes();
            if (types.length == 1 && types[0].isAssignableFrom(Location.class)) {
                return LookupResult.checked(method.invoke(landsIntegration, location));
            }
        }
        return LookupResult.unchecked();
    }

    private LookupResult invokeChunkLookup(Object landsIntegration, String methodName, World world, ChunkKey key) throws Exception {
        for (Method method : landsIntegration.getClass().getMethods()) {
            if (!methodName.equals(method.getName())) {
                continue;
            }

            Class<?>[] types = method.getParameterTypes();
            if (types.length == 3 && types[0].isAssignableFrom(World.class) && isInteger(types[1]) && isInteger(types[2])) {
                return LookupResult.checked(method.invoke(landsIntegration, world, Integer.valueOf(key.getX()), Integer.valueOf(key.getZ())));
            }
            if (types.length == 3 && types[0].isAssignableFrom(UUID.class) && isInteger(types[1]) && isInteger(types[2])) {
                return LookupResult.checked(method.invoke(landsIntegration, world.getUID(), Integer.valueOf(key.getX()), Integer.valueOf(key.getZ())));
            }
        }
        return LookupResult.unchecked();
    }

    private boolean isInteger(Class<?> type) {
        return type == Integer.TYPE || type == Integer.class;
    }

    private void warnOnce(String message, Throwable throwable) {
        if (warnedFailure) {
            return;
        }
        warnedFailure = true;
        if (throwable == null) {
            logger.warn(message);
        } else {
            logger.warn(message, throwable);
        }
    }

    private static final class LookupResult {
        private final boolean checked;
        private final boolean claimed;

        private LookupResult(boolean checked, boolean claimed) {
            this.checked = checked;
            this.claimed = claimed;
        }

        private static LookupResult checked(Object result) {
            if (result instanceof Boolean) {
                return new LookupResult(true, ((Boolean) result).booleanValue());
            }
            return new LookupResult(true, result != null);
        }

        private static LookupResult unchecked() {
            return new LookupResult(false, false);
        }

        private boolean isChecked() {
            return checked;
        }

        private boolean isClaimed() {
            return claimed;
        }
    }
}
