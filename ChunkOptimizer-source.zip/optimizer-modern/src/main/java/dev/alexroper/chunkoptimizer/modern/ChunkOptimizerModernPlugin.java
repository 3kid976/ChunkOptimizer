package dev.alexroper.chunkoptimizer.modern;

import dev.alexroper.chunkoptimizer.bukkit.BukkitOptimizerPlugin;
import dev.alexroper.chunkoptimizer.bukkit.command.BukkitOptimizerCommand;
import dev.alexroper.chunkoptimizer.bukkit.deletion.StorageChunkDeletionAdapter;
import dev.alexroper.chunkoptimizer.bukkit.gui.OptimizerGuiManager;
import dev.alexroper.chunkoptimizer.core.api.ChunkAccess;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;
import dev.alexroper.chunkoptimizer.core.persistence.SQLiteOptimizerStorage;
import dev.alexroper.chunkoptimizer.core.protection.EndIslandProtectionChecker;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionChecker;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionService;
import dev.alexroper.chunkoptimizer.core.queue.ChunkQueueService;
import dev.alexroper.chunkoptimizer.core.scanner.ChunkScanner;
import dev.alexroper.chunkoptimizer.core.service.ActivityTracker;
import dev.alexroper.chunkoptimizer.core.service.ChunkDeletionService;
import dev.alexroper.chunkoptimizer.core.service.ChunkManagementService;
import dev.alexroper.chunkoptimizer.core.service.ChunkOptimizerEngine;
import dev.alexroper.chunkoptimizer.core.service.ChunkSafetyService;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;
import dev.alexroper.chunkoptimizer.modern.adapter.ModernChunkAccess;
import dev.alexroper.chunkoptimizer.modern.adapter.ModernConfigLoader;
import dev.alexroper.chunkoptimizer.modern.adapter.ModernOptimizerLogger;
import dev.alexroper.chunkoptimizer.modern.adapter.ModernSchedulerAdapter;
import dev.alexroper.chunkoptimizer.modern.hook.ModernLandsProtectionHook;
import dev.alexroper.chunkoptimizer.modern.hook.ModernWorldGuardProtectionHook;
import dev.alexroper.chunkoptimizer.modern.listener.ModernPlayerActivityListener;
import org.bukkit.Location;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;

public final class ChunkOptimizerModernPlugin extends JavaPlugin implements BukkitOptimizerPlugin {
    private OptimizerConfig optimizerConfig;
    private OptimizerStorage storage;
    private ChunkOptimizerEngine engine;
    private ChunkDeletionService deletionService;
    private ChunkManagementService managementService;
    private ChunkSafetyService safetyService;
    private SchedulerAdapter scheduler;
    private OptimizerLogger optimizerLogger;
    private OptimizerGuiManager guiManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        scheduler = new ModernSchedulerAdapter(this);
        optimizerLogger = new ModernOptimizerLogger(this);
        guiManager = new OptimizerGuiManager(this);

        try {
            rebuildRuntime(true);
            registerListeners();
            registerCommand();
            recordOnlinePlayers();
            getLogger().info("ChunkOptimizer modern build enabled.");
        } catch (RuntimeException e) {
            getLogger().log(Level.SEVERE, "Failed to enable ChunkOptimizer.", e);
            getServer().getPluginManager().disablePlugin(this);
        }
    }

    @Override
    public void onDisable() {
        stopRuntime();
        closeStorage();
    }

    public synchronized void reloadOptimizer() {
        reloadConfig();
        rebuildRuntime(true);
        recordOnlinePlayers();
    }

    private synchronized void rebuildRuntime(boolean rebuildStorage) {
        stopRuntime();
        optimizerConfig = ModernConfigLoader.load(this);
        if (rebuildStorage) {
            closeStorage();
            storage = new SQLiteOptimizerStorage(new File(getDataFolder(), optimizerConfig.getDatabaseFileName()));
            storage.initialize();
            storage.setMetadata("artifact", "modern", System.currentTimeMillis());
        }

        ChunkAccess chunkAccess = new ModernChunkAccess();
        ActivityTracker activityTracker = new ActivityTracker(storage, optimizerConfig, optimizerLogger);
        ChunkQueueService queueService = new ChunkQueueService(storage, optimizerLogger);
        List<ProtectionChecker> checkers = new ArrayList<ProtectionChecker>();
        checkers.add(new EndIslandProtectionChecker(chunkAccess, optimizerConfig));
        if (optimizerConfig.isWorldGuardEnabled()) {
            checkers.add(new ModernWorldGuardProtectionHook(optimizerLogger));
        }
        if (optimizerConfig.isLandsEnabled()) {
            checkers.add(new ModernLandsProtectionHook(this, optimizerLogger));
        }

        ProtectionService protectionService = new ProtectionService(checkers, optimizerConfig, optimizerLogger);
        safetyService = new ChunkSafetyService(optimizerConfig, storage, chunkAccess, protectionService, scheduler);
        deletionService = new ChunkDeletionService(
                optimizerConfig,
                storage,
                safetyService,
                new StorageChunkDeletionAdapter(scheduler, optimizerLogger),
                scheduler,
                optimizerLogger);
        managementService = new ChunkManagementService(storage, optimizerLogger);
        ChunkScanner scanner = new ChunkScanner(optimizerConfig, storage, activityTracker, safetyService, queueService, scheduler, optimizerLogger);
        engine = new ChunkOptimizerEngine(optimizerConfig, storage, activityTracker, scanner, scheduler, optimizerLogger, deletionService);
        engine.start();
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new ModernPlayerActivityListener(this), this);
        getServer().getPluginManager().registerEvents(guiManager, this);
    }

    private void registerCommand() {
        PluginCommand command = getCommand("optimizer");
        if (command == null) {
            throw new IllegalStateException("optimizer command is missing from plugin.yml");
        }
        BukkitOptimizerCommand executor = new BukkitOptimizerCommand(this, guiManager);
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    private void recordOnlinePlayers() {
        for (Player player : getServer().getOnlinePlayers()) {
            recordVisit(player);
        }
    }

    private synchronized void stopRuntime() {
        if (engine != null) {
            engine.stop();
            engine = null;
        }
    }

    private synchronized void closeStorage() {
        if (storage != null) {
            storage.close();
            storage = null;
        }
    }

    public void recordVisit(Player player) {
        recordVisit(player, player.getLocation());
    }

    public void recordVisit(Player player, Location location) {
        ChunkOptimizerEngine currentEngine = engine;
        if (currentEngine == null || location == null || location.getWorld() == null) {
            return;
        }
        currentEngine.recordVisit(new ChunkKey(location.getWorld().getName(), location.getBlockX() >> 4, location.getBlockZ() >> 4));
    }

    public void runAsync(Runnable runnable) {
        scheduler.runAsync(runnable);
    }

    public void runSync(Runnable runnable) {
        scheduler.runSync(runnable);
    }

    public ChunkOptimizerEngine getEngine() {
        return engine;
    }

    @Override
    public JavaPlugin getJavaPlugin() {
        return this;
    }

    @Override
    public OptimizerConfig getOptimizerConfig() {
        return optimizerConfig;
    }

    @Override
    public OptimizerStorage getStorage() {
        return storage;
    }

    @Override
    public ChunkDeletionService getDeletionService() {
        return deletionService;
    }

    @Override
    public ChunkSafetyService getSafetyService() {
        return safetyService;
    }

    @Override
    public ChunkManagementService getManagementService() {
        return managementService;
    }

    @Override
    public OptimizerLogger getOptimizerLogger() {
        return optimizerLogger;
    }

    public boolean isOptimizerDebugMode() {
        return optimizerConfig != null && optimizerConfig.isDebugMode();
    }
}
