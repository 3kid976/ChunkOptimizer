plugins {
    id("com.gradleup.shadow") version "8.3.6" apply false
}

group = "dev.alexroper"
version = "1.0.0"

subprojects {
    group = rootProject.group
    version = rootProject.version
}

tasks.register<Copy>("releaseArtifacts") {
    dependsOn(":optimizer-legacy:shadowJar", ":optimizer-modern:shadowJar")
    from(project(":optimizer-legacy").layout.buildDirectory.file("libs/Optimizer-Legacy.jar"))
    from(project(":optimizer-modern").layout.buildDirectory.file("libs/Optimizer-Modern.jar"))
    into(layout.buildDirectory.dir("release"))
}

tasks.register("releaseBuild") {
    dependsOn(":optimizer-core:build", ":optimizer-bukkit:build", ":optimizer-legacy:build", ":optimizer-modern:build", "releaseArtifacts")
}
