package dev.alexroper.chunkoptimizer.core.model;

public final class QueuedChunk {
    private final ChunkKey key;
    private final long queuedAt;
    private final long inactiveSince;
    private final QueueState state;
    private final String reason;
    private final long processedAt;
    private final String error;

    public QueuedChunk(
            ChunkKey key,
            long queuedAt,
            long inactiveSince,
            QueueState state,
            String reason,
            long processedAt,
            String error) {
        this.key = key;
        this.queuedAt = queuedAt;
        this.inactiveSince = inactiveSince;
        this.state = state;
        this.reason = reason;
        this.processedAt = processedAt;
        this.error = error;
    }

    public ChunkKey getKey() {
        return key;
    }

    public long getQueuedAt() {
        return queuedAt;
    }

    public long getInactiveSince() {
        return inactiveSince;
    }

    public QueueState getState() {
        return state;
    }

    public String getReason() {
        return reason;
    }

    public long getProcessedAt() {
        return processedAt;
    }

    public String getError() {
        return error;
    }
}
