package dev.alexroper.chunkoptimizer.core.persistence;

import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.DeletionAuditRecord;
import dev.alexroper.chunkoptimizer.core.model.InactiveChunk;
import dev.alexroper.chunkoptimizer.core.model.OptimizerStats;
import dev.alexroper.chunkoptimizer.core.model.PendingVisit;
import dev.alexroper.chunkoptimizer.core.model.QueueStats;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import dev.alexroper.chunkoptimizer.core.model.QueueState;
import dev.alexroper.chunkoptimizer.core.model.WhitelistedChunk;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

public final class SQLiteOptimizerStorage implements OptimizerStorage {
    private static final String SCHEMA_VERSION = "2";

    private final File databaseFile;
    private Connection connection;

    public SQLiteOptimizerStorage(File databaseFile) {
        this.databaseFile = databaseFile;
    }

    @Override
    public synchronized void initialize() {
        try {
            File parent = databaseFile.getParentFile();
            if (parent != null && !parent.exists() && !parent.mkdirs()) {
                throw new SQLException("Could not create database directory: " + parent.getAbsolutePath());
            }
            connection = openConnection();
            configureConnection();
            createSchema();
            migrateSchema();
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to initialize SQLite storage", e);
        } catch (ClassNotFoundException e) {
            throw new OptimizerStorageException("SQLite JDBC driver was not found", e);
        }
    }

    private Connection openConnection() throws SQLException, ClassNotFoundException {
        String url = "jdbc:sqlite:" + databaseFile.getAbsolutePath();
        Class.forName("org.sqlite.JDBC");
        return DriverManager.getConnection(url);
    }

    private void configureConnection() throws SQLException {
        Statement statement = connection.createStatement();
        try {
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("PRAGMA busy_timeout=5000");
            statement.execute("PRAGMA foreign_keys=ON");
        } finally {
            statement.close();
        }
    }

    private void createSchema() throws SQLException {
        Statement statement = connection.createStatement();
        try {
            statement.execute("CREATE TABLE IF NOT EXISTS tracked_chunks (" +
                    "world TEXT NOT NULL, " +
                    "x INTEGER NOT NULL, " +
                    "z INTEGER NOT NULL, " +
                    "first_seen_at INTEGER NOT NULL, " +
                    "last_visited_at INTEGER NOT NULL, " +
                    "updated_at INTEGER NOT NULL, " +
                    "visit_count INTEGER NOT NULL DEFAULT 1, " +
                    "PRIMARY KEY(world, x, z))");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_tracked_chunks_last_visit ON tracked_chunks(world, last_visited_at)");

            statement.execute("CREATE TABLE IF NOT EXISTS queued_chunks (" +
                    "world TEXT NOT NULL, " +
                    "x INTEGER NOT NULL, " +
                    "z INTEGER NOT NULL, " +
                    "queued_at INTEGER NOT NULL, " +
                    "inactive_since INTEGER NOT NULL, " +
                    "state TEXT NOT NULL, " +
                    "reason TEXT NOT NULL, " +
                    "processed_at INTEGER, " +
                    "error TEXT, " +
                    "PRIMARY KEY(world, x, z))");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_queued_chunks_state ON queued_chunks(state, queued_at)");

            statement.execute("CREATE TABLE IF NOT EXISTS whitelisted_chunks (" +
                    "world TEXT NOT NULL, " +
                    "x INTEGER NOT NULL, " +
                    "z INTEGER NOT NULL, " +
                    "created_at INTEGER NOT NULL, " +
                    "note TEXT, " +
                    "added_by TEXT, " +
                    "PRIMARY KEY(world, x, z))");
            ensureColumn(statement, "whitelisted_chunks", "added_by", "TEXT");

            statement.execute("CREATE TABLE IF NOT EXISTS metadata (" +
                    "metadata_key TEXT PRIMARY KEY, " +
                    "metadata_value TEXT NOT NULL, " +
                    "updated_at INTEGER NOT NULL)");

            statement.execute("CREATE TABLE IF NOT EXISTS schema_migrations (" +
                    "version TEXT PRIMARY KEY, " +
                    "applied_at INTEGER NOT NULL)");

            statement.execute("CREATE TABLE IF NOT EXISTS deletion_audit (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    "world TEXT NOT NULL, " +
                    "x INTEGER NOT NULL, " +
                    "z INTEGER NOT NULL, " +
                    "actor TEXT NOT NULL, " +
                    "requested_at INTEGER NOT NULL, " +
                    "completed_at INTEGER NOT NULL, " +
                    "dry_run INTEGER NOT NULL, " +
                    "success INTEGER NOT NULL, " +
                    "postponed INTEGER NOT NULL, " +
                    "message TEXT, " +
                    "rollback_data TEXT)");
            statement.execute("CREATE INDEX IF NOT EXISTS idx_deletion_audit_chunk ON deletion_audit(world, x, z, completed_at)");
        } finally {
            statement.close();
        }
    }

    private void migrateSchema() throws SQLException {
        String version = getMetadata("schema-version");
        long now = System.currentTimeMillis();
        if (version == null) {
            recordMigration("1", now);
        }
        if (!SCHEMA_VERSION.equals(version)) {
            recordMigration(SCHEMA_VERSION, now);
            setMetadata("schema-version", SCHEMA_VERSION, now);
        }
    }

    private void recordMigration(String version, long appliedAt) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(
                "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES(?, ?)");
        try {
            statement.setString(1, version);
            statement.setLong(2, appliedAt);
            statement.executeUpdate();
        } finally {
            statement.close();
        }
    }

    private void ensureColumn(Statement statement, String table, String column, String definition) throws SQLException {
        ResultSet resultSet = statement.executeQuery("PRAGMA table_info(" + table + ")");
        try {
            while (resultSet.next()) {
                if (column.equalsIgnoreCase(resultSet.getString("name"))) {
                    return;
                }
            }
        } finally {
            resultSet.close();
        }
        statement.execute("ALTER TABLE " + table + " ADD COLUMN " + column + " " + definition);
    }

    @Override
    public synchronized void recordVisits(Map<ChunkKey, PendingVisit> visits) {
        if (visits == null || visits.isEmpty()) {
            return;
        }
        ensureOpen();
        String updateSql = "UPDATE tracked_chunks SET " +
                "last_visited_at = CASE WHEN last_visited_at < ? THEN ? ELSE last_visited_at END, " +
                "updated_at = ?, " +
                "visit_count = visit_count + ? " +
                "WHERE world = ? AND x = ? AND z = ?";
        String insertSql = "INSERT INTO tracked_chunks(world, x, z, first_seen_at, last_visited_at, updated_at, visit_count) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?)";
        boolean previousAutoCommit = true;
        try {
            previousAutoCommit = connection.getAutoCommit();
            connection.setAutoCommit(false);
            PreparedStatement updateStatement = connection.prepareStatement(updateSql);
            PreparedStatement insertStatement = connection.prepareStatement(insertSql);
            PreparedStatement queueStatement = connection.prepareStatement(
                    "DELETE FROM queued_chunks WHERE world = ? AND x = ? AND z = ? AND state = ? AND queued_at < ?");
            try {
                long now = System.currentTimeMillis();
                for (Map.Entry<ChunkKey, PendingVisit> entry : visits.entrySet()) {
                    ChunkKey key = entry.getKey();
                    PendingVisit visit = entry.getValue();
                    updateStatement.setLong(1, visit.getLastVisitedAt());
                    updateStatement.setLong(2, visit.getLastVisitedAt());
                    updateStatement.setLong(3, now);
                    updateStatement.setInt(4, visit.getVisitCount());
                    updateStatement.setString(5, key.getWorld());
                    updateStatement.setInt(6, key.getX());
                    updateStatement.setInt(7, key.getZ());
                    if (updateStatement.executeUpdate() == 0) {
                        insertStatement.setString(1, key.getWorld());
                        insertStatement.setInt(2, key.getX());
                        insertStatement.setInt(3, key.getZ());
                        insertStatement.setLong(4, visit.getLastVisitedAt());
                        insertStatement.setLong(5, visit.getLastVisitedAt());
                        insertStatement.setLong(6, now);
                        insertStatement.setInt(7, visit.getVisitCount());
                        insertStatement.executeUpdate();
                    }

                    queueStatement.setString(1, key.getWorld());
                    queueStatement.setInt(2, key.getX());
                    queueStatement.setInt(3, key.getZ());
                    queueStatement.setString(4, QueueState.QUEUED.name());
                    queueStatement.setLong(5, visit.getLastVisitedAt());
                    queueStatement.addBatch();
                }
                queueStatement.executeBatch();
            } finally {
                queueStatement.close();
                insertStatement.close();
                updateStatement.close();
            }
            connection.commit();
        } catch (SQLException e) {
            rollbackQuietly();
            throw new OptimizerStorageException("Failed to persist chunk visits", e);
        } finally {
            restoreAutoCommit(previousAutoCommit);
        }
    }

    @Override
    public synchronized List<InactiveChunk> findInactiveChunks(Collection<String> enabledWorlds, long cutoffTimestamp, int limit) {
        ensureOpen();
        List<String> worlds = normalizeWorlds(enabledWorlds);
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT t.world, t.x, t.z, t.last_visited_at ");
        sql.append("FROM tracked_chunks t ");
        sql.append("LEFT JOIN queued_chunks q ON q.world = t.world AND q.x = t.x AND q.z = t.z ");
        sql.append("AND q.state IN ('").append(QueueState.QUEUED.name()).append("', '").append(QueueState.DELETING.name()).append("') ");
        sql.append("WHERE t.last_visited_at <= ? AND q.world IS NULL ");
        if (!worlds.isEmpty()) {
            sql.append("AND t.world IN (");
            for (int i = 0; i < worlds.size(); i++) {
                if (i > 0) {
                    sql.append(", ");
                }
                sql.append("?");
            }
            sql.append(") ");
        }
        sql.append("ORDER BY t.last_visited_at ASC LIMIT ?");

        try {
            PreparedStatement statement = connection.prepareStatement(sql.toString());
            try {
                int parameter = 1;
                statement.setLong(parameter++, cutoffTimestamp);
                for (String world : worlds) {
                    statement.setString(parameter++, world);
                }
                statement.setInt(parameter, Math.max(1, limit));
                ResultSet resultSet = statement.executeQuery();
                try {
                    List<InactiveChunk> chunks = new ArrayList<InactiveChunk>();
                    while (resultSet.next()) {
                        ChunkKey key = new ChunkKey(resultSet.getString("world"), resultSet.getInt("x"), resultSet.getInt("z"));
                        chunks.add(new InactiveChunk(key, resultSet.getLong("last_visited_at")));
                    }
                    return chunks;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to find inactive chunks", e);
        }
    }

    private List<String> normalizeWorlds(Collection<String> enabledWorlds) {
        List<String> worlds = new ArrayList<String>();
        if (enabledWorlds == null) {
            return worlds;
        }
        for (String world : enabledWorlds) {
            if (world != null && !world.trim().isEmpty()) {
                worlds.add(world.trim());
            }
        }
        return worlds;
    }

    @Override
    public synchronized boolean enqueueChunk(ChunkKey key, long inactiveSince, long queuedAt, String reason) {
        ensureOpen();
        QueuedChunk existing = getQueuedChunk(key);
        if (existing != null && (existing.getState() == QueueState.QUEUED || existing.getState() == QueueState.DELETING)) {
            return false;
        }

        String updateSql = "UPDATE queued_chunks SET queued_at = ?, inactive_since = ?, state = ?, reason = ?, processed_at = NULL, error = NULL " +
                "WHERE world = ? AND x = ? AND z = ?";
        String insertSql = "INSERT INTO queued_chunks(world, x, z, queued_at, inactive_since, state, reason, processed_at, error) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?, NULL, NULL)";
        try {
            PreparedStatement updateStatement = connection.prepareStatement(updateSql);
            PreparedStatement insertStatement = connection.prepareStatement(insertSql);
            try {
                String cleanReason = reason == null ? "inactive" : reason;
                updateStatement.setLong(1, queuedAt);
                updateStatement.setLong(2, inactiveSince);
                updateStatement.setString(3, QueueState.QUEUED.name());
                updateStatement.setString(4, cleanReason);
                updateStatement.setString(5, key.getWorld());
                updateStatement.setInt(6, key.getX());
                updateStatement.setInt(7, key.getZ());
                if (updateStatement.executeUpdate() > 0) {
                    return true;
                }

                insertStatement.setString(1, key.getWorld());
                insertStatement.setInt(2, key.getX());
                insertStatement.setInt(3, key.getZ());
                insertStatement.setLong(4, queuedAt);
                insertStatement.setLong(5, inactiveSince);
                insertStatement.setString(6, QueueState.QUEUED.name());
                insertStatement.setString(7, cleanReason);
                return insertStatement.executeUpdate() > 0;
            } finally {
                insertStatement.close();
                updateStatement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to enqueue chunk " + key, e);
        }
    }

    @Override
    public synchronized boolean isQueued(ChunkKey key) {
        return exists("SELECT 1 FROM queued_chunks WHERE world = ? AND x = ? AND z = ? AND state = '" + QueueState.QUEUED.name() + "' LIMIT 1", key);
    }

    @Override
    public synchronized QueuedChunk getQueuedChunk(ChunkKey key) {
        ensureOpen();
        String sql = "SELECT world, x, z, queued_at, inactive_since, state, reason, COALESCE(processed_at, 0) AS processed_at, error " +
                "FROM queued_chunks WHERE world = ? AND x = ? AND z = ? LIMIT 1";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            try {
                bindKey(statement, key);
                ResultSet resultSet = statement.executeQuery();
                try {
                    return resultSet.next() ? readQueuedChunk(resultSet) : null;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to read queued chunk " + key, e);
        }
    }

    @Override
    public synchronized List<QueuedChunk> listQueuedChunks(Collection<String> worlds, QueueState state, int offset, int limit) {
        ensureOpen();
        List<String> normalizedWorlds = normalizeWorlds(worlds);
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT world, x, z, queued_at, inactive_since, state, reason, COALESCE(processed_at, 0) AS processed_at, error ");
        sql.append("FROM queued_chunks WHERE state = ? ");
        appendWorldFilter(sql, normalizedWorlds);
        sql.append("ORDER BY queued_at ASC LIMIT ? OFFSET ?");

        try {
            PreparedStatement statement = connection.prepareStatement(sql.toString());
            try {
                int parameter = 1;
                statement.setString(parameter++, state.name());
                parameter = bindWorlds(statement, parameter, normalizedWorlds);
                statement.setInt(parameter++, Math.max(1, limit));
                statement.setInt(parameter, Math.max(0, offset));
                ResultSet resultSet = statement.executeQuery();
                try {
                    List<QueuedChunk> chunks = new ArrayList<QueuedChunk>();
                    while (resultSet.next()) {
                        chunks.add(readQueuedChunk(resultSet));
                    }
                    return chunks;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to list queued chunks", e);
        }
    }

    @Override
    public synchronized int countQueuedChunks(Collection<String> worlds, QueueState state) {
        ensureOpen();
        List<String> normalizedWorlds = normalizeWorlds(worlds);
        StringBuilder sql = new StringBuilder();
        sql.append("SELECT COUNT(*) FROM queued_chunks WHERE state = ? ");
        appendWorldFilter(sql, normalizedWorlds);
        try {
            PreparedStatement statement = connection.prepareStatement(sql.toString());
            try {
                int parameter = 1;
                statement.setString(parameter++, state.name());
                bindWorlds(statement, parameter, normalizedWorlds);
                ResultSet resultSet = statement.executeQuery();
                try {
                    return resultSet.next() ? resultSet.getInt(1) : 0;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to count queued chunks", e);
        }
    }

    @Override
    public synchronized List<QueuedChunk> findQueuedChunksReadyForDeletion(long queuedBeforeOrAt, int limit) {
        ensureOpen();
        String sql = "SELECT world, x, z, queued_at, inactive_since, state, reason, COALESCE(processed_at, 0) AS processed_at, error " +
                "FROM queued_chunks WHERE state = ? AND queued_at <= ? ORDER BY queued_at ASC LIMIT ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            try {
                statement.setString(1, QueueState.QUEUED.name());
                statement.setLong(2, queuedBeforeOrAt);
                statement.setInt(3, Math.max(1, limit));
                ResultSet resultSet = statement.executeQuery();
                try {
                    List<QueuedChunk> chunks = new ArrayList<QueuedChunk>();
                    while (resultSet.next()) {
                        chunks.add(readQueuedChunk(resultSet));
                    }
                    return chunks;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to find queued chunks ready for deletion", e);
        }
    }

    @Override
    public synchronized void markQueueState(ChunkKey key, QueueState state, long processedAt, String error) {
        ensureOpen();
        String sql = "UPDATE queued_chunks SET state = ?, processed_at = ?, error = ? WHERE world = ? AND x = ? AND z = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            try {
                statement.setString(1, state.name());
                if (processedAt > 0L) {
                    statement.setLong(2, processedAt);
                } else {
                    statement.setNull(2, java.sql.Types.INTEGER);
                }
                statement.setString(3, error);
                statement.setString(4, key.getWorld());
                statement.setInt(5, key.getX());
                statement.setInt(6, key.getZ());
                statement.executeUpdate();
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to mark queue state for " + key, e);
        }
    }

    @Override
    public synchronized void removeQueuedChunk(ChunkKey key) {
        ensureOpen();
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM queued_chunks WHERE world = ? AND x = ? AND z = ?");
            try {
                bindKey(statement, key);
                statement.executeUpdate();
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to remove queued chunk " + key, e);
        }
    }

    @Override
    public synchronized void removeTrackedChunk(ChunkKey key) {
        ensureOpen();
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM tracked_chunks WHERE world = ? AND x = ? AND z = ?");
            try {
                bindKey(statement, key);
                statement.executeUpdate();
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to remove tracked chunk " + key, e);
        }
    }

    @Override
    public synchronized long getLastVisitedAt(ChunkKey key) {
        ensureOpen();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT last_visited_at FROM tracked_chunks WHERE world = ? AND x = ? AND z = ? LIMIT 1");
            try {
                bindKey(statement, key);
                ResultSet resultSet = statement.executeQuery();
                try {
                    return resultSet.next() ? resultSet.getLong("last_visited_at") : 0L;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to read last visit for " + key, e);
        }
    }

    private void appendWorldFilter(StringBuilder sql, List<String> worlds) {
        if (worlds.isEmpty()) {
            return;
        }
        sql.append("AND world IN (");
        for (int i = 0; i < worlds.size(); i++) {
            if (i > 0) {
                sql.append(", ");
            }
            sql.append("?");
        }
        sql.append(") ");
    }

    private int bindWorlds(PreparedStatement statement, int parameter, List<String> worlds) throws SQLException {
        for (String world : worlds) {
            statement.setString(parameter++, world);
        }
        return parameter;
    }

    private QueuedChunk readQueuedChunk(ResultSet resultSet) throws SQLException {
        ChunkKey key = new ChunkKey(resultSet.getString("world"), resultSet.getInt("x"), resultSet.getInt("z"));
        QueueState state = QueueState.valueOf(resultSet.getString("state"));
        return new QueuedChunk(
                key,
                resultSet.getLong("queued_at"),
                resultSet.getLong("inactive_since"),
                state,
                resultSet.getString("reason"),
                resultSet.getLong("processed_at"),
                resultSet.getString("error"));
    }

    @Override
    public synchronized boolean isWhitelisted(ChunkKey key) {
        return exists("SELECT 1 FROM whitelisted_chunks WHERE world = ? AND x = ? AND z = ? LIMIT 1", key);
    }

    private boolean exists(String sql, ChunkKey key) {
        ensureOpen();
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            try {
                bindKey(statement, key);
                ResultSet resultSet = statement.executeQuery();
                try {
                    return resultSet.next();
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to check chunk state for " + key, e);
        }
    }

    @Override
    public synchronized void addWhitelistedChunk(ChunkKey key, String note, String addedBy, long createdAt) {
        ensureOpen();
        String sql = "INSERT OR REPLACE INTO whitelisted_chunks(world, x, z, created_at, note, added_by) VALUES(?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            try {
                statement.setString(1, key.getWorld());
                statement.setInt(2, key.getX());
                statement.setInt(3, key.getZ());
                statement.setLong(4, createdAt);
                statement.setString(5, note);
                statement.setString(6, addedBy);
                statement.executeUpdate();
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to whitelist chunk " + key, e);
        }
    }

    @Override
    public synchronized void removeWhitelistedChunk(ChunkKey key) {
        ensureOpen();
        try {
            PreparedStatement statement = connection.prepareStatement("DELETE FROM whitelisted_chunks WHERE world = ? AND x = ? AND z = ?");
            try {
                bindKey(statement, key);
                statement.executeUpdate();
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to remove whitelisted chunk " + key, e);
        }
    }

    @Override
    public synchronized List<WhitelistedChunk> listWhitelistedChunks(int offset, int limit) {
        ensureOpen();
        String sql = "SELECT world, x, z, created_at, note, added_by FROM whitelisted_chunks ORDER BY created_at DESC LIMIT ? OFFSET ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            try {
                statement.setInt(1, Math.max(1, limit));
                statement.setInt(2, Math.max(0, offset));
                ResultSet resultSet = statement.executeQuery();
                try {
                    List<WhitelistedChunk> chunks = new ArrayList<WhitelistedChunk>();
                    while (resultSet.next()) {
                        chunks.add(readWhitelistedChunk(resultSet));
                    }
                    return chunks;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to list whitelisted chunks", e);
        }
    }

    @Override
    public synchronized int countWhitelistedChunks() {
        ensureOpen();
        try {
            return (int) count("SELECT COUNT(*) FROM whitelisted_chunks");
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to count whitelisted chunks", e);
        }
    }

    private WhitelistedChunk readWhitelistedChunk(ResultSet resultSet) throws SQLException {
        ChunkKey key = new ChunkKey(resultSet.getString("world"), resultSet.getInt("x"), resultSet.getInt("z"));
        return new WhitelistedChunk(
                key,
                resultSet.getString("note"),
                resultSet.getString("added_by"),
                resultSet.getLong("created_at"));
    }

    @Override
    public synchronized OptimizerStats getStats() {
        ensureOpen();
        try {
            long tracked = count("SELECT COUNT(*) FROM tracked_chunks");
            long queued = count("SELECT COUNT(*) FROM queued_chunks WHERE state = '" + QueueState.QUEUED.name() + "'");
            long whitelisted = count("SELECT COUNT(*) FROM whitelisted_chunks");
            long oldestVisit = scalarLong("SELECT COALESCE(MIN(last_visited_at), 0) FROM tracked_chunks");
            return new OptimizerStats(tracked, queued, whitelisted, oldestVisit, 0);
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to read optimizer stats", e);
        }
    }

    @Override
    public synchronized QueueStats getQueueStats() {
        ensureOpen();
        try {
            return new QueueStats(
                    (int) count("SELECT COUNT(*) FROM queued_chunks WHERE state = '" + QueueState.QUEUED.name() + "'"),
                    (int) count("SELECT COUNT(*) FROM queued_chunks WHERE state = '" + QueueState.DELETING.name() + "'"),
                    (int) count("SELECT COUNT(*) FROM queued_chunks WHERE state = '" + QueueState.DELETED.name() + "'"),
                    (int) count("SELECT COUNT(*) FROM queued_chunks WHERE state = '" + QueueState.SKIPPED.name() + "'"),
                    (int) count("SELECT COUNT(*) FROM queued_chunks WHERE state = '" + QueueState.FAILED.name() + "'"),
                    (int) count("SELECT COUNT(*) FROM deletion_audit"));
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to read queue statistics", e);
        }
    }

    @Override
    public synchronized void recordDeletionAudit(DeletionAuditRecord record) {
        ensureOpen();
        String sql = "INSERT INTO deletion_audit(world, x, z, actor, requested_at, completed_at, dry_run, success, postponed, message, rollback_data) " +
                "VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            try {
                ChunkKey key = record.getKey();
                statement.setString(1, key.getWorld());
                statement.setInt(2, key.getX());
                statement.setInt(3, key.getZ());
                statement.setString(4, record.getActor() == null ? "unknown" : record.getActor());
                statement.setLong(5, record.getRequestedAt());
                statement.setLong(6, record.getCompletedAt());
                statement.setInt(7, record.isDryRun() ? 1 : 0);
                statement.setInt(8, record.isSuccess() ? 1 : 0);
                statement.setInt(9, record.isPostponed() ? 1 : 0);
                statement.setString(10, record.getMessage());
                statement.setString(11, record.getRollbackData());
                statement.executeUpdate();
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to write deletion audit record for " + record.getKey(), e);
        }
    }

    private long count(String sql) throws SQLException {
        return scalarLong(sql);
    }

    private long scalarLong(String sql) throws SQLException {
        Statement statement = connection.createStatement();
        try {
            ResultSet resultSet = statement.executeQuery(sql);
            try {
                return resultSet.next() ? resultSet.getLong(1) : 0L;
            } finally {
                resultSet.close();
            }
        } finally {
            statement.close();
        }
    }

    @Override
    public synchronized void setMetadata(String key, String value, long updatedAt) {
        ensureOpen();
        String updateSql = "UPDATE metadata SET metadata_value = ?, updated_at = ? WHERE metadata_key = ?";
        String insertSql = "INSERT INTO metadata(metadata_key, metadata_value, updated_at) VALUES(?, ?, ?)";
        try {
            PreparedStatement updateStatement = connection.prepareStatement(updateSql);
            PreparedStatement insertStatement = connection.prepareStatement(insertSql);
            try {
                updateStatement.setString(1, value);
                updateStatement.setLong(2, updatedAt);
                updateStatement.setString(3, key);
                if (updateStatement.executeUpdate() == 0) {
                    insertStatement.setString(1, key);
                    insertStatement.setString(2, value);
                    insertStatement.setLong(3, updatedAt);
                    insertStatement.executeUpdate();
                }
            } finally {
                insertStatement.close();
                updateStatement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to write metadata " + key, e);
        }
    }

    @Override
    public synchronized String getMetadata(String key) {
        ensureOpen();
        try {
            PreparedStatement statement = connection.prepareStatement("SELECT metadata_value FROM metadata WHERE metadata_key = ? LIMIT 1");
            try {
                statement.setString(1, key);
                ResultSet resultSet = statement.executeQuery();
                try {
                    return resultSet.next() ? resultSet.getString("metadata_value") : null;
                } finally {
                    resultSet.close();
                }
            } finally {
                statement.close();
            }
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to read metadata " + key, e);
        }
    }

    private void bindKey(PreparedStatement statement, ChunkKey key) throws SQLException {
        statement.setString(1, key.getWorld());
        statement.setInt(2, key.getX());
        statement.setInt(3, key.getZ());
    }

    private void ensureOpen() {
        if (connection == null) {
            throw new IllegalStateException("SQLite storage has not been initialized");
        }
    }

    private void rollbackQuietly() {
        try {
            if (connection != null) {
                connection.rollback();
            }
        } catch (SQLException ignored) {
            // Preserve the original storage failure.
        }
    }

    private void restoreAutoCommit(boolean autoCommit) {
        try {
            if (connection != null) {
                connection.setAutoCommit(autoCommit);
            }
        } catch (SQLException ignored) {
            // Preserve the original storage failure.
        }
    }

    @Override
    public synchronized void close() {
        if (connection == null) {
            return;
        }
        try {
            connection.close();
        } catch (SQLException e) {
            throw new OptimizerStorageException("Failed to close SQLite storage", e);
        } finally {
            connection = null;
        }
    }
}
