package dev.alexroper.chunkoptimizer.core.model;

public final class ScanResult {
    private final int candidates;
    private final int queued;
    private final int protectedChunks;
    private final int skipped;
    private final long durationMillis;

    public ScanResult(int candidates, int queued, int protectedChunks, int skipped, long durationMillis) {
        this.candidates = candidates;
        this.queued = queued;
        this.protectedChunks = protectedChunks;
        this.skipped = skipped;
        this.durationMillis = durationMillis;
    }

    public int getCandidates() {
        return candidates;
    }

    public int getQueued() {
        return queued;
    }

    public int getProtectedChunks() {
        return protectedChunks;
    }

    public int getSkipped() {
        return skipped;
    }

    public long getDurationMillis() {
        return durationMillis;
    }
}
