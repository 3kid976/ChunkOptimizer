package dev.alexroper.chunkoptimizer.core.model;

public final class DeletionAuditRecord {
    private final ChunkKey key;
    private final String actor;
    private final long requestedAt;
    private final long completedAt;
    private final boolean dryRun;
    private final boolean success;
    private final boolean postponed;
    private final String message;
    private final String rollbackData;

    public DeletionAuditRecord(
            ChunkKey key,
            String actor,
            long requestedAt,
            long completedAt,
            boolean dryRun,
            boolean success,
            boolean postponed,
            String message,
            String rollbackData) {
        this.key = key;
        this.actor = actor;
        this.requestedAt = requestedAt;
        this.completedAt = completedAt;
        this.dryRun = dryRun;
        this.success = success;
        this.postponed = postponed;
        this.message = message;
        this.rollbackData = rollbackData;
    }

    public ChunkKey getKey() {
        return key;
    }

    public String getActor() {
        return actor;
    }

    public long getRequestedAt() {
        return requestedAt;
    }

    public long getCompletedAt() {
        return completedAt;
    }

    public boolean isDryRun() {
        return dryRun;
    }

    public boolean isSuccess() {
        return success;
    }

    public boolean isPostponed() {
        return postponed;
    }

    public String getMessage() {
        return message;
    }

    public String getRollbackData() {
        return rollbackData;
    }
}
