package dev.alexroper.chunkoptimizer.core.service;

import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.OptimizerStats;
import dev.alexroper.chunkoptimizer.core.model.ScanResult;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;
import dev.alexroper.chunkoptimizer.core.scanner.ChunkScanner;
import dev.alexroper.chunkoptimizer.core.scheduler.ScheduledTaskHandle;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;

import java.util.concurrent.CompletableFuture;

public final class ChunkOptimizerEngine {
    private final OptimizerConfig config;
    private final OptimizerStorage storage;
    private final ActivityTracker activityTracker;
    private final ChunkScanner scanner;
    private final SchedulerAdapter scheduler;
    private final OptimizerLogger logger;
    private final ChunkDeletionService deletionService;
    private ScheduledTaskHandle flushTask;
    private ScheduledTaskHandle scanTask;
    private ScheduledTaskHandle deleteTask;

    public ChunkOptimizerEngine(
            OptimizerConfig config,
            OptimizerStorage storage,
            ActivityTracker activityTracker,
            ChunkScanner scanner,
            SchedulerAdapter scheduler,
            OptimizerLogger logger,
            ChunkDeletionService deletionService) {
        this.config = config;
        this.storage = storage;
        this.activityTracker = activityTracker;
        this.scanner = scanner;
        this.scheduler = scheduler;
        this.logger = logger;
        this.deletionService = deletionService;
    }

    public void start() {
        long flushPeriod = config.getVisitFlushIntervalMillis();
        flushTask = scheduler.runRepeatingAsync(() -> {
            try {
                activityTracker.flush();
            } catch (RuntimeException e) {
                logger.warn("Failed to flush chunk activity records.", e);
            }
        }, flushPeriod, flushPeriod);

        if (config.isAutoQueue()) {
            long scanPeriod = config.getScanIntervalMillis();
            long initialDelay = Math.min(scanPeriod, 60000L);
            scanTask = scheduler.runRepeatingAsync(() -> {
                try {
                    scanner.scanNow();
                } catch (RuntimeException e) {
                    logger.warn("Chunk scan failed.", e);
                }
            }, initialDelay, scanPeriod);
        }

        if (config.isAutoDeleteEnabled() && deletionService != null) {
            long deletePeriod = config.getAutoDeleteIntervalMillis();
            long initialDelay = Math.min(deletePeriod, 60000L);
            deleteTask = scheduler.runRepeatingAsync(() -> {
                try {
                    activityTracker.flush();
                } catch (RuntimeException e) {
                    logger.warn("Failed to flush chunk activity records before deletion maintenance.", e);
                }
                deletionService.processMaintenanceCycle().whenComplete((deleted, throwable) -> {
                    if (throwable != null) {
                        logger.warn("Chunk deletion maintenance failed.", throwable);
                    } else if (deleted != null && deleted.intValue() > 0) {
                        logger.info("Chunk deletion maintenance reset " + deleted + " chunk(s).");
                    }
                });
            }, initialDelay, deletePeriod);
        }
    }

    public void stop() {
        cancelTask(flushTask);
        cancelTask(scanTask);
        cancelTask(deleteTask);
        flushTask = null;
        scanTask = null;
        deleteTask = null;
        if (deletionService != null) {
            deletionService.shutdown();
        }
        try {
            activityTracker.flush();
        } catch (RuntimeException e) {
            logger.warn("Failed to flush final chunk activity records.", e);
        }
    }

    private void cancelTask(ScheduledTaskHandle handle) {
        if (handle != null) {
            handle.cancel();
        }
    }

    public void recordVisit(ChunkKey key) {
        activityTracker.markVisited(key);
    }

    public CompletableFuture<ScanResult> triggerScan() {
        CompletableFuture<ScanResult> future = new CompletableFuture<ScanResult>();
        scheduler.runAsync(() -> {
            try {
                future.complete(scanner.scanNow());
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
            }
        });
        return future;
    }

    public OptimizerStats getStats() {
        OptimizerStats stored = storage.getStats();
        return new OptimizerStats(
                stored.getTrackedChunks(),
                stored.getQueuedChunks(),
                stored.getWhitelistedChunks(),
                stored.getOldestVisitTimestamp(),
                activityTracker.getPendingVisitCount());
    }
}
