package dev.alexroper.chunkoptimizer.core.protection;

public final class ProtectionResult {
    private static final ProtectionResult UNPROTECTED = new ProtectionResult(false, false, "unprotected");

    private final boolean protectedChunk;
    private final boolean unknown;
    private final String reason;

    private ProtectionResult(boolean protectedChunk, boolean unknown, String reason) {
        this.protectedChunk = protectedChunk;
        this.unknown = unknown;
        this.reason = reason;
    }

    public static ProtectionResult unprotected() {
        return UNPROTECTED;
    }

    public static ProtectionResult protectedChunk(String reason) {
        return new ProtectionResult(true, false, reason);
    }

    public static ProtectionResult unknown(String reason) {
        return new ProtectionResult(false, true, reason);
    }

    public boolean isProtectedChunk() {
        return protectedChunk;
    }

    public boolean isUnknown() {
        return unknown;
    }

    public String getReason() {
        return reason;
    }
}
