package dev.alexroper.chunkoptimizer.core.model;

public final class InactiveChunk {
    private final ChunkKey key;
    private final long lastVisitedAt;

    public InactiveChunk(ChunkKey key, long lastVisitedAt) {
        this.key = key;
        this.lastVisitedAt = lastVisitedAt;
    }

    public ChunkKey getKey() {
        return key;
    }

    public long getLastVisitedAt() {
        return lastVisitedAt;
    }
}
