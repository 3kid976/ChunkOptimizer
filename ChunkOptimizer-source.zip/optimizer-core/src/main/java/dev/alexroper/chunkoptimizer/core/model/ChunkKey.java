package dev.alexroper.chunkoptimizer.core.model;

import java.util.Objects;

public final class ChunkKey {
    private final String world;
    private final int x;
    private final int z;

    public ChunkKey(String world, int x, int z) {
        if (world == null || world.trim().isEmpty()) {
            throw new IllegalArgumentException("world cannot be blank");
        }
        this.world = world;
        this.x = x;
        this.z = z;
    }

    public String getWorld() {
        return world;
    }

    public int getX() {
        return x;
    }

    public int getZ() {
        return z;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof ChunkKey)) {
            return false;
        }
        ChunkKey chunkKey = (ChunkKey) o;
        return x == chunkKey.x && z == chunkKey.z && world.equals(chunkKey.world);
    }

    @Override
    public int hashCode() {
        return Objects.hash(world, x, z);
    }

    @Override
    public String toString() {
        return world + "[" + x + "," + z + "]";
    }
}
