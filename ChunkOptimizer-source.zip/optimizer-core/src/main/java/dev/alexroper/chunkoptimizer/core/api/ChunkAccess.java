package dev.alexroper.chunkoptimizer.core.api;

import dev.alexroper.chunkoptimizer.core.model.ChunkKey;

import java.util.Collection;

public interface ChunkAccess {
    boolean isWorldAvailable(String worldName);

    boolean isEndWorld(String worldName);

    boolean isChunkLoaded(ChunkKey key);

    boolean isSpawnProtected(ChunkKey key, int radiusChunks);

    int countOnlinePlayersNear(ChunkKey key, int radiusChunks);

    double getRecentTps();

    Collection<String> getLoadedWorldNames();
}
