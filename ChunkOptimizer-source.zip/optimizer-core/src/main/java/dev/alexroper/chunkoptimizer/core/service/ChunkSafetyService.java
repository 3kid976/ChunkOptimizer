package dev.alexroper.chunkoptimizer.core.service;

import dev.alexroper.chunkoptimizer.core.api.ChunkAccess;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.model.ChunkInspection;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.QueueState;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionResult;
import dev.alexroper.chunkoptimizer.core.protection.ProtectionService;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public final class ChunkSafetyService {
    private final OptimizerConfig config;
    private final OptimizerStorage storage;
    private final ChunkAccess chunkAccess;
    private final ProtectionService protectionService;
    private final SchedulerAdapter scheduler;

    public ChunkSafetyService(
            OptimizerConfig config,
            OptimizerStorage storage,
            ChunkAccess chunkAccess,
            ProtectionService protectionService,
            SchedulerAdapter scheduler) {
        this.config = config;
        this.storage = storage;
        this.chunkAccess = chunkAccess;
        this.protectionService = protectionService;
        this.scheduler = scheduler;
    }

    public CompletableFuture<ChunkInspection> inspect(final ChunkKey key, final boolean includeNearbyProtections) {
        return inspect(key, includeNearbyProtections, 0L);
    }

    public CompletableFuture<ChunkInspection> inspect(
            final ChunkKey key,
            final boolean includeNearbyProtections,
            final long cooldownRemainingMillis) {
        final CompletableFuture<ChunkInspection> future = new CompletableFuture<ChunkInspection>();
        scheduler.runAsync(() -> {
            final StorageSnapshot snapshot;
            try {
                snapshot = new StorageSnapshot(
                        storage.getLastVisitedAt(key),
                        storage.getQueuedChunk(key),
                        storage.isWhitelisted(key));
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
                return;
            }

            scheduler.callSync(() -> inspectSync(key, snapshot, includeNearbyProtections, cooldownRemainingMillis))
                    .whenComplete((inspection, throwable) -> {
                        if (throwable != null) {
                            future.completeExceptionally(throwable);
                        } else {
                            future.complete(inspection);
                        }
                    });
        });
        return future;
    }

    public ChunkInspection inspectSync(
            ChunkKey key,
            long lastVisitedAt,
            QueuedChunk queuedChunk,
            boolean whitelisted,
            boolean includeNearbyProtections,
            long cooldownRemainingMillis) {
        return inspectSync(
                key,
                new StorageSnapshot(lastVisitedAt, queuedChunk, whitelisted),
                includeNearbyProtections,
                cooldownRemainingMillis);
    }

    private ChunkInspection inspectSync(
            ChunkKey key,
            StorageSnapshot snapshot,
            boolean includeNearbyProtections,
            long cooldownRemainingMillis) {
        long now = System.currentTimeMillis();
        List<String> blockers = new ArrayList<String>();

        boolean worldEnabled = config.isWorldEnabled(key.getWorld());
        if (!worldEnabled) {
            blockers.add("World is disabled in config.");
        }

        boolean worldAvailable = chunkAccess.isWorldAvailable(key.getWorld());
        if (!worldAvailable) {
            blockers.add("World is not loaded.");
        }

        boolean chunkLoaded = worldAvailable && chunkAccess.isChunkLoaded(key);

        boolean spawnProtected = worldAvailable && chunkAccess.isSpawnProtected(key, config.getSpawnProtectionRadiusChunks());
        if (spawnProtected) {
            blockers.add("Chunk is inside configured spawn protection radius.");
        }

        int nearbyPlayers = worldAvailable ? chunkAccess.countOnlinePlayersNear(key, config.getPlayerSafetyRadiusChunks()) : 0;
        if (nearbyPlayers > 0) {
            blockers.add("Online player safety radius contains " + nearbyPlayers + " player(s).");
        }

        boolean recentActivity = snapshot.lastVisitedAt > 0L
                && config.getRecentVisitGraceMillis() > 0L
                && snapshot.lastVisitedAt >= now - config.getRecentVisitGraceMillis();
        if (recentActivity) {
            blockers.add("Chunk was visited inside the recent activity grace window.");
        }

        boolean visitedAfterQueue = snapshot.queuedChunk != null
                && snapshot.queuedChunk.getState() == QueueState.QUEUED
                && snapshot.lastVisitedAt > snapshot.queuedChunk.getQueuedAt();
        if (visitedAfterQueue) {
            blockers.add("Chunk was visited after it was queued.");
        }

        if (snapshot.whitelisted) {
            blockers.add("Chunk is manually whitelisted.");
        }

        boolean cooldownActive = cooldownRemainingMillis > 0L;
        if (cooldownActive) {
            blockers.add("Deletion cooldown is active for " + cooldownRemainingMillis + "ms.");
        }

        double tps = chunkAccess.getRecentTps();
        boolean tpsThrottled = config.isTpsThrottleEnabled()
                && tps >= 0.0D
                && config.getMinimumTps() > 0.0D
                && tps < config.getMinimumTps();
        if (tpsThrottled) {
            blockers.add("Server TPS is below deletion threshold (" + roundTps(tps) + " < " + roundTps(config.getMinimumTps()) + ").");
        }

        ProtectionResult protection = worldAvailable ? protectionService.check(key) : ProtectionResult.protectedChunk("world unavailable");
        if (protection.isProtectedChunk()) {
            blockers.add("Protected by " + protection.getReason() + ".");
        }

        List<String> nearbyProtections = includeNearbyProtections && worldAvailable
                ? inspectNearbyProtections(key)
                : new ArrayList<String>();

        return new ChunkInspection(
                key,
                snapshot.lastVisitedAt,
                snapshot.queuedChunk,
                snapshot.whitelisted,
                worldEnabled,
                worldAvailable,
                chunkLoaded,
                spawnProtected,
                nearbyPlayers,
                recentActivity,
                cooldownActive,
                cooldownRemainingMillis,
                tpsThrottled,
                tps,
                config.isDryRunMode(),
                protection,
                blockers,
                nearbyProtections);
    }

    private List<String> inspectNearbyProtections(ChunkKey key) {
        List<String> protections = new ArrayList<String>();
        int radius = config.getInspectNearbyRadiusChunks();
        if (radius <= 0) {
            return protections;
        }
        int maxResults = 12;
        for (int x = key.getX() - radius; x <= key.getX() + radius; x++) {
            for (int z = key.getZ() - radius; z <= key.getZ() + radius; z++) {
                if (x == key.getX() && z == key.getZ()) {
                    continue;
                }
                ChunkKey nearby = new ChunkKey(key.getWorld(), x, z);
                ProtectionResult result = protectionService.check(nearby);
                if (result.isProtectedChunk()) {
                    protections.add(nearby.toString() + ": " + result.getReason());
                    if (protections.size() >= maxResults) {
                        protections.add("Additional nearby protections omitted.");
                        return protections;
                    }
                }
            }
        }
        return protections;
    }

    private String roundTps(double value) {
        return String.format(java.util.Locale.ROOT, "%.2f", value);
    }

    private static final class StorageSnapshot {
        private final long lastVisitedAt;
        private final QueuedChunk queuedChunk;
        private final boolean whitelisted;

        private StorageSnapshot(long lastVisitedAt, QueuedChunk queuedChunk, boolean whitelisted) {
            this.lastVisitedAt = lastVisitedAt;
            this.queuedChunk = queuedChunk;
            this.whitelisted = whitelisted;
        }
    }
}
