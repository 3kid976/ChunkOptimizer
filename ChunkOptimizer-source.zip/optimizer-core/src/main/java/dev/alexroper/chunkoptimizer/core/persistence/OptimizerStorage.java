package dev.alexroper.chunkoptimizer.core.persistence;

import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.DeletionAuditRecord;
import dev.alexroper.chunkoptimizer.core.model.InactiveChunk;
import dev.alexroper.chunkoptimizer.core.model.OptimizerStats;
import dev.alexroper.chunkoptimizer.core.model.PendingVisit;
import dev.alexroper.chunkoptimizer.core.model.QueueStats;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import dev.alexroper.chunkoptimizer.core.model.QueueState;
import dev.alexroper.chunkoptimizer.core.model.WhitelistedChunk;

import java.util.Collection;
import java.util.List;
import java.util.Map;

public interface OptimizerStorage extends AutoCloseable {
    void initialize();

    void recordVisits(Map<ChunkKey, PendingVisit> visits);

    List<InactiveChunk> findInactiveChunks(Collection<String> enabledWorlds, long cutoffTimestamp, int limit);

    boolean enqueueChunk(ChunkKey key, long inactiveSince, long queuedAt, String reason);

    boolean isQueued(ChunkKey key);

    QueuedChunk getQueuedChunk(ChunkKey key);

    List<QueuedChunk> listQueuedChunks(Collection<String> worlds, QueueState state, int offset, int limit);

    int countQueuedChunks(Collection<String> worlds, QueueState state);

    List<QueuedChunk> findQueuedChunksReadyForDeletion(long queuedBeforeOrAt, int limit);

    void markQueueState(ChunkKey key, QueueState state, long processedAt, String error);

    void removeQueuedChunk(ChunkKey key);

    void removeTrackedChunk(ChunkKey key);

    long getLastVisitedAt(ChunkKey key);

    boolean isWhitelisted(ChunkKey key);

    default void addWhitelistedChunk(ChunkKey key, String reason, long createdAt) {
        addWhitelistedChunk(key, reason, "unknown", createdAt);
    }

    void addWhitelistedChunk(ChunkKey key, String reason, String addedBy, long createdAt);

    void removeWhitelistedChunk(ChunkKey key);

    List<WhitelistedChunk> listWhitelistedChunks(int offset, int limit);

    int countWhitelistedChunks();

    OptimizerStats getStats();

    QueueStats getQueueStats();

    void recordDeletionAudit(DeletionAuditRecord record);

    void setMetadata(String key, String value, long updatedAt);

    String getMetadata(String key);

    @Override
    void close();
}
