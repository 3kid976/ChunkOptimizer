package dev.alexroper.chunkoptimizer.core.api;

import dev.alexroper.chunkoptimizer.core.model.ChunkDeletionResult;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;

import java.util.concurrent.CompletableFuture;

public interface ChunkDeletionAdapter {
    CompletableFuture<ChunkDeletionResult> resetChunk(ChunkKey key);
}
