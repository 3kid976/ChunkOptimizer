package dev.alexroper.chunkoptimizer.core.model;

public final class PendingVisit {
    private final long lastVisitedAt;
    private final int visitCount;

    public PendingVisit(long lastVisitedAt, int visitCount) {
        this.lastVisitedAt = lastVisitedAt;
        this.visitCount = visitCount;
    }

    public long getLastVisitedAt() {
        return lastVisitedAt;
    }

    public int getVisitCount() {
        return visitCount;
    }

    public PendingVisit merge(long timestamp) {
        long newestTimestamp = Math.max(lastVisitedAt, timestamp);
        return new PendingVisit(newestTimestamp, visitCount + 1);
    }
}
