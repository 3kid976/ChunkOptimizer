package dev.alexroper.chunkoptimizer.core.service;

import dev.alexroper.chunkoptimizer.core.api.ChunkDeletionAdapter;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkInspection;
import dev.alexroper.chunkoptimizer.core.model.DeletionAuditRecord;
import dev.alexroper.chunkoptimizer.core.model.ChunkDeletionResult;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import dev.alexroper.chunkoptimizer.core.model.QueueState;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicInteger;

public final class ChunkDeletionService {
    private final OptimizerConfig config;
    private final OptimizerStorage storage;
    private final ChunkDeletionAdapter deletionAdapter;
    private final SchedulerAdapter scheduler;
    private final OptimizerLogger logger;
    private final ChunkSafetyService safetyService;
    private final AtomicBoolean maintenanceRunning = new AtomicBoolean(false);
    private final AtomicBoolean shuttingDown = new AtomicBoolean(false);
    private final AtomicLong lastDeletionAt = new AtomicLong(0L);

    public ChunkDeletionService(
            OptimizerConfig config,
            OptimizerStorage storage,
            ChunkSafetyService safetyService,
            ChunkDeletionAdapter deletionAdapter,
            SchedulerAdapter scheduler,
            OptimizerLogger logger) {
        this.config = config;
        this.storage = storage;
        this.safetyService = safetyService;
        this.deletionAdapter = deletionAdapter;
        this.scheduler = scheduler;
        this.logger = logger;
    }

    public CompletableFuture<ChunkDeletionResult> deleteChunk(final ChunkKey key, final String actor) {
        final CompletableFuture<ChunkDeletionResult> future = new CompletableFuture<ChunkDeletionResult>();
        final long requestedAt = System.currentTimeMillis();
        inspectForDeletion(key).whenComplete((inspection, throwable) -> {
            if (throwable != null) {
                future.completeExceptionally(throwable);
                return;
            }
            prepareDeletion(key, normalizeActor(actor), requestedAt, inspection, future);
        });
        return future;
    }

    public CompletableFuture<ChunkInspection> previewDeletion(final ChunkKey key) {
        return safetyService.inspect(key, true, cooldownRemainingMillis());
    }

    public CompletableFuture<Integer> processMaintenanceCycle() {
        final CompletableFuture<Integer> future = new CompletableFuture<Integer>();
        if (shuttingDown.get()) {
            future.complete(Integer.valueOf(0));
            return future;
        }
        if (!maintenanceRunning.compareAndSet(false, true)) {
            future.complete(Integer.valueOf(0));
            return future;
        }

        scheduler.runAsync(() -> {
            final List<QueuedChunk> chunks;
            try {
                long cutoff = System.currentTimeMillis() - config.getAutoDeleteDelayMillis();
                chunks = storage.findQueuedChunksReadyForDeletion(cutoff, config.getAutoDeleteBatchSize());
            } catch (Throwable throwable) {
                maintenanceRunning.set(false);
                future.completeExceptionally(throwable);
                return;
            }

            if (chunks.isEmpty()) {
                maintenanceRunning.set(false);
                future.complete(Integer.valueOf(0));
                return;
            }

            final AtomicInteger deleted = new AtomicInteger(0);
            processMaintenanceChunk(chunks, 0, deleted, future);
        });
        return future;
    }

    public void shutdown() {
        shuttingDown.set(true);
    }

    private void processMaintenanceChunk(
            final List<QueuedChunk> chunks,
            final int index,
            final AtomicInteger deleted,
            final CompletableFuture<Integer> future) {
        if (index >= chunks.size() || shuttingDown.get()) {
            maintenanceRunning.set(false);
            future.complete(Integer.valueOf(deleted.get()));
            return;
        }

        deleteChunk(chunks.get(index).getKey(), "maintenance").whenComplete((result, throwable) -> {
            if (throwable != null) {
                logger.warn("Maintenance deletion failed for " + chunks.get(index).getKey() + ".", throwable);
            } else if (result != null && result.isSuccess() && !result.isDryRun()) {
                deleted.incrementAndGet();
            }
            processMaintenanceChunk(chunks, index + 1, deleted, future);
        });
    }

    private CompletableFuture<ChunkInspection> inspectForDeletion(ChunkKey key) {
        return safetyService.inspect(key, false, cooldownRemainingMillis());
    }

    private void prepareDeletion(
            final ChunkKey key,
            final String actor,
            final long requestedAt,
            final ChunkInspection inspection,
            final CompletableFuture<ChunkDeletionResult> future) {
        if (shuttingDown.get()) {
            completeWithoutState(future, requestedAt, actor, ChunkDeletionResult.postponed(key, "ChunkOptimizer is shutting down."));
            return;
        }

        if (!inspection.canDelete()) {
            ChunkDeletionResult result = shouldPostpone(inspection)
                    ? ChunkDeletionResult.postponed(key, "Deletion postponed: " + joinReasons(inspection))
                    : ChunkDeletionResult.failure(key, "Deletion blocked: " + joinReasons(inspection));
            QueueState state = shouldPostpone(inspection) ? QueueState.QUEUED : QueueState.SKIPPED;
            completeWithOptionalState(future, requestedAt, actor, result, state, inspection.isQueued());
            return;
        }

        if (config.isDryRunMode()) {
            completeWithoutState(future, requestedAt, actor, ChunkDeletionResult.dryRun(key, "Dry-run: chunk passed all safety checks and would be reset."));
            return;
        }

        scheduler.runAsync(() -> {
            try {
                if (!inspection.isQueued()) {
                    long now = System.currentTimeMillis();
                    storage.enqueueChunk(key, inspection.getLastVisitedAt() > 0L ? inspection.getLastVisitedAt() : now, now, "manual deletion requested by " + actor);
                }
                storage.markQueueState(key, QueueState.DELETING, 0L, null);
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
                return;
            }

            scheduler.runSync(() -> executeDeletion(key, actor, requestedAt, future));
        });
    }

    private void executeDeletion(
            final ChunkKey key,
            final String actor,
            final long requestedAt,
            final CompletableFuture<ChunkDeletionResult> future) {
        deletionAdapter.resetChunk(key).whenComplete((result, throwable) -> {
            if (throwable != null) {
                logger.warn("Chunk deletion failed for " + key + ".", throwable);
                completeWithState(future, requestedAt, actor, ChunkDeletionResult.failure(key, throwable.getMessage()), QueueState.FAILED);
                return;
            }
            ChunkDeletionResult safeResult = result == null
                    ? ChunkDeletionResult.failure(key, "Deletion adapter returned no result.")
                    : result;
            if (safeResult.isSuccess()) {
                completeSuccessfulDeletion(future, requestedAt, actor, safeResult);
                return;
            }
            completeWithState(future, requestedAt, actor, safeResult, safeResult.isPostponed() ? QueueState.QUEUED : QueueState.FAILED);
        });
    }

    private void completeSuccessfulDeletion(
            final CompletableFuture<ChunkDeletionResult> future,
            final long requestedAt,
            final String actor,
            final ChunkDeletionResult result) {
        scheduler.runAsync(() -> {
            try {
                storage.markQueueState(result.getKey(), QueueState.DELETED, System.currentTimeMillis(), null);
                storage.removeTrackedChunk(result.getKey());
                recordAudit(requestedAt, actor, result);
                lastDeletionAt.set(System.currentTimeMillis());
                logger.info("Deleted chunk data for " + result.getKey() + ": " + result.getMessage());
                future.complete(result);
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
            }
        });
    }

    private void completeWithState(
            final CompletableFuture<ChunkDeletionResult> future,
            final long requestedAt,
            final String actor,
            final ChunkDeletionResult result,
            final QueueState state) {
        completeWithOptionalState(future, requestedAt, actor, result, state, true);
    }

    private void completeWithOptionalState(
            final CompletableFuture<ChunkDeletionResult> future,
            final long requestedAt,
            final String actor,
            final ChunkDeletionResult result,
            final QueueState state,
            final boolean updateQueueState) {
        scheduler.runAsync(() -> {
            try {
                if (updateQueueState) {
                    long processedAt = state == QueueState.QUEUED || state == QueueState.DELETING ? 0L : System.currentTimeMillis();
                    storage.markQueueState(result.getKey(), state, processedAt, result.getMessage());
                }
                recordAudit(requestedAt, actor, result);
                future.complete(result);
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
            }
        });
    }

    private void completeWithoutState(
            final CompletableFuture<ChunkDeletionResult> future,
            final long requestedAt,
            final String actor,
            final ChunkDeletionResult result) {
        completeWithOptionalState(future, requestedAt, actor, result, QueueState.QUEUED, false);
    }

    private boolean shouldPostpone(ChunkInspection inspection) {
        return !inspection.isWorldAvailable()
                || inspection.getNearbyPlayers() > 0
                || inspection.hasRecentActivity()
                || inspection.isCooldownActive()
                || inspection.isTpsThrottled();
    }

    private String joinReasons(ChunkInspection inspection) {
        StringBuilder builder = new StringBuilder();
        List<String> blockers = inspection.getBlockers();
        for (int i = 0; i < blockers.size(); i++) {
            if (i > 0) {
                builder.append("; ");
            }
            builder.append(blockers.get(i));
        }
        return builder.toString();
    }

    private long cooldownRemainingMillis() {
        long cooldown = config.getDeletionCooldownMillis();
        if (cooldown <= 0L) {
            return 0L;
        }
        long elapsed = System.currentTimeMillis() - lastDeletionAt.get();
        return Math.max(0L, cooldown - elapsed);
    }

    private void recordAudit(long requestedAt, String actor, ChunkDeletionResult result) {
        storage.recordDeletionAudit(new DeletionAuditRecord(
                result.getKey(),
                actor,
                requestedAt,
                System.currentTimeMillis(),
                result.isDryRun(),
                result.isSuccess(),
                result.isPostponed(),
                result.getMessage(),
                result.getRollbackData()));
    }

    private String normalizeActor(String actor) {
        if (actor == null || actor.trim().isEmpty()) {
            return "unknown";
        }
        return actor.trim();
    }
}
