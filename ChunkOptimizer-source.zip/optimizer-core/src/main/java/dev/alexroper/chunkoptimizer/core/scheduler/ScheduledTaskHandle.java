package dev.alexroper.chunkoptimizer.core.scheduler;

public interface ScheduledTaskHandle {
    void cancel();
}
