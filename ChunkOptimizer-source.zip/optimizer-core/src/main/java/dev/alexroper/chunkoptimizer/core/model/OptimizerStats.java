package dev.alexroper.chunkoptimizer.core.model;

public final class OptimizerStats {
    private final long trackedChunks;
    private final long queuedChunks;
    private final long whitelistedChunks;
    private final long oldestVisitTimestamp;
    private final int pendingVisitWrites;

    public OptimizerStats(long trackedChunks, long queuedChunks, long whitelistedChunks, long oldestVisitTimestamp, int pendingVisitWrites) {
        this.trackedChunks = trackedChunks;
        this.queuedChunks = queuedChunks;
        this.whitelistedChunks = whitelistedChunks;
        this.oldestVisitTimestamp = oldestVisitTimestamp;
        this.pendingVisitWrites = pendingVisitWrites;
    }

    public long getTrackedChunks() {
        return trackedChunks;
    }

    public long getQueuedChunks() {
        return queuedChunks;
    }

    public long getWhitelistedChunks() {
        return whitelistedChunks;
    }

    public long getOldestVisitTimestamp() {
        return oldestVisitTimestamp;
    }

    public int getPendingVisitWrites() {
        return pendingVisitWrites;
    }
}
