package dev.alexroper.chunkoptimizer.core.config;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public final class OptimizerConfig {
    private static final long MINIMUM_DURATION_MILLIS = TimeUnit.SECONDS.toMillis(1L);
    private static final long MINIMUM_VISIT_FLUSH_MILLIS = TimeUnit.SECONDS.toMillis(5L);

    private final long inactivityMillis;
    private final long scanIntervalMillis;
    private final int chunksPerCycle;
    private final List<String> enabledWorlds;
    private final Set<String> enabledWorldLookup;
    private final boolean autoQueue;
    private final boolean autoDeleteEnabled;
    private final long autoDeleteDelayMillis;
    private final long autoDeleteIntervalMillis;
    private final int autoDeleteBatchSize;
    private final int endIslandProtectionRadius;
    private final boolean debugMode;
    private final long visitFlushIntervalMillis;
    private final boolean worldGuardEnabled;
    private final boolean landsEnabled;
    private final boolean externalProtectionFailClosed;
    private final boolean dryRunMode;
    private final long deletionCooldownMillis;
    private final int playerSafetyRadiusChunks;
    private final int spawnProtectionRadiusChunks;
    private final long recentVisitGraceMillis;
    private final boolean tpsThrottleEnabled;
    private final double minimumTps;
    private final int inspectNearbyRadiusChunks;
    private final String databaseFileName;

    public OptimizerConfig(
            long inactivityMillis,
            long scanIntervalMillis,
            int chunksPerCycle,
            List<String> enabledWorlds,
            boolean autoQueue,
            boolean autoDeleteEnabled,
            long autoDeleteDelayMillis,
            long autoDeleteIntervalMillis,
            int autoDeleteBatchSize,
            int endIslandProtectionRadius,
            boolean debugMode,
            long visitFlushIntervalMillis,
            boolean worldGuardEnabled,
            boolean landsEnabled,
            boolean externalProtectionFailClosed,
            boolean dryRunMode,
            long deletionCooldownMillis,
            int playerSafetyRadiusChunks,
            int spawnProtectionRadiusChunks,
            long recentVisitGraceMillis,
            boolean tpsThrottleEnabled,
            double minimumTps,
            int inspectNearbyRadiusChunks,
            String databaseFileName) {
        this.inactivityMillis = Math.max(MINIMUM_DURATION_MILLIS, inactivityMillis);
        this.scanIntervalMillis = Math.max(MINIMUM_DURATION_MILLIS, scanIntervalMillis);
        this.chunksPerCycle = Math.max(1, chunksPerCycle);
        this.enabledWorlds = normalizeWorlds(enabledWorlds);
        this.enabledWorldLookup = new HashSet<String>();
        for (String world : this.enabledWorlds) {
            enabledWorldLookup.add(world.toLowerCase(Locale.ROOT));
        }
        this.autoQueue = autoQueue;
        this.autoDeleteEnabled = autoDeleteEnabled;
        this.autoDeleteDelayMillis = Math.max(MINIMUM_DURATION_MILLIS, autoDeleteDelayMillis);
        this.autoDeleteIntervalMillis = Math.max(MINIMUM_DURATION_MILLIS, autoDeleteIntervalMillis);
        this.autoDeleteBatchSize = Math.max(1, autoDeleteBatchSize);
        this.endIslandProtectionRadius = Math.max(0, endIslandProtectionRadius);
        this.debugMode = debugMode;
        this.visitFlushIntervalMillis = Math.max(MINIMUM_VISIT_FLUSH_MILLIS, visitFlushIntervalMillis);
        this.worldGuardEnabled = worldGuardEnabled;
        this.landsEnabled = landsEnabled;
        this.externalProtectionFailClosed = externalProtectionFailClosed;
        this.dryRunMode = dryRunMode;
        this.deletionCooldownMillis = Math.max(0L, deletionCooldownMillis);
        this.playerSafetyRadiusChunks = Math.max(0, playerSafetyRadiusChunks);
        this.spawnProtectionRadiusChunks = Math.max(0, spawnProtectionRadiusChunks);
        this.recentVisitGraceMillis = Math.max(0L, recentVisitGraceMillis);
        this.tpsThrottleEnabled = tpsThrottleEnabled;
        this.minimumTps = Math.max(0.0D, minimumTps);
        this.inspectNearbyRadiusChunks = Math.max(0, inspectNearbyRadiusChunks);
        this.databaseFileName = databaseFileName == null || databaseFileName.trim().isEmpty() ? "chunkoptimizer.db" : databaseFileName.trim();
    }

    private static List<String> normalizeWorlds(List<String> worlds) {
        if (worlds == null || worlds.isEmpty()) {
            return Collections.emptyList();
        }
        List<String> normalized = new ArrayList<String>();
        for (String world : worlds) {
            if (world != null && !world.trim().isEmpty()) {
                normalized.add(world.trim());
            }
        }
        return Collections.unmodifiableList(normalized);
    }

    public int getInactivityDays() {
        return ceilDuration(inactivityMillis, TimeUnit.DAYS);
    }

    public long getInactivityMillis() {
        return inactivityMillis;
    }

    public String getInactivityDurationLabel() {
        return formatDuration(inactivityMillis);
    }

    public int getScanIntervalMinutes() {
        return ceilDuration(scanIntervalMillis, TimeUnit.MINUTES);
    }

    public long getScanIntervalMillis() {
        return scanIntervalMillis;
    }

    public int getChunksPerCycle() {
        return chunksPerCycle;
    }

    public List<String> getEnabledWorlds() {
        return enabledWorlds;
    }

    public boolean isWorldEnabled(String world) {
        return enabledWorldLookup.isEmpty() || enabledWorldLookup.contains(world.toLowerCase(Locale.ROOT));
    }

    public boolean isAutoQueue() {
        return autoQueue;
    }

    public boolean isAutoDeleteEnabled() {
        return autoDeleteEnabled;
    }

    public int getAutoDeleteDelayDays() {
        return ceilDuration(autoDeleteDelayMillis, TimeUnit.DAYS);
    }

    public long getAutoDeleteDelayMillis() {
        return autoDeleteDelayMillis;
    }

    public String getAutoDeleteDelayDurationLabel() {
        return formatDuration(autoDeleteDelayMillis);
    }

    public int getAutoDeleteIntervalMinutes() {
        return ceilDuration(autoDeleteIntervalMillis, TimeUnit.MINUTES);
    }

    public long getAutoDeleteIntervalMillis() {
        return autoDeleteIntervalMillis;
    }

    public int getAutoDeleteBatchSize() {
        return autoDeleteBatchSize;
    }

    public int getEndIslandProtectionRadius() {
        return endIslandProtectionRadius;
    }

    public boolean isDebugMode() {
        return debugMode;
    }

    public int getVisitFlushIntervalSeconds() {
        return ceilDuration(visitFlushIntervalMillis, TimeUnit.SECONDS);
    }

    public long getVisitFlushIntervalMillis() {
        return visitFlushIntervalMillis;
    }

    public boolean isWorldGuardEnabled() {
        return worldGuardEnabled;
    }

    public boolean isLandsEnabled() {
        return landsEnabled;
    }

    public boolean isExternalProtectionFailClosed() {
        return externalProtectionFailClosed;
    }

    public boolean isDryRunMode() {
        return dryRunMode;
    }

    public int getDeletionCooldownSeconds() {
        return ceilDuration(deletionCooldownMillis, TimeUnit.SECONDS);
    }

    public long getDeletionCooldownMillis() {
        return deletionCooldownMillis;
    }

    public String getDeletionCooldownDurationLabel() {
        return formatDuration(deletionCooldownMillis);
    }

    public int getPlayerSafetyRadiusChunks() {
        return playerSafetyRadiusChunks;
    }

    public int getSpawnProtectionRadiusChunks() {
        return spawnProtectionRadiusChunks;
    }

    public int getRecentVisitGraceMinutes() {
        return ceilDuration(recentVisitGraceMillis, TimeUnit.MINUTES);
    }

    public long getRecentVisitGraceMillis() {
        return recentVisitGraceMillis;
    }

    public boolean isTpsThrottleEnabled() {
        return tpsThrottleEnabled;
    }

    public double getMinimumTps() {
        return minimumTps;
    }

    public int getInspectNearbyRadiusChunks() {
        return inspectNearbyRadiusChunks;
    }

    public String getDatabaseFileName() {
        return databaseFileName;
    }

    private static int ceilDuration(long millis, TimeUnit unit) {
        if (millis <= 0L) {
            return 0;
        }
        long unitMillis = unit.toMillis(1L);
        long value = ((millis - 1L) / unitMillis) + 1L;
        return value > Integer.MAX_VALUE ? Integer.MAX_VALUE : (int) value;
    }

    private static String formatDuration(long millis) {
        if (millis <= 0L) {
            return "0s";
        }

        StringBuilder builder = new StringBuilder();
        long remaining = millis;
        remaining = appendUnit(builder, remaining, TimeUnit.DAYS.toMillis(1L), "d");
        remaining = appendUnit(builder, remaining, TimeUnit.HOURS.toMillis(1L), "h");
        remaining = appendUnit(builder, remaining, TimeUnit.MINUTES.toMillis(1L), "m");
        appendUnit(builder, remaining, TimeUnit.SECONDS.toMillis(1L), "s");
        if (builder.length() == 0) {
            return "1s";
        }
        return builder.toString();
    }

    private static long appendUnit(StringBuilder builder, long millis, long unitMillis, String suffix) {
        long amount = millis / unitMillis;
        if (amount > 0L) {
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(amount).append(suffix);
        }
        return millis - amount * unitMillis;
    }
}
