package dev.alexroper.chunkoptimizer.core.service;

import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;

import java.util.List;

public final class ChunkManagementService {
    private final OptimizerStorage storage;
    private final OptimizerLogger logger;

    public ChunkManagementService(OptimizerStorage storage, OptimizerLogger logger) {
        this.storage = storage;
        this.logger = logger;
    }

    public void whitelistChunk(ChunkKey key, String reason, String addedBy) {
        String cleanReason = normalize(reason, "manual whitelist");
        String cleanAddedBy = normalize(addedBy, "unknown");
        storage.addWhitelistedChunk(key, cleanReason, cleanAddedBy, System.currentTimeMillis());
        storage.removeQueuedChunk(key);
        logger.info("Whitelisted chunk " + key + " by " + cleanAddedBy + " (" + cleanReason + ").");
    }

    public int whitelistChunks(List<ChunkKey> keys, String reason, String addedBy) {
        if (keys == null || keys.isEmpty()) {
            return 0;
        }
        String cleanReason = normalize(reason, "manual whitelist");
        String cleanAddedBy = normalize(addedBy, "unknown");
        long now = System.currentTimeMillis();
        for (ChunkKey key : keys) {
            storage.addWhitelistedChunk(key, cleanReason, cleanAddedBy, now);
            storage.removeQueuedChunk(key);
        }
        logger.info("Whitelisted " + keys.size() + " chunks by " + cleanAddedBy + " (" + cleanReason + ").");
        return keys.size();
    }

    public void removeWhitelistedChunk(ChunkKey key, String actor) {
        storage.removeWhitelistedChunk(key);
        logger.info("Removed chunk " + key + " from whitelist by " + normalize(actor, "unknown") + ".");
    }

    public void removeFromQueue(ChunkKey key, String actor) {
        storage.removeQueuedChunk(key);
        logger.info("Removed chunk " + key + " from queue by " + normalize(actor, "unknown") + ".");
    }

    public boolean queueChunk(ChunkKey key, String reason, String actor) {
        long now = System.currentTimeMillis();
        boolean queued = storage.enqueueChunk(key, now, now, normalize(reason, "manual queue by " + normalize(actor, "unknown")));
        if (queued) {
            logger.info("Queued chunk " + key + " by " + normalize(actor, "unknown") + ".");
        }
        return queued;
    }

    private String normalize(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) {
            return fallback;
        }
        return value.trim();
    }
}
