package dev.alexroper.chunkoptimizer.core.protection;

import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ProtectionService {
    private final List<ProtectionChecker> checkers;
    private final OptimizerConfig config;
    private final OptimizerLogger logger;

    public ProtectionService(List<ProtectionChecker> checkers, OptimizerConfig config, OptimizerLogger logger) {
        this.checkers = Collections.unmodifiableList(new ArrayList<ProtectionChecker>(checkers));
        this.config = config;
        this.logger = logger;
    }

    public ProtectionResult check(ChunkKey key) {
        for (ProtectionChecker checker : checkers) {
            ProtectionResult result;
            try {
                result = checker.check(key);
            } catch (Throwable throwable) {
                logger.warn("Protection checker " + checker.getName() + " failed for " + key + ". Failing closed.", throwable);
                return ProtectionResult.protectedChunk(checker.getName() + " failed closed");
            }

            if (result.isProtectedChunk()) {
                logger.debug("Chunk " + key + " protected by " + checker.getName() + ": " + result.getReason());
                return result;
            }
            if (result.isUnknown() && config.isExternalProtectionFailClosed()) {
                logger.warn("Protection checker " + checker.getName() + " could not classify " + key + ". Treating it as protected.");
                return ProtectionResult.protectedChunk(checker.getName() + " unknown");
            }
        }
        return ProtectionResult.unprotected();
    }
}
