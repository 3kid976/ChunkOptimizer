package dev.alexroper.chunkoptimizer.core.config;

import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ConfigDurationParser {
    private static final Pattern DURATION_PATTERN = Pattern.compile("^(-?[0-9]+(?:\\.[0-9]+)?)\\s*([a-zA-Z]*)$");

    private ConfigDurationParser() {
    }

    public static long parseMillis(Object rawValue, long defaultAmount, TimeUnit defaultUnit, long minimumMillis) {
        long defaultMillis = safeMillis(defaultAmount, defaultUnit);
        long parsedMillis = parseMillis(rawValue, defaultMillis, defaultUnit);
        return Math.max(minimumMillis, parsedMillis);
    }

    private static long parseMillis(Object rawValue, long defaultMillis, TimeUnit defaultUnit) {
        if (rawValue == null) {
            return defaultMillis;
        }
        if (rawValue instanceof Number) {
            return multiply(((Number) rawValue).doubleValue(), defaultUnit.toMillis(1L), defaultMillis);
        }
        if (rawValue instanceof String) {
            return parseString((String) rawValue, defaultMillis, defaultUnit);
        }
        return defaultMillis;
    }

    private static long parseString(String rawValue, long defaultMillis, TimeUnit defaultUnit) {
        String value = rawValue == null ? "" : rawValue.trim();
        if (value.isEmpty()) {
            return defaultMillis;
        }

        Matcher matcher = DURATION_PATTERN.matcher(value);
        if (!matcher.matches()) {
            return defaultMillis;
        }

        double amount;
        try {
            amount = Double.parseDouble(matcher.group(1));
        } catch (NumberFormatException e) {
            return defaultMillis;
        }

        long unitMillis = unitMillis(matcher.group(2), defaultUnit);
        if (unitMillis < 0L) {
            return defaultMillis;
        }
        return multiply(amount, unitMillis, defaultMillis);
    }

    private static long unitMillis(String unit, TimeUnit defaultUnit) {
        if (unit == null || unit.trim().isEmpty()) {
            return defaultUnit.toMillis(1L);
        }

        String normalized = unit.trim().toLowerCase(Locale.ROOT);
        if ("ms".equals(normalized) || "millisecond".equals(normalized) || "milliseconds".equals(normalized)) {
            return 1L;
        }
        if ("s".equals(normalized) || "sec".equals(normalized) || "secs".equals(normalized)
                || "second".equals(normalized) || "seconds".equals(normalized)) {
            return TimeUnit.SECONDS.toMillis(1L);
        }
        if ("m".equals(normalized) || "min".equals(normalized) || "mins".equals(normalized)
                || "minute".equals(normalized) || "minutes".equals(normalized)) {
            return TimeUnit.MINUTES.toMillis(1L);
        }
        if ("h".equals(normalized) || "hr".equals(normalized) || "hrs".equals(normalized)
                || "hour".equals(normalized) || "hours".equals(normalized)) {
            return TimeUnit.HOURS.toMillis(1L);
        }
        if ("d".equals(normalized) || "day".equals(normalized) || "days".equals(normalized)) {
            return TimeUnit.DAYS.toMillis(1L);
        }
        return -1L;
    }

    private static long multiply(double amount, long unitMillis, long fallbackMillis) {
        double millis = amount * (double) unitMillis;
        if (Double.isNaN(millis)) {
            return fallbackMillis;
        }
        if (millis >= Long.MAX_VALUE) {
            return Long.MAX_VALUE;
        }
        if (millis <= Long.MIN_VALUE) {
            return Long.MIN_VALUE;
        }
        return Math.round(millis);
    }

    private static long safeMillis(long amount, TimeUnit unit) {
        return unit.toMillis(amount);
    }
}
