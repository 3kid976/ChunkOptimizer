package dev.alexroper.chunkoptimizer.core.model;

import dev.alexroper.chunkoptimizer.core.protection.ProtectionResult;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class ChunkInspection {
    private final ChunkKey key;
    private final long lastVisitedAt;
    private final QueuedChunk queuedChunk;
    private final boolean whitelisted;
    private final boolean worldEnabled;
    private final boolean worldAvailable;
    private final boolean chunkLoaded;
    private final boolean spawnProtected;
    private final int nearbyPlayers;
    private final boolean recentActivity;
    private final boolean cooldownActive;
    private final long cooldownRemainingMillis;
    private final boolean tpsThrottled;
    private final double currentTps;
    private final boolean dryRunMode;
    private final ProtectionResult protectionResult;
    private final List<String> blockers;
    private final List<String> nearbyProtections;

    public ChunkInspection(
            ChunkKey key,
            long lastVisitedAt,
            QueuedChunk queuedChunk,
            boolean whitelisted,
            boolean worldEnabled,
            boolean worldAvailable,
            boolean chunkLoaded,
            boolean spawnProtected,
            int nearbyPlayers,
            boolean recentActivity,
            boolean cooldownActive,
            long cooldownRemainingMillis,
            boolean tpsThrottled,
            double currentTps,
            boolean dryRunMode,
            ProtectionResult protectionResult,
            List<String> blockers,
            List<String> nearbyProtections) {
        this.key = key;
        this.lastVisitedAt = lastVisitedAt;
        this.queuedChunk = queuedChunk;
        this.whitelisted = whitelisted;
        this.worldEnabled = worldEnabled;
        this.worldAvailable = worldAvailable;
        this.chunkLoaded = chunkLoaded;
        this.spawnProtected = spawnProtected;
        this.nearbyPlayers = Math.max(0, nearbyPlayers);
        this.recentActivity = recentActivity;
        this.cooldownActive = cooldownActive;
        this.cooldownRemainingMillis = Math.max(0L, cooldownRemainingMillis);
        this.tpsThrottled = tpsThrottled;
        this.currentTps = currentTps;
        this.dryRunMode = dryRunMode;
        this.protectionResult = protectionResult == null ? ProtectionResult.unprotected() : protectionResult;
        this.blockers = immutableCopy(blockers);
        this.nearbyProtections = immutableCopy(nearbyProtections);
    }

    private static List<String> immutableCopy(List<String> values) {
        if (values == null || values.isEmpty()) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList<String>(values));
    }

    public ChunkKey getKey() {
        return key;
    }

    public long getLastVisitedAt() {
        return lastVisitedAt;
    }

    public QueuedChunk getQueuedChunk() {
        return queuedChunk;
    }

    public boolean isQueued() {
        return queuedChunk != null && queuedChunk.getState() == QueueState.QUEUED;
    }

    public boolean isWhitelisted() {
        return whitelisted;
    }

    public boolean isWorldEnabled() {
        return worldEnabled;
    }

    public boolean isWorldAvailable() {
        return worldAvailable;
    }

    public boolean isChunkLoaded() {
        return chunkLoaded;
    }

    public boolean isSpawnProtected() {
        return spawnProtected;
    }

    public int getNearbyPlayers() {
        return nearbyPlayers;
    }

    public boolean hasRecentActivity() {
        return recentActivity;
    }

    public boolean isCooldownActive() {
        return cooldownActive;
    }

    public long getCooldownRemainingMillis() {
        return cooldownRemainingMillis;
    }

    public boolean isTpsThrottled() {
        return tpsThrottled;
    }

    public double getCurrentTps() {
        return currentTps;
    }

    public boolean isDryRunMode() {
        return dryRunMode;
    }

    public ProtectionResult getProtectionResult() {
        return protectionResult;
    }

    public List<String> getBlockers() {
        return blockers;
    }

    public List<String> getNearbyProtections() {
        return nearbyProtections;
    }

    public boolean isProtectedChunk() {
        return !blockers.isEmpty();
    }

    public boolean canDelete() {
        return blockers.isEmpty();
    }
}
