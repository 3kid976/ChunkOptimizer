package dev.alexroper.chunkoptimizer.core.model;

public final class WhitelistedChunk {
    private final ChunkKey key;
    private final String reason;
    private final String addedBy;
    private final long createdAt;

    public WhitelistedChunk(ChunkKey key, String reason, String addedBy, long createdAt) {
        this.key = key;
        this.reason = reason;
        this.addedBy = addedBy;
        this.createdAt = createdAt;
    }

    public ChunkKey getKey() {
        return key;
    }

    public String getReason() {
        return reason;
    }

    public String getAddedBy() {
        return addedBy;
    }

    public long getCreatedAt() {
        return createdAt;
    }
}
