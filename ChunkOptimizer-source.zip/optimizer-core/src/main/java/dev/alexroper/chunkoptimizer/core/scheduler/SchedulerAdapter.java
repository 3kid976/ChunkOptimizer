package dev.alexroper.chunkoptimizer.core.scheduler;

import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

public interface SchedulerAdapter {
    void runAsync(Runnable runnable);

    void runSync(Runnable runnable);

    boolean isPrimaryThread();

    default <T> CompletableFuture<T> callSync(final Supplier<T> supplier) {
        final CompletableFuture<T> future = new CompletableFuture<T>();
        if (isPrimaryThread()) {
            try {
                future.complete(supplier.get());
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
            }
            return future;
        }
        runSync(() -> {
            try {
                future.complete(supplier.get());
            } catch (Throwable throwable) {
                future.completeExceptionally(throwable);
            }
        });
        return future;
    }

    ScheduledTaskHandle runRepeatingAsync(Runnable runnable, long initialDelayMillis, long periodMillis);
}
