package dev.alexroper.chunkoptimizer.core.queue;

import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;

public final class ChunkQueueService {
    private final OptimizerStorage storage;
    private final OptimizerLogger logger;

    public ChunkQueueService(OptimizerStorage storage, OptimizerLogger logger) {
        this.storage = storage;
        this.logger = logger;
    }

    public boolean queue(ChunkKey key, long inactiveSince, String reason) {
        boolean queued = storage.enqueueChunk(key, inactiveSince, System.currentTimeMillis(), reason);
        if (queued) {
            logger.debug("Queued inactive chunk " + key + " (" + reason + ").");
        }
        return queued;
    }
}
