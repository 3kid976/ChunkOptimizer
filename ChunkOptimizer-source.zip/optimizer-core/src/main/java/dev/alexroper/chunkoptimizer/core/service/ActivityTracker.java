package dev.alexroper.chunkoptimizer.core.service;

import dev.alexroper.chunkoptimizer.core.api.ChunkVisitTracker;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.PendingVisit;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

public final class ActivityTracker implements ChunkVisitTracker {
    private final OptimizerStorage storage;
    private final OptimizerConfig config;
    private final OptimizerLogger logger;
    private final ConcurrentMap<ChunkKey, PendingVisit> pendingVisits = new ConcurrentHashMap<ChunkKey, PendingVisit>();

    public ActivityTracker(OptimizerStorage storage, OptimizerConfig config, OptimizerLogger logger) {
        this.storage = storage;
        this.config = config;
        this.logger = logger;
    }

    public void markVisited(ChunkKey key) {
        if (!config.isWorldEnabled(key.getWorld())) {
            return;
        }
        final long now = System.currentTimeMillis();
        pendingVisits.compute(key, (ignored, current) -> current == null ? new PendingVisit(now, 1) : current.merge(now));
    }

    public void flush() {
        Map<ChunkKey, PendingVisit> snapshot = drainPendingVisits();
        if (snapshot.isEmpty()) {
            return;
        }
        try {
            storage.recordVisits(snapshot);
            logger.debug("Flushed " + snapshot.size() + " chunk activity records.");
        } catch (RuntimeException e) {
            restorePendingVisits(snapshot);
            throw e;
        }
    }

    private Map<ChunkKey, PendingVisit> drainPendingVisits() {
        Map<ChunkKey, PendingVisit> snapshot = new HashMap<ChunkKey, PendingVisit>();
        for (Map.Entry<ChunkKey, PendingVisit> entry : pendingVisits.entrySet()) {
            if (pendingVisits.remove(entry.getKey(), entry.getValue())) {
                snapshot.put(entry.getKey(), entry.getValue());
            }
        }
        return snapshot;
    }

    private void restorePendingVisits(Map<ChunkKey, PendingVisit> snapshot) {
        for (Map.Entry<ChunkKey, PendingVisit> entry : snapshot.entrySet()) {
            final PendingVisit original = entry.getValue();
            pendingVisits.merge(entry.getKey(), original, (left, right) -> {
                long newest = Math.max(left.getLastVisitedAt(), right.getLastVisitedAt());
                return new PendingVisit(newest, left.getVisitCount() + right.getVisitCount());
            });
        }
    }

    public int getPendingVisitCount() {
        return pendingVisits.size();
    }
}
