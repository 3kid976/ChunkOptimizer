package dev.alexroper.chunkoptimizer.core.protection;

import dev.alexroper.chunkoptimizer.core.api.ChunkAccess;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;

public final class EndIslandProtectionChecker implements ProtectionChecker {
    private final ChunkAccess chunkAccess;
    private final OptimizerConfig config;

    public EndIslandProtectionChecker(ChunkAccess chunkAccess, OptimizerConfig config) {
        this.chunkAccess = chunkAccess;
        this.config = config;
    }

    @Override
    public String getName() {
        return "end-island";
    }

    @Override
    public ProtectionResult check(ChunkKey key) {
        int radius = config.getEndIslandProtectionRadius();
        if (radius <= 0 || !chunkAccess.isEndWorld(key.getWorld())) {
            return ProtectionResult.unprotected();
        }
        if (chunkIntersectsOriginCircle(key.getX(), key.getZ(), radius)) {
            return ProtectionResult.protectedChunk("inside configured End island radius");
        }
        return ProtectionResult.unprotected();
    }

    private boolean chunkIntersectsOriginCircle(int chunkX, int chunkZ, int radius) {
        int minX = chunkX << 4;
        int maxX = minX + 15;
        int minZ = chunkZ << 4;
        int maxZ = minZ + 15;
        int closestX = clamp(0, minX, maxX);
        int closestZ = clamp(0, minZ, maxZ);
        long distanceSquared = (long) closestX * (long) closestX + (long) closestZ * (long) closestZ;
        return distanceSquared <= (long) radius * (long) radius;
    }

    private int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }
}
