package dev.alexroper.chunkoptimizer.core.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class PagedResult<T> {
    private final List<T> items;
    private final int totalItems;
    private final int page;
    private final int pageSize;

    public PagedResult(List<T> items, int totalItems, int page, int pageSize) {
        this.items = Collections.unmodifiableList(new ArrayList<T>(items));
        this.totalItems = Math.max(0, totalItems);
        this.page = Math.max(0, page);
        this.pageSize = Math.max(1, pageSize);
    }

    public List<T> getItems() {
        return items;
    }

    public int getTotalItems() {
        return totalItems;
    }

    public int getPage() {
        return page;
    }

    public int getPageSize() {
        return pageSize;
    }

    public int getTotalPages() {
        if (totalItems == 0) {
            return 1;
        }
        return (totalItems + pageSize - 1) / pageSize;
    }

    public boolean hasPreviousPage() {
        return page > 0;
    }

    public boolean hasNextPage() {
        return page + 1 < getTotalPages();
    }
}
