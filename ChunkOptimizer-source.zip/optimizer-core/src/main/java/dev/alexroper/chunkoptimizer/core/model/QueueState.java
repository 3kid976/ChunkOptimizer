package dev.alexroper.chunkoptimizer.core.model;

public enum QueueState {
    QUEUED,
    DELETING,
    DELETED,
    SKIPPED,
    FAILED
}
