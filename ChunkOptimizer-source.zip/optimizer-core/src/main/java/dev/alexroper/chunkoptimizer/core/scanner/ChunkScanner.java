package dev.alexroper.chunkoptimizer.core.scanner;

import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkInspection;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.InactiveChunk;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import dev.alexroper.chunkoptimizer.core.model.ScanResult;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;
import dev.alexroper.chunkoptimizer.core.queue.ChunkQueueService;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;
import dev.alexroper.chunkoptimizer.core.service.ActivityTracker;
import dev.alexroper.chunkoptimizer.core.service.ChunkSafetyService;

import java.util.List;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ChunkScanner {
    private final OptimizerConfig config;
    private final OptimizerStorage storage;
    private final ActivityTracker activityTracker;
    private final ChunkSafetyService safetyService;
    private final ChunkQueueService queueService;
    private final SchedulerAdapter scheduler;
    private final OptimizerLogger logger;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public ChunkScanner(
            OptimizerConfig config,
            OptimizerStorage storage,
            ActivityTracker activityTracker,
            ChunkSafetyService safetyService,
            ChunkQueueService queueService,
            SchedulerAdapter scheduler,
            OptimizerLogger logger) {
        this.config = config;
        this.storage = storage;
        this.activityTracker = activityTracker;
        this.safetyService = safetyService;
        this.queueService = queueService;
        this.scheduler = scheduler;
        this.logger = logger;
    }

    public ScanResult scanNow() {
        if (!running.compareAndSet(false, true)) {
            logger.debug("Scan request ignored because another scan is still running.");
            return new ScanResult(0, 0, 0, 0, 0L);
        }

        long startedAt = System.currentTimeMillis();
        int queued = 0;
        int protectedChunks = 0;
        int skipped = 0;
        List<InactiveChunk> candidates = Collections.emptyList();
        try {
            activityTracker.flush();
            long cutoff = System.currentTimeMillis() - config.getInactivityMillis();
            candidates = storage.findInactiveChunks(config.getEnabledWorlds(), cutoff, config.getChunksPerCycle());
            for (InactiveChunk candidate : candidates) {
                ChunkKey key = candidate.getKey();
                QueuedChunk queuedChunk = storage.getQueuedChunk(key);
                boolean whitelisted = storage.isWhitelisted(key);
                ChunkInspection inspection = scheduler.callSync(() -> safetyService.inspectSync(
                        key,
                        candidate.getLastVisitedAt(),
                        queuedChunk,
                        whitelisted,
                        false,
                        0L)).join();
                if (!inspection.isWorldEnabled() || !inspection.isWorldAvailable()) {
                    skipped++;
                    continue;
                }

                if (inspection.isProtectedChunk()) {
                    protectedChunks++;
                    continue;
                }

                if (!config.isAutoQueue()) {
                    skipped++;
                    continue;
                }

                if (queueService.queue(key, candidate.getLastVisitedAt(), "inactive for " + config.getInactivityDurationLabel())) {
                    queued++;
                } else {
                    skipped++;
                }
            }
        } finally {
            running.set(false);
        }

        long duration = System.currentTimeMillis() - startedAt;
        ScanResult result = new ScanResult(candidates.size(), queued, protectedChunks, skipped, duration);
        logger.info("Scan complete: " + queued + " queued, " + protectedChunks + " protected, " + skipped + " skipped from " + candidates.size() + " candidates in " + duration + "ms.");
        return result;
    }
}
