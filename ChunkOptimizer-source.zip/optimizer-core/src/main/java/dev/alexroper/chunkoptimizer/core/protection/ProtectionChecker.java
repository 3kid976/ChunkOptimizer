package dev.alexroper.chunkoptimizer.core.protection;

import dev.alexroper.chunkoptimizer.core.model.ChunkKey;

public interface ProtectionChecker {
    String getName();

    ProtectionResult check(ChunkKey key);
}
