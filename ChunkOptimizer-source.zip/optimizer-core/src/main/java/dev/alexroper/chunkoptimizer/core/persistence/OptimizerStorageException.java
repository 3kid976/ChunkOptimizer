package dev.alexroper.chunkoptimizer.core.persistence;

public final class OptimizerStorageException extends RuntimeException {
    public OptimizerStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
