package dev.alexroper.chunkoptimizer.core.model;

public final class QueueStats {
    private final int queued;
    private final int deleting;
    private final int deleted;
    private final int skipped;
    private final int failed;
    private final int auditRecords;

    public QueueStats(int queued, int deleting, int deleted, int skipped, int failed, int auditRecords) {
        this.queued = Math.max(0, queued);
        this.deleting = Math.max(0, deleting);
        this.deleted = Math.max(0, deleted);
        this.skipped = Math.max(0, skipped);
        this.failed = Math.max(0, failed);
        this.auditRecords = Math.max(0, auditRecords);
    }

    public int getQueued() {
        return queued;
    }

    public int getDeleting() {
        return deleting;
    }

    public int getDeleted() {
        return deleted;
    }

    public int getSkipped() {
        return skipped;
    }

    public int getFailed() {
        return failed;
    }

    public int getAuditRecords() {
        return auditRecords;
    }
}
