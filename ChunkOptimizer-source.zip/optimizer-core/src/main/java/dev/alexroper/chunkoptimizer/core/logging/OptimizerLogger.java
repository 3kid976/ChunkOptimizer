package dev.alexroper.chunkoptimizer.core.logging;

public interface OptimizerLogger {
    void info(String message);

    void warn(String message);

    void warn(String message, Throwable throwable);

    void error(String message, Throwable throwable);

    void debug(String message);
}
