package dev.alexroper.chunkoptimizer.core.model;

public final class ChunkDeletionResult {
    private final ChunkKey key;
    private final boolean success;
    private final boolean postponed;
    private final String message;
    private final boolean dryRun;
    private final String rollbackData;

    private ChunkDeletionResult(ChunkKey key, boolean success, boolean postponed, String message) {
        this(key, success, postponed, message, false, null);
    }

    private ChunkDeletionResult(ChunkKey key, boolean success, boolean postponed, String message, boolean dryRun, String rollbackData) {
        this.key = key;
        this.success = success;
        this.postponed = postponed;
        this.message = message;
        this.dryRun = dryRun;
        this.rollbackData = rollbackData;
    }

    public static ChunkDeletionResult success(ChunkKey key, String message) {
        return new ChunkDeletionResult(key, true, false, message);
    }

    public static ChunkDeletionResult success(ChunkKey key, String message, String rollbackData) {
        return new ChunkDeletionResult(key, true, false, message, false, rollbackData);
    }

    public static ChunkDeletionResult dryRun(ChunkKey key, String message) {
        return new ChunkDeletionResult(key, true, false, message, true, null);
    }

    public static ChunkDeletionResult failure(ChunkKey key, String message) {
        return new ChunkDeletionResult(key, false, false, message);
    }

    public static ChunkDeletionResult postponed(ChunkKey key, String message) {
        return new ChunkDeletionResult(key, false, true, message);
    }

    public ChunkKey getKey() {
        return key;
    }

    public boolean isSuccess() {
        return success;
    }

    public boolean isPostponed() {
        return postponed;
    }

    public String getMessage() {
        return message;
    }

    public boolean isDryRun() {
        return dryRun;
    }

    public String getRollbackData() {
        return rollbackData;
    }
}
