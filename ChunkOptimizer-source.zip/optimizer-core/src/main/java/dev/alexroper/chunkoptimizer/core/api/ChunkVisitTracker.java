package dev.alexroper.chunkoptimizer.core.api;

import dev.alexroper.chunkoptimizer.core.model.ChunkKey;

public interface ChunkVisitTracker {
    void markVisited(ChunkKey key);

    void flush();

    int getPendingVisitCount();
}
