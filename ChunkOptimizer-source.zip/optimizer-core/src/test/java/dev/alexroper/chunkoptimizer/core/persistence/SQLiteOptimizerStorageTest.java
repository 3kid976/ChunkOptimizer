package dev.alexroper.chunkoptimizer.core.persistence;

import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.PendingVisit;
import dev.alexroper.chunkoptimizer.core.model.QueueState;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;

final class SQLiteOptimizerStorageTest {
    @TempDir
    Path tempDir;

    @Test
    void recordVisitsKeepsQueueWhenVisitPredatesQueue() {
        SQLiteOptimizerStorage storage = newStorage();
        try {
            ChunkKey key = new ChunkKey("world", 4, -2);
            storage.enqueueChunk(key, 1000L, 2000L, "manual force queue");

            Map<ChunkKey, PendingVisit> visits = new HashMap<ChunkKey, PendingVisit>();
            visits.put(key, new PendingVisit(1500L, 1));
            storage.recordVisits(visits);

            QueuedChunk queued = storage.getQueuedChunk(key);
            assertNotNull(queued);
            assertEquals(QueueState.QUEUED, queued.getState());
            assertEquals(2000L, queued.getQueuedAt());
        } finally {
            storage.close();
        }
    }

    @Test
    void recordVisitsRemovesQueueWhenVisitHappensAfterQueue() {
        SQLiteOptimizerStorage storage = newStorage();
        try {
            ChunkKey key = new ChunkKey("world", 4, -2);
            storage.enqueueChunk(key, 1000L, 2000L, "inactive");

            Map<ChunkKey, PendingVisit> visits = new HashMap<ChunkKey, PendingVisit>();
            visits.put(key, new PendingVisit(2500L, 1));
            storage.recordVisits(visits);

            assertNull(storage.getQueuedChunk(key));
        } finally {
            storage.close();
        }
    }

    private SQLiteOptimizerStorage newStorage() {
        SQLiteOptimizerStorage storage = new SQLiteOptimizerStorage(tempDir.resolve("chunkoptimizer.db").toFile());
        storage.initialize();
        return storage;
    }
}
