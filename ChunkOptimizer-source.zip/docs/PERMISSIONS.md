# Permissions

## `optimizer.view`

Default: `op`

Allows:

- `/optimizer`
- `/optimizer gui`
- `/optimizer queue`
- `/optimizer whitelist`
- `/optimizer stats`
- GUI queue and whitelist viewing

## `optimizer.admin`

Default: `op`

Includes all viewer access and allows:

- reloads
- scans and force starts
- dry-runs
- chunk inspection
- manual queueing
- deletion requests
- whitelist edits
- queue removals
- chunk teleport utilities
- debug diagnostics

Use `optimizer.admin` only for trusted operators. The plugin still enforces safety checks for deletion, but admin users can queue and request destructive workflows.
