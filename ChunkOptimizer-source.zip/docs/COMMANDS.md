# Commands

Base command: `/optimizer`

Aliases: `/chunkoptimizer`, `/coptimizer`

## Viewer Commands

`/optimizer`

Opens the GUI for players with `optimizer.view` or `optimizer.admin`.

`/optimizer gui`

Opens the main GUI.

`/optimizer queue`

Opens queued chunk categories.

`/optimizer whitelist`

Opens the whitelist GUI.

`/optimizer stats`

Shows tracked chunks, queued chunks, whitelist count, pending writes, and oldest visit.

## Admin Commands

`/optimizer reload`

Reloads config and rebuilds runtime services.

`/optimizer scan`

Starts an immediate inactive chunk scan.

`/optimizer forcestart`

Alias for an immediate scan.

`/optimizer dryrun [world chunk-x chunk-z]`

Builds a deletion preview. If a player omits coordinates, the current chunk is used.

`/optimizer inspectchunk [world chunk-x chunk-z]`

Shows last visit, queue status, whitelist status, protection blockers, nearby protections, player radius state, and TPS throttle state.

`/optimizer forcequeue <world> <chunk-x> <chunk-z> [reason]`

Adds a chunk to the persistent queue. Safety checks still run before any deletion.

Queued chunks are removed from the queue when player activity is recorded in that chunk after it was queued.

`/optimizer whitelist <world> <chunk-x> <chunk-z> [reason]`

Adds one chunk to the manual whitelist and removes it from the queue.

`/optimizer whitelist <world> r:<radius> confirm [reason]`

Adds chunks around the player's current chunk in the named world. `r:1` is only the chunk the player is standing in. Without `confirm`, the command shows how many chunks would be whitelisted and does not make changes.

`/optimizer deletechunk <world> <chunk-x> <chunk-z> [confirm]`

Requests a protected reset. Players receive a GUI confirmation. Console must append `confirm`.

`/optimizer tpchunk <world> <chunk-x> <chunk-z>`

Teleports the player to the center of a chunk.

`/optimizer debug`

Shows config status, schema version, hook presence, queue state counts, audit count, and tracking stats.
