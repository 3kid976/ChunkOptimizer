# Compatibility

## Modern Jar

Use `Optimizer-Modern.jar` on Paper 1.20+ with Java 21.

The modern build uses Paper APIs where available through version-safe reflection and falls back to Bukkit scheduling when needed.

## Legacy Jar

Use `Optimizer-Legacy.jar` on Paper/Spigot 1.12.x with Java 8.

The legacy build avoids modern-only APIs and safely skips TPS throttling when the server does not expose a compatible TPS method.

## Optional Plugins

WorldGuard and Lands are soft dependencies. ChunkOptimizer loads without either plugin installed.

When a supported hook is present:

- WorldGuard regions protect overlapping chunks.
- Lands claims protect claimed chunks.
- hook failures are treated as protected by default through `protection.external-fail-closed`.

## Storage

SQLite JDBC and SLF4J are shaded into both release jars under `dev.alexroper.chunkoptimizer.libs`.

Schema migrations run automatically on startup and are recorded in `schema_migrations`.

## Chunk Reset Method

ChunkOptimizer deletes the server's stored data for eligible chunks while the world stays online. The next normal chunk load then regenerates terrain from the world's active generator and seed.

Modern builds delete the chunk, entity, and POI storage records through the server's live storage layer. Legacy 1.12 builds clear the exact chunk entry from the cached Anvil region file. The plugin does not clone worlds, copy region files, or call deprecated chunk regeneration APIs.

Before deleting, the plugin rechecks player visibility, force-load state, plugin chunk tickets, and whether the server can unload the chunk without saving it. If the server keeps the chunk loaded, deletion is postponed.
