# Configuration

Generated file: `plugins/ChunkOptimizer/config.yml`

ChunkOptimizer works in two steps:

1. It remembers chunks that players visit.
2. It queues old chunks, then optionally deletes queued chunks after another waiting period.

Deletion means the stored chunk, entity, and POI data is removed. When Minecraft loads that chunk again, it generates fresh terrain from the world seed.

Time values use simple suffixes:

- `30s` means 30 seconds
- `10m` means 10 minutes
- `2h` means 2 hours
- `7d` means 7 days

## Main Settings

`worlds`

Worlds managed by the plugin. Use `[]` for every loaded world, or list exact Bukkit world names.

`inactive-after`

How long a chunk must go without a player visit before it can be queued.

`scan-every`

How often the plugin looks for inactive chunks.

`queue-inactive-chunks`

When true, inactive chunks are added to the queue. Queueing does not delete anything.

`auto-delete`

When true, the plugin can delete queued chunks after they wait long enough. Leave false while testing.

`delete-after-queued`

How long a chunk must sit in the queue before auto-delete may try it. Examples: `30m`, `2h`, `7d`.

`delete-check-every`

How often auto-delete checks the queue.

`max-deletes-per-check`

Maximum chunks auto-delete can reset each time it checks the queue.

`dry-run`

When true, deletion is previewed and audited but no chunk data is changed.

`player-safe-radius`

Do not delete chunks within this many chunks of an online player.

## Advanced

`max-chunks-per-scan`

Maximum inactive chunks inspected during each scan.

`save-visits-every`

How often player visits are saved to SQLite. If a player enters a chunk after it was queued, it disappears from the GUI after this save.

`delete-cooldown`

Extra wait between successful chunk resets.

`spawn-protection-radius`

Do not delete chunks near a world's spawn location.

`recent-visit-protection`

Do not delete chunks visited within this time, even if they are queued.

`end-island-protection-radius`

Do not delete chunks on the main End island, measured in blocks from `0,0`.

`pause-deletes-below-tps`

Set to `0` to ignore TPS. Otherwise, deletion pauses below this TPS.

## Protection Hooks

`protection-hooks.worldguard`

If WorldGuard is installed, WorldGuard regions protect chunks from deletion.

`protection-hooks.lands`

If Lands is installed, Lands claims protect chunks from deletion.

`protection-hooks.protect-if-hook-fails`

When true, a hook error treats the chunk as protected.

## Troubleshooting

`inspect-nearby-radius`

Nearby chunk radius shown by `/optimizer inspectchunk`.

`debug`

Enables extra console logging.

`database-file`

SQLite database file inside `plugins/ChunkOptimizer`.
