# Installation

## Choose the Correct Jar

- Paper 1.20+ on Java 21: `Optimizer-Modern.jar`
- Paper/Spigot 1.12.x on Java 8: `Optimizer-Legacy.jar`

Release jars are located in:

```text
build/release/
```

## Install

1. Stop the server.
2. Place the correct jar in the server `plugins/` directory.
3. Start the server.
4. Open `plugins/ChunkOptimizer/config.yml`.
5. Configure `worlds`, `inactive-after`, `dry-run`, and `player-safe-radius`.
6. Run `/optimizer debug`.
7. Run `/optimizer dryrun` and `/optimizer inspectchunk` on representative chunks.
8. Leave `auto-delete: false` until dry-run output matches your cleanup policy.

## Recommended Rollout

1. Start with `queue-inactive-chunks: true` and `auto-delete: false`.
2. Let the plugin collect activity for at least your intended inactivity window.
3. Review `/optimizer queue` and `/optimizer inspectchunk`.
4. Enable `dry-run: true` and `auto-delete: true` for a test maintenance period.
5. Review audit records and debug output.
6. Disable `dry-run` only after confirming the queue is correct.
