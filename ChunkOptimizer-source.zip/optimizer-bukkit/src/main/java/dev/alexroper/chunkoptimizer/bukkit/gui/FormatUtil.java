package dev.alexroper.chunkoptimizer.bukkit.gui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public final class FormatUtil {
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private FormatUtil() {
    }

    public static String timestamp(long timestamp) {
        if (timestamp <= 0L) {
            return "unknown";
        }
        synchronized (DATE_FORMAT) {
            return DATE_FORMAT.format(new Date(timestamp));
        }
    }

    public static String durationSince(long timestamp) {
        if (timestamp <= 0L) {
            return "unknown";
        }
        long millis = Math.max(0L, System.currentTimeMillis() - timestamp);
        long days = TimeUnit.MILLISECONDS.toDays(millis);
        if (days > 0L) {
            return days + "d " + (TimeUnit.MILLISECONDS.toHours(millis) % 24L) + "h";
        }
        long hours = TimeUnit.MILLISECONDS.toHours(millis);
        if (hours > 0L) {
            return hours + "h " + (TimeUnit.MILLISECONDS.toMinutes(millis) % 60L) + "m";
        }
        long minutes = TimeUnit.MILLISECONDS.toMinutes(millis);
        if (minutes > 0L) {
            return minutes + "m";
        }
        return "less than 1m";
    }
}
