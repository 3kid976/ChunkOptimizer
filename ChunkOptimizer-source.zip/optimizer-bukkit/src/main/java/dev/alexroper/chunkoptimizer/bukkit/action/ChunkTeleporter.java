package dev.alexroper.chunkoptimizer.bukkit.action;

import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;

public final class ChunkTeleporter {
    private ChunkTeleporter() {
    }

    public static boolean teleport(Player player, ChunkKey key) {
        World world = Bukkit.getWorld(key.getWorld());
        if (world == null) {
            player.sendMessage(ChatColor.RED + "World is not loaded: " + key.getWorld());
            return false;
        }

        int blockX = (key.getX() << 4) + 8;
        int blockZ = (key.getZ() << 4) + 8;
        int blockY;
        try {
            blockY = world.getHighestBlockYAt(blockX, blockZ) + 1;
        } catch (RuntimeException e) {
            blockY = world.getSpawnLocation().getBlockY();
        }
        Location location = new Location(world, blockX + 0.5D, blockY, blockZ + 0.5D);
        return player.teleport(location);
    }
}
