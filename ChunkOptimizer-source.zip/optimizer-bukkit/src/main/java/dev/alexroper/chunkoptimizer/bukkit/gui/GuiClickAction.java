package dev.alexroper.chunkoptimizer.bukkit.gui;

import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;

public interface GuiClickAction {
    void click(Player player, ClickType clickType);
}
