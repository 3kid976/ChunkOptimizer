package dev.alexroper.chunkoptimizer.bukkit.gui;

import org.bukkit.inventory.ItemStack;

public final class GuiItems {
    private GuiItems() {
    }

    public static ItemStack filler() {
        return ItemBuilder.of(MaterialUtil.item("GRAY_STAINED_GLASS_PANE", "STAINED_GLASS_PANE", 7))
                .name(" ")
                .build();
    }

    public static ItemStack darkFiller() {
        return ItemBuilder.of(MaterialUtil.item("BLACK_STAINED_GLASS_PANE", "STAINED_GLASS_PANE", 15))
                .name(" ")
                .build();
    }

    public static ItemStack back() {
        return ItemBuilder.of(MaterialUtil.item("ARROW", "ARROW"))
                .name("&eBack")
                .lore("&7Return to the previous menu.")
                .build();
    }

    public static ItemStack previousPage() {
        return ItemBuilder.of(MaterialUtil.item("ARROW", "ARROW"))
                .name("&ePrevious Page")
                .build();
    }

    public static ItemStack nextPage() {
        return ItemBuilder.of(MaterialUtil.item("ARROW", "ARROW"))
                .name("&eNext Page")
                .build();
    }

    public static ItemStack close() {
        return ItemBuilder.of(MaterialUtil.item("BARRIER", "BARRIER"))
                .name("&cClose")
                .build();
    }

    public static ItemStack pageInfo(int page, int totalPages, int totalItems) {
        return ItemBuilder.of(MaterialUtil.item("PAPER", "PAPER"))
                .name("&fPage &e" + (page + 1) + "&7/&e" + totalPages)
                .lore("&7Entries: &f" + totalItems)
                .build();
    }

    public static ItemStack loading() {
        return ItemBuilder.of(MaterialUtil.item("CLOCK", "WATCH"))
                .name("&eLoading...")
                .lore("&7Fetching cached chunk data.")
                .build();
    }
}
