package dev.alexroper.chunkoptimizer.bukkit.gui;

import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.util.ArrayList;
import java.util.List;

public enum WorldCategory {
    OVERWORLD("Overworld", World.Environment.NORMAL),
    NETHER("Nether", World.Environment.NETHER),
    END("End", World.Environment.THE_END);

    private final String displayName;
    private final World.Environment environment;

    WorldCategory(String displayName, World.Environment environment) {
        this.displayName = displayName;
        this.environment = environment;
    }

    public String getDisplayName() {
        return displayName;
    }

    public World.Environment getEnvironment() {
        return environment;
    }

    public List<String> getLoadedWorldNames(OptimizerConfig config) {
        List<String> names = new ArrayList<String>();
        for (World world : Bukkit.getWorlds()) {
            if (world.getEnvironment() == environment && (config == null || config.isWorldEnabled(world.getName()))) {
                names.add(world.getName());
            }
        }
        return names;
    }

    public static WorldCategory fromName(String value) {
        if (value == null) {
            return null;
        }
        for (WorldCategory category : values()) {
            if (category.name().equalsIgnoreCase(value) || category.displayName.equalsIgnoreCase(value)) {
                return category;
            }
        }
        return null;
    }
}
