package dev.alexroper.chunkoptimizer.bukkit.gui;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

public final class GuiMenu {
    private final String title;
    private final int size;
    private final Map<Integer, ItemStack> items = new HashMap<Integer, ItemStack>();
    private final Map<Integer, GuiClickAction> actions = new HashMap<Integer, GuiClickAction>();

    public GuiMenu(String title, int size) {
        this.title = title;
        this.size = size;
    }

    public void setItem(int slot, ItemStack item) {
        setItem(slot, item, null);
    }

    public void setItem(int slot, ItemStack item, GuiClickAction action) {
        if (slot < 0 || slot >= size) {
            return;
        }
        items.put(Integer.valueOf(slot), item);
        if (action != null) {
            actions.put(Integer.valueOf(slot), action);
        }
    }

    public Inventory createInventory() {
        OptimizerInventoryHolder holder = new OptimizerInventoryHolder(this);
        Inventory inventory = Bukkit.createInventory(holder, size, title);
        holder.setInventory(inventory);
        for (Map.Entry<Integer, ItemStack> entry : items.entrySet()) {
            inventory.setItem(entry.getKey().intValue(), entry.getValue());
        }
        return inventory;
    }

    public void handleClick(Player player, int rawSlot, ClickType clickType) {
        GuiClickAction action = actions.get(Integer.valueOf(rawSlot));
        if (action != null) {
            action.click(player, clickType);
        } else {
            SoundUtil.fail(player);
        }
    }
}
