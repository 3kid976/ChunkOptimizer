package dev.alexroper.chunkoptimizer.bukkit;

import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.persistence.OptimizerStorage;
import dev.alexroper.chunkoptimizer.core.service.ChunkDeletionService;
import dev.alexroper.chunkoptimizer.core.service.ChunkManagementService;
import dev.alexroper.chunkoptimizer.core.service.ChunkOptimizerEngine;
import dev.alexroper.chunkoptimizer.core.service.ChunkSafetyService;
import org.bukkit.plugin.java.JavaPlugin;

public interface BukkitOptimizerPlugin {
    JavaPlugin getJavaPlugin();

    OptimizerConfig getOptimizerConfig();

    OptimizerStorage getStorage();

    ChunkOptimizerEngine getEngine();

    ChunkDeletionService getDeletionService();

    ChunkSafetyService getSafetyService();

    ChunkManagementService getManagementService();

    OptimizerLogger getOptimizerLogger();

    void reloadOptimizer();

    void runAsync(Runnable runnable);

    void runSync(Runnable runnable);
}
