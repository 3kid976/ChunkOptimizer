package dev.alexroper.chunkoptimizer.bukkit.config;

import dev.alexroper.chunkoptimizer.core.config.ConfigDurationParser;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.concurrent.TimeUnit;

public final class BukkitConfigLoader {
    private static final long MINIMUM_DURATION_MILLIS = TimeUnit.SECONDS.toMillis(1L);
    private static final long MINIMUM_VISIT_FLUSH_MILLIS = TimeUnit.SECONDS.toMillis(5L);

    private BukkitConfigLoader() {
    }

    public static OptimizerConfig load(JavaPlugin plugin) {
        FileConfiguration config = plugin.getConfig();
        return new OptimizerConfig(
                duration(config, 30, TimeUnit.DAYS, MINIMUM_DURATION_MILLIS, "inactive-after", "inactivity-days"),
                duration(config, 60, TimeUnit.MINUTES, MINIMUM_DURATION_MILLIS, "scan-every", "scan-interval-minutes"),
                integer(config, 250, "max-chunks-per-scan", "chunks-per-cycle"),
                stringList(config, "worlds", "enabled-worlds"),
                bool(config, true, "queue-inactive-chunks", "auto-queue"),
                bool(config, false, "auto-delete", "auto-delete-enabled"),
                duration(config, 7, TimeUnit.DAYS, MINIMUM_DURATION_MILLIS, "delete-after-queued", "auto-delete-delay", "auto-delete-delay-days"),
                duration(config, 10, TimeUnit.MINUTES, MINIMUM_DURATION_MILLIS, "delete-check-every", "auto-delete-interval-minutes"),
                integer(config, 5, "max-deletes-per-check", "auto-delete-batch-size"),
                integer(config, 256, "end-island-protection-radius", "protection.end-island-protection-radius"),
                bool(config, false, "debug", "diagnostics.debug-mode", "debug-mode"),
                duration(config, 30, TimeUnit.SECONDS, MINIMUM_VISIT_FLUSH_MILLIS, "save-visits-every", "visit-flush-interval-seconds"),
                bool(config, true, "protection-hooks.worldguard", "protection.worldguard"),
                bool(config, true, "protection-hooks.lands", "protection.lands"),
                bool(config, true, "protection-hooks.protect-if-hook-fails", "protection.external-fail-closed"),
                bool(config, false, "dry-run", "safety.dry-run"),
                duration(config, 10, TimeUnit.SECONDS, 0L, "delete-cooldown", "safety.deletion-cooldown-seconds"),
                integer(config, 3, "player-safe-radius", "safety.player-radius-chunks"),
                integer(config, 12, "spawn-protection-radius", "safety.spawn-radius-chunks"),
                duration(config, 30, TimeUnit.MINUTES, 0L, "recent-visit-protection", "safety.recent-visit-grace-minutes"),
                tpsThrottleEnabled(config),
                minimumTps(config),
                integer(config, 1, "inspect-nearby-radius", "diagnostics.inspect-nearby-radius-chunks"),
                string(config, "chunkoptimizer.db", "database-file", "database.file"));
    }

    private static long duration(FileConfiguration config, long defaultAmount, TimeUnit defaultUnit, long minimumMillis, String... paths) {
        Object value = firstSet(config, Long.valueOf(defaultAmount), paths);
        return ConfigDurationParser.parseMillis(value, defaultAmount, defaultUnit, minimumMillis);
    }

    private static boolean bool(FileConfiguration config, boolean defaultValue, String... paths) {
        for (String path : paths) {
            if (config.isSet(path)) {
                return config.getBoolean(path, defaultValue);
            }
        }
        return defaultValue;
    }

    private static int integer(FileConfiguration config, int defaultValue, String... paths) {
        for (String path : paths) {
            if (config.isSet(path)) {
                return config.getInt(path, defaultValue);
            }
        }
        return defaultValue;
    }

    private static double decimal(FileConfiguration config, double defaultValue, String... paths) {
        for (String path : paths) {
            if (config.isSet(path)) {
                return config.getDouble(path, defaultValue);
            }
        }
        return defaultValue;
    }

    private static String string(FileConfiguration config, String defaultValue, String... paths) {
        for (String path : paths) {
            if (config.isSet(path)) {
                return config.getString(path, defaultValue);
            }
        }
        return defaultValue;
    }

    private static List<String> stringList(FileConfiguration config, String... paths) {
        for (String path : paths) {
            if (config.isSet(path)) {
                return config.getStringList(path);
            }
        }
        return java.util.Collections.emptyList();
    }

    private static Object firstSet(FileConfiguration config, Object defaultValue, String... paths) {
        for (String path : paths) {
            if (config.isSet(path)) {
                return config.get(path);
            }
        }
        return defaultValue;
    }

    private static boolean tpsThrottleEnabled(FileConfiguration config) {
        if (config.isSet("pause-deletes-below-tps")) {
            return config.getDouble("pause-deletes-below-tps", 18.0D) > 0.0D;
        }
        return bool(config, true, "performance.tps-throttle-enabled");
    }

    private static double minimumTps(FileConfiguration config) {
        if (config.isSet("pause-deletes-below-tps")) {
            return Math.max(0.0D, config.getDouble("pause-deletes-below-tps", 18.0D));
        }
        return decimal(config, 18.0D, "performance.minimum-tps");
    }
}
