package dev.alexroper.chunkoptimizer.bukkit.gui;

import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;

public final class MaterialUtil {
    private MaterialUtil() {
    }

    public static ItemStack item(String modernName, String legacyName) {
        return item(modernName, legacyName, 0, 1);
    }

    public static ItemStack item(String modernName, String legacyName, int legacyData) {
        return item(modernName, legacyName, legacyData, 1);
    }

    public static ItemStack item(String modernName, String legacyName, int legacyData, int amount) {
        Material modern = match(modernName);
        if (modern != null) {
            return new ItemStack(modern, amount);
        }
        Material legacy = match(legacyName);
        if (legacy == null) {
            legacy = Material.STONE;
        }
        if (legacyData > 0) {
            return new ItemStack(legacy, amount, (short) legacyData);
        }
        return new ItemStack(legacy, amount);
    }

    private static Material match(String name) {
        if (name == null || name.trim().isEmpty()) {
            return null;
        }
        return Material.matchMaterial(name);
    }
}
