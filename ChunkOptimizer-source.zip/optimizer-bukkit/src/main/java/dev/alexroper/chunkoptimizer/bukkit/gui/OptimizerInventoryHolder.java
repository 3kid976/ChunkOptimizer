package dev.alexroper.chunkoptimizer.bukkit.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public final class OptimizerInventoryHolder implements InventoryHolder {
    private final GuiMenu menu;
    private Inventory inventory;

    public OptimizerInventoryHolder(GuiMenu menu) {
        this.menu = menu;
    }

    public GuiMenu getMenu() {
        return menu;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }
}
