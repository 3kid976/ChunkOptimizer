package dev.alexroper.chunkoptimizer.bukkit.gui;

import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ItemBuilder {
    private final ItemStack item;
    private String name;
    private final List<String> lore = new ArrayList<String>();

    private ItemBuilder(ItemStack item) {
        this.item = item;
    }

    public static ItemBuilder of(ItemStack item) {
        return new ItemBuilder(item);
    }

    public ItemBuilder name(String name) {
        this.name = color(name);
        return this;
    }

    public ItemBuilder lore(String... lines) {
        if (lines != null) {
            for (String line : Arrays.asList(lines)) {
                lore.add(color(line));
            }
        }
        return this;
    }

    public ItemBuilder lore(List<String> lines) {
        if (lines != null) {
            for (String line : lines) {
                lore.add(color(line));
            }
        }
        return this;
    }

    public ItemStack build() {
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            if (name != null) {
                meta.setDisplayName(name);
            }
            if (!lore.isEmpty()) {
                meta.setLore(lore);
            }
            item.setItemMeta(meta);
        }
        return item;
    }

    public static String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }
}
