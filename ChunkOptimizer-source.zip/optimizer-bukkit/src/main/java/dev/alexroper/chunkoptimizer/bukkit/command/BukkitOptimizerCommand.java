package dev.alexroper.chunkoptimizer.bukkit.command;

import dev.alexroper.chunkoptimizer.bukkit.BukkitOptimizerPlugin;
import dev.alexroper.chunkoptimizer.bukkit.action.ChunkTeleporter;
import dev.alexroper.chunkoptimizer.bukkit.gui.OptimizerGuiManager;
import dev.alexroper.chunkoptimizer.core.config.OptimizerConfig;
import dev.alexroper.chunkoptimizer.core.model.ChunkDeletionResult;
import dev.alexroper.chunkoptimizer.core.model.ChunkInspection;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.OptimizerStats;
import dev.alexroper.chunkoptimizer.core.model.QueueStats;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import dev.alexroper.chunkoptimizer.core.model.ScanResult;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class BukkitOptimizerCommand implements CommandExecutor, TabCompleter {
    private static final List<String> SUBCOMMANDS = Arrays.asList(
            "gui", "queue", "whitelist", "deletechunk", "tpchunk", "reload", "scan", "stats",
            "debug", "dryrun", "forcestart", "forcequeue", "inspectchunk");
    private static final int MAX_WHITELIST_RADIUS = 256;
    private static final String PREFIX = ChatColor.DARK_AQUA + "ChunkOptimizer " + ChatColor.GRAY + "» " + ChatColor.RESET;

    private final BukkitOptimizerPlugin plugin;
    private final OptimizerGuiManager guiManager;

    public BukkitOptimizerCommand(BukkitOptimizerPlugin plugin, OptimizerGuiManager guiManager) {
        this.plugin = plugin;
        this.guiManager = guiManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (sender instanceof Player && canView(sender)) {
                guiManager.openMain((Player) sender);
                return true;
            }
            sendUsage(sender, label);
            return true;
        }

        String subcommand = args[0].toLowerCase(Locale.ROOT);
        if ("gui".equals(subcommand)) {
            Player player = requirePlayer(sender);
            if (player != null && requireView(sender)) {
                guiManager.openMain(player);
            }
            return true;
        }

        if ("queue".equals(subcommand)) {
            Player player = requirePlayer(sender);
            if (player != null && requireView(sender)) {
                guiManager.openQueueCategories(player);
            }
            return true;
        }

        if ("whitelist".equals(subcommand)) {
            return handleWhitelist(sender, args);
        }

        if ("deletechunk".equals(subcommand)) {
            return handleDeleteChunk(sender, args);
        }

        if ("tpchunk".equals(subcommand)) {
            return handleTeleportChunk(sender, args);
        }

        if ("dryrun".equals(subcommand)) {
            return handleDryRun(sender, args);
        }

        if ("forcequeue".equals(subcommand)) {
            return handleForceQueue(sender, args);
        }

        if ("inspectchunk".equals(subcommand)) {
            return handleInspectChunk(sender, args);
        }

        if ("debug".equals(subcommand)) {
            return handleDebug(sender);
        }

        if ("reload".equals(subcommand)) {
            if (!requireAdmin(sender)) {
                return true;
            }
            plugin.reloadOptimizer();
            guiManager.clearCache();
            sender.sendMessage(PREFIX + ChatColor.GREEN + "Reloaded.");
            return true;
        }

        if ("scan".equals(subcommand) || "forcestart".equals(subcommand)) {
            return handleScan(sender);
        }

        if ("stats".equals(subcommand)) {
            if (!requireView(sender)) {
                return true;
            }
            plugin.runAsync(() -> {
                OptimizerStats stats = plugin.getEngine().getStats();
                plugin.runSync(() -> sendStats(sender, stats));
            });
            return true;
        }

        sendUsage(sender, label);
        return true;
    }

    private boolean handleWhitelist(CommandSender sender, String[] args) {
        if (args.length == 1) {
            Player player = requirePlayer(sender);
            if (player != null && requireView(sender)) {
                guiManager.openWhitelistPage(player, 0);
            }
            return true;
        }

        if (!requireAdmin(sender)) {
            return true;
        }
        if (args.length >= 3 && isRadiusToken(args[2])) {
            return handleWhitelistRadius(sender, args);
        }
        ChunkKey key = parseKey(sender, args, 1);
        if (key == null) {
            return true;
        }
        String reason = join(args, 4, "manual whitelist");
        String addedBy = sender instanceof Player ? sender.getName() : "console";
        plugin.runAsync(() -> {
            plugin.getManagementService().whitelistChunk(key, reason, addedBy);
            guiManager.clearCache();
            plugin.runSync(() -> sender.sendMessage(PREFIX + ChatColor.GREEN + "Whitelisted " + key + "."));
        });
        return true;
    }

    private boolean handleWhitelistRadius(CommandSender sender, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) {
            return true;
        }
        Location location = player.getLocation();
        if (location.getWorld() == null) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Could not resolve your current world.");
            return true;
        }
        Integer radius = parseRadius(sender, args[2]);
        if (radius == null) {
            return true;
        }
        String worldName = args[1];
        int centerX = location.getBlockX() >> 4;
        int centerZ = location.getBlockZ() >> 4;
        int chunkCount = countRadiusChunks(radius);
        if (args.length < 4 || !"confirm".equalsIgnoreCase(args[3])) {
            String reasonSuffix = args.length > 3 ? " " + join(args, 3, "") : "";
            sender.sendMessage(PREFIX + ChatColor.YELLOW + "Radius whitelist will add up to "
                    + chunkCount + " chunk" + (chunkCount == 1 ? "" : "s")
                    + " around " + worldName + "[" + centerX + "," + centerZ + "] with r:" + radius + ".");
            sender.sendMessage(PREFIX + ChatColor.RED + "Run /optimizer whitelist " + worldName
                    + " r:" + radius + " confirm" + reasonSuffix + " to confirm.");
            return true;
        }
        List<ChunkKey> keys = buildRadiusKeys(worldName, centerX, centerZ, radius);
        String reason = join(args, 4, "manual radius whitelist");
        String addedBy = player.getName();
        plugin.runAsync(() -> {
            int whitelisted = plugin.getManagementService().whitelistChunks(keys, reason, addedBy);
            if (whitelisted > 0) {
                guiManager.clearCache();
            }
            plugin.runSync(() -> sender.sendMessage(PREFIX + ChatColor.GREEN + "Whitelisted "
                    + whitelisted + " chunk" + (whitelisted == 1 ? "" : "s")
                    + " around " + worldName + "[" + centerX + "," + centerZ + "] with r:" + radius + "."));
        });
        return true;
    }

    private int countRadiusChunks(int radius) {
        int edgeDistance = radius - 1;
        int size = edgeDistance * 2 + 1;
        return size * size;
    }

    private boolean handleDeleteChunk(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        ChunkKey key = parseKey(sender, args, 1);
        if (key == null) {
            return true;
        }
        if (sender instanceof Player) {
            guiManager.openDeleteConfirmation((Player) sender, key);
            return true;
        }
        if (args.length < 5 || !"confirm".equalsIgnoreCase(args[4])) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Console deletion requires: /optimizer deletechunk <world> <chunk-x> <chunk-z> confirm");
            return true;
        }
        sender.sendMessage(PREFIX + ChatColor.YELLOW + "Deletion queued for " + key + ".");
        plugin.getDeletionService().deleteChunk(key, sender instanceof Player ? sender.getName() : "console")
                .whenComplete((result, throwable) -> plugin.runSync(() -> {
                    if (throwable != null) {
                        sender.sendMessage(PREFIX + ChatColor.RED + "Deletion failed: " + throwable.getMessage());
                        return;
                    }
                    guiManager.clearCache();
                    sendDeletionResult(sender, result);
                }));
        return true;
    }

    private boolean handleDryRun(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        ChunkKey key = parseKeyOrCurrent(sender, args, 1);
        if (key == null) {
            return true;
        }
        sender.sendMessage(PREFIX + ChatColor.YELLOW + "Building deletion preview for " + key + ".");
        plugin.getDeletionService().previewDeletion(key).whenComplete((inspection, throwable) -> plugin.runSync(() -> {
            if (throwable != null) {
                sender.sendMessage(PREFIX + ChatColor.RED + "Dry-run failed: " + throwable.getMessage());
                return;
            }
            sendInspection(sender, inspection, true);
        }));
        return true;
    }

    private boolean handleForceQueue(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        ChunkKey key = parseKey(sender, args, 1);
        if (key == null) {
            return true;
        }
        String reason = join(args, 4, "manual force queue");
        String actor = sender instanceof Player ? sender.getName() : "console";
        plugin.runAsync(() -> {
            boolean queued = plugin.getManagementService().queueChunk(key, reason, actor);
            if (queued) {
                guiManager.clearCache();
            }
            plugin.runSync(() -> sender.sendMessage(PREFIX + (queued
                    ? ChatColor.GREEN + "Queued " + key + ". Safety checks still run before deletion."
                    : ChatColor.YELLOW + key.toString() + " is already queued.")));
        });
        return true;
    }

    private boolean handleInspectChunk(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        ChunkKey key = parseKeyOrCurrent(sender, args, 1);
        if (key == null) {
            return true;
        }
        sender.sendMessage(PREFIX + ChatColor.YELLOW + "Inspecting " + key + ".");
        plugin.getSafetyService().inspect(key, true).whenComplete((inspection, throwable) -> plugin.runSync(() -> {
            if (throwable != null) {
                sender.sendMessage(PREFIX + ChatColor.RED + "Inspection failed: " + throwable.getMessage());
                return;
            }
            sendInspection(sender, inspection, false);
        }));
        return true;
    }

    private boolean handleDebug(CommandSender sender) {
        if (!requireAdmin(sender)) {
            return true;
        }
        plugin.runAsync(() -> {
            OptimizerStats stats = plugin.getEngine().getStats();
            QueueStats queueStats = plugin.getStorage().getQueueStats();
            String schemaVersion = plugin.getStorage().getMetadata("schema-version");
            plugin.runSync(() -> sendDebug(sender, stats, queueStats, schemaVersion));
        });
        return true;
    }

    private boolean handleScan(CommandSender sender) {
        if (!requireAdmin(sender)) {
            return true;
        }
        sender.sendMessage(PREFIX + ChatColor.YELLOW + "Scan started.");
        plugin.getEngine().triggerScan().whenComplete((result, throwable) -> plugin.runSync(() -> {
            if (throwable != null) {
                sender.sendMessage(PREFIX + ChatColor.RED + "Scan failed: " + throwable.getMessage());
                return;
            }
            if (result.getQueued() > 0) {
                guiManager.clearCache();
            }
            sendScanResult(sender, result);
        }));
        return true;
    }

    private boolean handleTeleportChunk(CommandSender sender, String[] args) {
        if (!requireAdmin(sender)) {
            return true;
        }
        Player player = requirePlayer(sender);
        if (player == null) {
            return true;
        }
        ChunkKey key = parseKey(sender, args, 1);
        if (key == null) {
            return true;
        }
        if (ChunkTeleporter.teleport(player, key)) {
            sender.sendMessage(PREFIX + ChatColor.GREEN + "Teleported to " + key + ".");
        } else {
            sender.sendMessage(PREFIX + ChatColor.RED + "Could not teleport to " + key + ".");
        }
        return true;
    }

    private ChunkKey parseKey(CommandSender sender, String[] args, int offset) {
        if (args.length < offset + 3) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Expected: <world> <chunk-x> <chunk-z>");
            return null;
        }
        try {
            return new ChunkKey(args[offset], Integer.parseInt(args[offset + 1]), Integer.parseInt(args[offset + 2]));
        } catch (NumberFormatException e) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Chunk coordinates must be whole numbers.");
            return null;
        } catch (IllegalArgumentException e) {
            sender.sendMessage(PREFIX + ChatColor.RED + e.getMessage());
            return null;
        }
    }

    private ChunkKey parseKeyOrCurrent(CommandSender sender, String[] args, int offset) {
        if (args.length >= offset + 3) {
            return parseKey(sender, args, offset);
        }
        if (!(sender instanceof Player)) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Console must provide: <world> <chunk-x> <chunk-z>");
            return null;
        }
        Location location = ((Player) sender).getLocation();
        if (location.getWorld() == null) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Could not resolve your current world.");
            return null;
        }
        return new ChunkKey(location.getWorld().getName(), location.getBlockX() >> 4, location.getBlockZ() >> 4);
    }

    private Integer parseRadius(CommandSender sender, String token) {
        String value = token.substring(token.indexOf(':') + 1);
        try {
            int radius = Integer.parseInt(value);
            if (radius < 1) {
                sender.sendMessage(PREFIX + ChatColor.RED + "Radius must be at least 1. r:1 is your current chunk.");
                return null;
            }
            if (radius > MAX_WHITELIST_RADIUS) {
                sender.sendMessage(PREFIX + ChatColor.RED + "Radius cannot exceed " + MAX_WHITELIST_RADIUS + " chunks.");
                return null;
            }
            return radius;
        } catch (NumberFormatException e) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Radius must be a whole number, for example r:10.");
            return null;
        }
    }

    private boolean isRadiusToken(String token) {
        if (token == null) {
            return false;
        }
        String lower = token.toLowerCase(Locale.ROOT);
        return lower.startsWith("r:") || lower.startsWith("radius:");
    }

    private List<ChunkKey> buildRadiusKeys(String worldName, int centerX, int centerZ, int radius) {
        int edgeDistance = radius - 1;
        int size = edgeDistance * 2 + 1;
        List<ChunkKey> keys = new ArrayList<ChunkKey>(size * size);
        for (int x = centerX - edgeDistance; x <= centerX + edgeDistance; x++) {
            for (int z = centerZ - edgeDistance; z <= centerZ + edgeDistance; z++) {
                keys.add(new ChunkKey(worldName, x, z));
            }
        }
        return keys;
    }

    private String join(String[] args, int start, String fallback) {
        if (args.length <= start) {
            return fallback;
        }
        StringBuilder builder = new StringBuilder();
        for (int i = start; i < args.length; i++) {
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(args[i]);
        }
        return builder.toString();
    }

    private void sendUsage(CommandSender sender, String label) {
        sender.sendMessage(PREFIX + ChatColor.YELLOW + "Usage: /" + label + " <gui|queue|whitelist|deletechunk|tpchunk|reload|scan|stats|debug|dryrun|forcestart|forcequeue|inspectchunk>");
    }

    private void sendScanResult(CommandSender sender, ScanResult result) {
        sender.sendMessage(PREFIX + ChatColor.GREEN + "Scan complete: " +
                result.getQueued() + " queued, " +
                result.getProtectedChunks() + " protected, " +
                result.getSkipped() + " skipped, " +
                result.getCandidates() + " candidates in " +
                result.getDurationMillis() + "ms.");
    }

    private void sendStats(CommandSender sender, OptimizerStats stats) {
        sender.sendMessage(PREFIX + ChatColor.AQUA + "Stats");
        sender.sendMessage(ChatColor.GRAY + "Tracked chunks: " + ChatColor.WHITE + stats.getTrackedChunks());
        sender.sendMessage(ChatColor.GRAY + "Queued chunks: " + ChatColor.WHITE + stats.getQueuedChunks());
        sender.sendMessage(ChatColor.GRAY + "Whitelisted chunks: " + ChatColor.WHITE + stats.getWhitelistedChunks());
        sender.sendMessage(ChatColor.GRAY + "Pending visit writes: " + ChatColor.WHITE + stats.getPendingVisitWrites());
        sender.sendMessage(ChatColor.GRAY + "Oldest visit: " + ChatColor.WHITE + formatTimestamp(stats.getOldestVisitTimestamp()));
    }

    private void sendDebug(CommandSender sender, OptimizerStats stats, QueueStats queueStats, String schemaVersion) {
        OptimizerConfig config = plugin.getOptimizerConfig();
        sender.sendMessage(PREFIX + ChatColor.AQUA + "Debug");
        sender.sendMessage(ChatColor.GRAY + "Schema version: " + ChatColor.WHITE + stringOr(schemaVersion, "unknown"));
        sender.sendMessage(ChatColor.GRAY + "Dry-run mode: " + ChatColor.WHITE + config.isDryRunMode());
        sender.sendMessage(ChatColor.GRAY + "Auto queue/delete: " + ChatColor.WHITE + config.isAutoQueue() + " / " + config.isAutoDeleteEnabled());
        sender.sendMessage(ChatColor.GRAY + "Batch size / cooldown: " + ChatColor.WHITE + config.getAutoDeleteBatchSize() + " / " + config.getDeletionCooldownDurationLabel());
        sender.sendMessage(ChatColor.GRAY + "Player radius / spawn radius: " + ChatColor.WHITE + config.getPlayerSafetyRadiusChunks() + " / " + config.getSpawnProtectionRadiusChunks() + " chunks");
        sender.sendMessage(ChatColor.GRAY + "Protection hooks: " + ChatColor.WHITE + "WorldGuard=" + hookStatus("WorldGuard", config.isWorldGuardEnabled()) + ", Lands=" + hookStatus("Lands", config.isLandsEnabled()));
        sender.sendMessage(ChatColor.GRAY + "Queue states: " + ChatColor.WHITE
                + "queued=" + queueStats.getQueued()
                + ", deleting=" + queueStats.getDeleting()
                + ", deleted=" + queueStats.getDeleted()
                + ", skipped=" + queueStats.getSkipped()
                + ", failed=" + queueStats.getFailed());
        sender.sendMessage(ChatColor.GRAY + "Audit records: " + ChatColor.WHITE + queueStats.getAuditRecords());
        sender.sendMessage(ChatColor.GRAY + "Tracked / whitelisted / pending writes: " + ChatColor.WHITE
                + stats.getTrackedChunks() + " / " + stats.getWhitelistedChunks() + " / " + stats.getPendingVisitWrites());
    }

    private void sendInspection(CommandSender sender, ChunkInspection inspection, boolean dryRun) {
        ChunkKey key = inspection.getKey();
        QueuedChunk queued = inspection.getQueuedChunk();
        sender.sendMessage(PREFIX + ChatColor.AQUA + (dryRun ? "Dry-run preview" : "Chunk inspection") + ChatColor.GRAY + " for " + ChatColor.WHITE + key);
        sender.sendMessage(ChatColor.GRAY + "Last visited: " + ChatColor.WHITE + formatTimestamp(inspection.getLastVisitedAt()));
        sender.sendMessage(ChatColor.GRAY + "Queue status: " + ChatColor.WHITE + (queued == null ? "not queued" : queued.getState().name().toLowerCase(Locale.ROOT)));
        sender.sendMessage(ChatColor.GRAY + "Whitelist status: " + ChatColor.WHITE + (inspection.isWhitelisted() ? "whitelisted" : "not whitelisted"));
        sender.sendMessage(ChatColor.GRAY + "Protection status: " + ChatColor.WHITE + (inspection.canDelete() ? "clear" : "blocked"));
        sender.sendMessage(ChatColor.GRAY + "World / loaded / nearby players: " + ChatColor.WHITE
                + inspection.isWorldAvailable() + " / " + inspection.isChunkLoaded() + " / " + inspection.getNearbyPlayers());
        sender.sendMessage(ChatColor.GRAY + "TPS throttle: " + ChatColor.WHITE + (inspection.isTpsThrottled() ? "active" : "clear") + tpsSuffix(inspection.getCurrentTps()));
        sender.sendMessage(ChatColor.GRAY + "Deletion result: " + ChatColor.WHITE + (inspection.canDelete()
                ? (inspection.isDryRunMode() ? "would delete; config dry-run prevents writes" : "would delete")
                : "will not delete"));
        if (!inspection.getBlockers().isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "Blockers:");
            for (String blocker : inspection.getBlockers()) {
                sender.sendMessage(ChatColor.DARK_GRAY + "- " + ChatColor.RED + blocker);
            }
        }
        if (!inspection.getNearbyProtections().isEmpty()) {
            sender.sendMessage(ChatColor.GRAY + "Nearby protections:");
            for (String protection : inspection.getNearbyProtections()) {
                sender.sendMessage(ChatColor.DARK_GRAY + "- " + ChatColor.YELLOW + protection);
            }
        }
    }

    private void sendDeletionResult(CommandSender sender, ChunkDeletionResult result) {
        if (result.isDryRun()) {
            sender.sendMessage(PREFIX + ChatColor.AQUA + result.getMessage());
        } else if (result.isSuccess()) {
            sender.sendMessage(PREFIX + ChatColor.GREEN + result.getMessage());
        } else if (result.isPostponed()) {
            sender.sendMessage(PREFIX + ChatColor.YELLOW + result.getMessage());
        } else {
            sender.sendMessage(PREFIX + ChatColor.RED + result.getMessage());
        }
    }

    private String hookStatus(String pluginName, boolean enabledInConfig) {
        if (!enabledInConfig) {
            return "disabled";
        }
        return Bukkit.getPluginManager().getPlugin(pluginName) == null ? "absent" : "present";
    }

    private String tpsSuffix(double tps) {
        if (tps < 0.0D) {
            return " (TPS unavailable)";
        }
        return " (" + String.format(Locale.ROOT, "%.2f", tps) + ")";
    }

    private String stringOr(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    private String formatTimestamp(long timestamp) {
        if (timestamp <= 0L) {
            return "none";
        }
        return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new Date(timestamp));
    }

    private Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player) {
            return (Player) sender;
        }
        sender.sendMessage(PREFIX + ChatColor.RED + "This command must be run by a player.");
        return null;
    }

    private boolean requireView(CommandSender sender) {
        if (canView(sender)) {
            return true;
        }
        sender.sendMessage(PREFIX + ChatColor.RED + "You do not have permission to view ChunkOptimizer.");
        return false;
    }

    private boolean requireAdmin(CommandSender sender) {
        if (sender.hasPermission("optimizer.admin")) {
            return true;
        }
        sender.sendMessage(PREFIX + ChatColor.RED + "You do not have permission to administer ChunkOptimizer.");
        return false;
    }

    private boolean canView(CommandSender sender) {
        return sender.hasPermission("optimizer.view") || sender.hasPermission("optimizer.admin");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            String prefix = args[0].toLowerCase(Locale.ROOT);
            List<String> matches = new ArrayList<String>();
            for (String subcommand : SUBCOMMANDS) {
                if (subcommand.startsWith(prefix) && canSuggest(sender, subcommand)) {
                    matches.add(subcommand);
                }
            }
            return matches;
        }
        if (args.length == 2 && isChunkKeyCommand(args[0])) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            List<String> matches = new ArrayList<String>();
            for (World world : Bukkit.getWorlds()) {
                if (world.getName().toLowerCase(Locale.ROOT).startsWith(prefix)) {
                    matches.add(world.getName());
                }
            }
            return matches;
        }
        if (args.length == 3 && isChunkKeyCommand(args[0])) {
            List<String> candidates = new ArrayList<String>();
            if ("whitelist".equalsIgnoreCase(args[0]) && sender instanceof Player) {
                candidates.add("r:1");
                candidates.add("r:5");
                candidates.add("r:10");
            }
            if (sender instanceof Player) {
                Location location = ((Player) sender).getLocation();
                candidates.add(Integer.toString(location.getBlockX() >> 4));
            }
            return matches(args[2], candidates);
        }
        if (args.length == 4 && "whitelist".equalsIgnoreCase(args[0]) && isRadiusToken(args[2]) && sender instanceof Player) {
            return matches(args[3], Arrays.asList("confirm"));
        }
        if (args.length == 4 && isChunkKeyCommand(args[0]) && !isRadiusToken(args[2]) && sender instanceof Player) {
            Location location = ((Player) sender).getLocation();
            return matches(args[3], Arrays.asList(Integer.toString(location.getBlockZ() >> 4)));
        }
        return new ArrayList<String>();
    }

    private List<String> matches(String prefix, List<String> candidates) {
        String lowerPrefix = prefix == null ? "" : prefix.toLowerCase(Locale.ROOT);
        List<String> matches = new ArrayList<String>();
        for (String candidate : candidates) {
            if (candidate.toLowerCase(Locale.ROOT).startsWith(lowerPrefix)) {
                matches.add(candidate);
            }
        }
        return matches;
    }

    private boolean canSuggest(CommandSender sender, String subcommand) {
        if ("gui".equals(subcommand) || "queue".equals(subcommand) || "whitelist".equals(subcommand) || "stats".equals(subcommand)) {
            return canView(sender);
        }
        return sender.hasPermission("optimizer.admin");
    }

    private boolean isChunkKeyCommand(String subcommand) {
        return "deletechunk".equalsIgnoreCase(subcommand)
                || "tpchunk".equalsIgnoreCase(subcommand)
                || "whitelist".equalsIgnoreCase(subcommand)
                || "dryrun".equalsIgnoreCase(subcommand)
                || "forcequeue".equalsIgnoreCase(subcommand)
                || "inspectchunk".equalsIgnoreCase(subcommand);
    }
}
