package dev.alexroper.chunkoptimizer.bukkit.deletion;

import dev.alexroper.chunkoptimizer.core.api.ChunkDeletionAdapter;
import dev.alexroper.chunkoptimizer.core.logging.OptimizerLogger;
import dev.alexroper.chunkoptimizer.core.model.ChunkDeletionResult;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.scheduler.SchedulerAdapter;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public final class StorageChunkDeletionAdapter implements ChunkDeletionAdapter {
    private static final int REGION_SIZE = 32;
    private static final int REGION_HEADER_BYTES = 4096;
    private static final String[] MODERN_CHUNK_POS_CLASSES = new String[] {
            "net.minecraft.world.level.ChunkCoordIntPair",
            "net.minecraft.world.level.ChunkPos"
    };
    private static final String[] MODERN_COMPOUND_CLASSES = new String[] {
            "net.minecraft.nbt.NBTTagCompound",
            "net.minecraft.nbt.CompoundTag"
    };
    private static final String[] MODERN_CHUNK_ENTITIES_CLASSES = new String[] {
            "net.minecraft.world.level.entity.ChunkEntities"
    };
    private static final String[] MODERN_SECTION_POSITION_CLASSES = new String[] {
            "net.minecraft.core.SectionPosition",
            "net.minecraft.core.SectionPos"
    };
    private static final String MOONRISE_REGION_FILE_IO_CLASS = "ca.spottedleaf.moonrise.patches.chunk_system.io.MoonriseRegionFileIO";
    private static final String MOONRISE_REGION_FILE_TYPE_CLASS = "ca.spottedleaf.moonrise.patches.chunk_system.io.MoonriseRegionFileIO$RegionFileType";

    private final SchedulerAdapter scheduler;
    private final OptimizerLogger logger;

    public StorageChunkDeletionAdapter(SchedulerAdapter scheduler, OptimizerLogger logger) {
        this.scheduler = scheduler;
        this.logger = logger;
    }

    @Override
    public CompletableFuture<ChunkDeletionResult> resetChunk(final ChunkKey key) {
        final CompletableFuture<ChunkDeletionResult> future = new CompletableFuture<ChunkDeletionResult>();
        scheduler.runSync(() -> {
            try {
                future.complete(deleteStoredChunk(key));
            } catch (Throwable throwable) {
                logger.warn("Failed to delete stored chunk data for " + key + ".", throwable);
                future.complete(ChunkDeletionResult.failure(key, rootMessage(throwable)));
            }
        });
        return future;
    }

    private ChunkDeletionResult deleteStoredChunk(ChunkKey key) throws Exception {
        World world = Bukkit.getWorld(key.getWorld());
        if (world == null) {
            return ChunkDeletionResult.postponed(key, "World is not loaded.");
        }
        if (isVisibleToPlayers(world, key)) {
            return ChunkDeletionResult.postponed(key, "Chunk is still visible to one or more players.");
        }
        if (isForceLoaded(world, key)) {
            return ChunkDeletionResult.postponed(key, "Chunk is force-loaded.");
        }
        if (hasPluginTickets(world, key)) {
            return ChunkDeletionResult.postponed(key, "Chunk has active plugin chunk tickets.");
        }
        if (!unloadIfNeeded(world, key)) {
            return ChunkDeletionResult.postponed(key, "Server kept the chunk loaded after an unload request.");
        }

        if (isModernStorageAvailable()) {
            deleteModernStorage(world, key);
            return ChunkDeletionResult.success(key, "Deleted stored chunk, entity, and POI data. The chunk will regenerate on next load.");
        }

        if (deleteLegacyStorage(world, key)) {
            return ChunkDeletionResult.success(key, "Deleted stored legacy chunk data. The chunk will regenerate on next load.");
        }
        return ChunkDeletionResult.failure(key, "No supported live chunk deletion strategy is available for this server version.");
    }

    private boolean unloadIfNeeded(World world, ChunkKey key) {
        if (!world.isChunkLoaded(key.getX(), key.getZ())) {
            return true;
        }
        try {
            world.unloadChunk(key.getX(), key.getZ(), false);
        } catch (RuntimeException e) {
            logger.debug("Unload without save failed for " + key + ": " + e.getMessage());
        }
        return !world.isChunkLoaded(key.getX(), key.getZ());
    }

    private boolean isVisibleToPlayers(World world, ChunkKey key) {
        try {
            Method method = world.getClass().getMethod("getPlayersSeeingChunk", Integer.TYPE, Integer.TYPE);
            Object value = method.invoke(world, Integer.valueOf(key.getX()), Integer.valueOf(key.getZ()));
            return value instanceof Collection && !((Collection<?>) value).isEmpty();
        } catch (NoSuchMethodException e) {
            return false;
        } catch (Throwable throwable) {
            logger.debug("Could not inspect chunk viewers for " + key + ": " + throwable.getMessage());
            return true;
        }
    }

    private boolean isForceLoaded(World world, ChunkKey key) {
        try {
            Method method = world.getClass().getMethod("isChunkForceLoaded", Integer.TYPE, Integer.TYPE);
            Object value = method.invoke(world, Integer.valueOf(key.getX()), Integer.valueOf(key.getZ()));
            return value instanceof Boolean && ((Boolean) value).booleanValue();
        } catch (NoSuchMethodException e) {
            return false;
        } catch (Throwable throwable) {
            logger.debug("Could not inspect force-load state for " + key + ": " + throwable.getMessage());
            return true;
        }
    }

    private boolean hasPluginTickets(World world, ChunkKey key) {
        try {
            Method method = world.getClass().getMethod("getPluginChunkTickets", Integer.TYPE, Integer.TYPE);
            Object value = method.invoke(world, Integer.valueOf(key.getX()), Integer.valueOf(key.getZ()));
            if (value instanceof Collection) {
                return !((Collection<?>) value).isEmpty();
            }
            if (value instanceof Map) {
                return !((Map<?, ?>) value).isEmpty();
            }
            return false;
        } catch (NoSuchMethodException e) {
            return false;
        } catch (Throwable throwable) {
            logger.debug("Could not inspect plugin chunk tickets for " + key + ": " + throwable.getMessage());
            return true;
        }
    }

    private boolean isModernStorageAvailable() {
        return firstClass(MODERN_CHUNK_POS_CLASSES) != null && firstClass(MODERN_COMPOUND_CLASSES) != null;
    }

    private void deleteModernStorage(World world, ChunkKey key) throws Exception {
        Class<?> chunkPosClass = firstClass(MODERN_CHUNK_POS_CLASSES);
        if (chunkPosClass == null) {
            throw new IllegalStateException("Modern ChunkPos class is unavailable.");
        }
        Object chunkPos = newChunkPos(chunkPosClass, key);
        Object worldHandle = invokeNoArg(world, "getHandle");
        Object chunkProvider = findChunkProvider(worldHandle);
        Object chunkMap = findFieldValueBySimpleName(chunkProvider, "PlayerChunkMap", "ChunkMap");
        if (chunkMap == null) {
            throw new IllegalStateException("Could not access modern chunk storage.");
        }

        if (deleteMoonriseStorage(world, worldHandle, chunkProvider, chunkMap, chunkPos, key)) {
            return;
        }

        invokeWriteNull(chunkMap, chunkPos);
        flushStorage(chunkMap);

        deleteModernEntityStorage(worldHandle, chunkPos);
        deleteModernPoiStorage(world, worldHandle, chunkProvider, chunkMap, chunkPos, key);
    }

    private Object newChunkPos(Class<?> chunkPosClass, ChunkKey key) throws Exception {
        Constructor<?> constructor = chunkPosClass.getConstructor(Integer.TYPE, Integer.TYPE);
        return constructor.newInstance(Integer.valueOf(key.getX()), Integer.valueOf(key.getZ()));
    }

    private Object findChunkProvider(Object worldHandle) throws Exception {
        Object value = findNoArgReturnValue(worldHandle, "ChunkProviderServer", "ServerChunkCache");
        if (value == null) {
            throw new IllegalStateException("Could not access the server chunk provider.");
        }
        return value;
    }

    private void deleteModernEntityStorage(Object worldHandle, Object chunkPos) throws Exception {
        Object entityManager = findFieldValueBySimpleName(worldHandle, "PersistentEntitySectionManager");
        if (entityManager == null) {
            throw new IllegalStateException("Could not access modern entity section manager.");
        }
        Object entityStorage = findFieldValueBySimpleName(entityManager, "EntityPersistentStorage", "EntityStorage");
        if (entityStorage == null) {
            throw new IllegalStateException("Could not access modern entity storage.");
        }
        Class<?> chunkEntitiesClass = firstClass(MODERN_CHUNK_ENTITIES_CLASSES);
        if (chunkEntitiesClass == null) {
            throw new IllegalStateException("Modern ChunkEntities class is unavailable.");
        }
        Constructor<?> constructor = chunkEntitiesClass.getConstructor(chunkPos.getClass(), List.class);
        Object emptyEntities = constructor.newInstance(chunkPos, Collections.emptyList());
        invokeSingleArgument(entityStorage, emptyEntities);
        flushStorage(entityStorage);
    }

    private boolean deleteMoonriseStorage(World world, Object worldHandle, Object chunkProvider, Object chunkMap, Object chunkPos, ChunkKey key) throws Exception {
        Class<?> ioClass = firstClass(new String[] {MOONRISE_REGION_FILE_IO_CLASS});
        Class<?> typeClass = firstClass(new String[] {MOONRISE_REGION_FILE_TYPE_CLASS});
        if (ioClass == null || typeClass == null) {
            return false;
        }

        Object chunkType = enumConstant(typeClass, "CHUNK_DATA");
        Object entityType = enumConstant(typeClass, "ENTITY_DATA");
        Object poiType = enumConstant(typeClass, "POI_DATA");
        if (chunkType == null || entityType == null || poiType == null) {
            return false;
        }

        scheduleMoonriseDelete(ioClass, worldHandle, typeClass, chunkType, key);
        scheduleMoonriseDelete(ioClass, worldHandle, typeClass, entityType, key);
        Object poiStorage = findPoiStorage(worldHandle, chunkProvider, chunkMap);
        if (poiStorage != null) {
            clearPoiMemory(poiStorage, chunkPos, world, key);
        }
        scheduleMoonriseDelete(ioClass, worldHandle, typeClass, poiType, key);
        flushMoonriseStorage(ioClass, worldHandle, typeClass, chunkType);
        flushMoonriseStorage(ioClass, worldHandle, typeClass, entityType);
        flushMoonriseStorage(ioClass, worldHandle, typeClass, poiType);
        if (poiStorage != null) {
            clearPoiMemory(poiStorage, chunkPos, world, key);
        }
        return true;
    }

    private void scheduleMoonriseDelete(Class<?> ioClass, Object worldHandle, Class<?> typeClass, Object regionFileType, ChunkKey key) throws Exception {
        Method method = findMoonriseMethod(ioClass, "scheduleSave", worldHandle.getClass(), typeClass);
        if (method == null) {
            throw new IllegalStateException("Could not access Paper Moonrise scheduleSave.");
        }
        method.invoke(null, worldHandle, Integer.valueOf(key.getX()), Integer.valueOf(key.getZ()), null, regionFileType);
    }

    private void flushMoonriseStorage(Class<?> ioClass, Object worldHandle, Class<?> typeClass, Object regionFileType) throws Exception {
        Method flush = findMoonriseMethod(ioClass, "flush", worldHandle.getClass(), typeClass);
        if (flush != null) {
            flush.invoke(null, worldHandle, regionFileType);
        }
        Method flushRegionStorage = findMoonriseMethod(ioClass, "flushRegionStorages", worldHandle.getClass(), typeClass);
        if (flushRegionStorage != null) {
            flushRegionStorage.invoke(null, worldHandle, regionFileType);
        }
    }

    private Method findMoonriseMethod(Class<?> ioClass, String name, Class<?> worldHandleClass, Class<?> typeClass) {
        Method[] methods = ioClass.getMethods();
        for (Method method : methods) {
            Class<?>[] parameterTypes = method.getParameterTypes();
            if (!name.equals(method.getName()) || parameterTypes.length < 2) {
                continue;
            }
            if (parameterTypes[0].isAssignableFrom(worldHandleClass)
                    && parameterTypes[parameterTypes.length - 1] == typeClass
                    && ("flush".equals(name) || "flushRegionStorages".equals(name))
                    && parameterTypes.length == 2) {
                method.setAccessible(true);
                return method;
            }
            if ("scheduleSave".equals(name)
                    && parameterTypes.length == 5
                    && parameterTypes[0].isAssignableFrom(worldHandleClass)
                    && parameterTypes[1] == Integer.TYPE
                    && parameterTypes[2] == Integer.TYPE
                    && isCompoundTag(parameterTypes[3])
                    && parameterTypes[4] == typeClass) {
                method.setAccessible(true);
                return method;
            }
        }
        return null;
    }

    private Object enumConstant(Class<?> enumClass, String name) {
        Object[] constants = enumClass.getEnumConstants();
        if (constants == null) {
            return null;
        }
        for (Object constant : constants) {
            if (constant instanceof Enum && ((Enum<?>) constant).name().equals(name)) {
                return constant;
            }
        }
        return null;
    }

    private void deleteModernPoiStorage(World world, Object worldHandle, Object chunkProvider, Object chunkMap, Object chunkPos, ChunkKey key) throws Exception {
        Object poiStorage = findPoiStorage(worldHandle, chunkProvider, chunkMap);
        if (poiStorage == null) {
            throw new IllegalStateException("Could not access modern POI storage.");
        }
        clearPoiMemory(poiStorage, chunkPos, world, key);
        Object poiFileStorage = findFieldValueBySimpleName(poiStorage, "SimpleRegionStorage", "IOWorker", "RegionFileStorage");
        if (poiFileStorage == null) {
            throw new IllegalStateException("Could not access modern POI file storage.");
        }
        invokeWriteNull(poiFileStorage, chunkPos);
        flushStorage(poiFileStorage);
        clearPoiMemory(poiStorage, chunkPos, world, key);
    }

    private Object findPoiStorage(Object worldHandle, Object chunkProvider, Object chunkMap) throws Exception {
        Object poiStorage = findNoArgReturnValue(worldHandle, "VillagePlace", "PoiManager");
        if (poiStorage == null) {
            poiStorage = findNoArgReturnValue(chunkProvider, "VillagePlace", "PoiManager");
        }
        if (poiStorage == null) {
            poiStorage = findNoArgReturnValue(chunkMap, "VillagePlace", "PoiManager");
        }
        if (poiStorage == null) {
            poiStorage = findFieldValueBySimpleName(worldHandle, "VillagePlace", "PoiManager");
        }
        if (poiStorage == null) {
            poiStorage = findFieldValueBySimpleName(chunkProvider, "VillagePlace", "PoiManager");
        }
        if (poiStorage == null) {
            poiStorage = findFieldValueBySimpleName(chunkMap, "VillagePlace", "PoiManager");
        }
        return poiStorage;
    }

    private void invokeWriteNull(Object target, Object chunkPos) throws Exception {
        Method method = findWriteMethod(target.getClass(), chunkPos.getClass());
        if (method == null) {
            throw new IllegalStateException("Could not find chunk storage write method on " + target.getClass().getName() + ".");
        }
        Object argument = null;
        Class<?> secondType = method.getParameterTypes()[1];
        if (java.util.function.Supplier.class.isAssignableFrom(secondType)) {
            argument = new java.util.function.Supplier<Object>() {
                @Override
                public Object get() {
                    return null;
                }
            };
        }
        Object result = method.invoke(target, chunkPos, argument);
        joinIfFuture(result);
    }

    private Method findWriteMethod(Class<?> type, Class<?> chunkPosClass) {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            Method[] methods = current.getDeclaredMethods();
            for (Method method : methods) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length != 2 || !parameterTypes[0].isAssignableFrom(chunkPosClass)) {
                    continue;
                }
                if (isCompoundTag(parameterTypes[1]) || java.util.function.Supplier.class.isAssignableFrom(parameterTypes[1])) {
                    method.setAccessible(true);
                    return method;
                }
            }
        }
        Method[] publicMethods = type.getMethods();
        for (Method method : publicMethods) {
            Class<?>[] parameterTypes = method.getParameterTypes();
            if (parameterTypes.length == 2
                    && parameterTypes[0].isAssignableFrom(chunkPosClass)
                    && (isCompoundTag(parameterTypes[1]) || java.util.function.Supplier.class.isAssignableFrom(parameterTypes[1]))) {
                method.setAccessible(true);
                return method;
            }
        }
        return null;
    }

    private boolean isCompoundTag(Class<?> type) {
        String name = type.getName();
        return "net.minecraft.nbt.NBTTagCompound".equals(name) || "net.minecraft.nbt.CompoundTag".equals(name);
    }

    private void flushStorage(Object target) throws Exception {
        Method noArg = findNoArgMethod(target.getClass(), "o", "flush", "sync", "flushWorker");
        if (noArg != null) {
            joinIfFuture(noArg.invoke(target));
            return;
        }

        Method booleanMethod = findBooleanFlushMethod(target.getClass());
        if (booleanMethod != null) {
            joinIfFuture(booleanMethod.invoke(target, Boolean.TRUE));
        }
    }

    private Method findBooleanFlushMethod(Class<?> type) {
        Method preferred = findBooleanFlushMethod(type, true);
        if (preferred != null) {
            return preferred;
        }
        return findBooleanFlushMethod(type, false);
    }

    private Method findBooleanFlushMethod(Class<?> type, boolean preferFuture) {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            Method[] methods = current.getDeclaredMethods();
            for (Method method : methods) {
                if (method.getParameterTypes().length == 1
                        && method.getParameterTypes()[0] == Boolean.TYPE
                        && (preferFuture == CompletableFuture.class.isAssignableFrom(method.getReturnType()))
                        && (method.getReturnType() == Void.TYPE || CompletableFuture.class.isAssignableFrom(method.getReturnType()))) {
                    String name = method.getName();
                    if ("b".equals(name) || "flush".equals(name) || "sync".equals(name) || "a".equals(name)) {
                        method.setAccessible(true);
                        return method;
                    }
                }
            }
        }
        return null;
    }

    private void invokeSingleArgument(Object target, Object argument) throws Exception {
        Class<?> argumentClass = argument.getClass();
        for (Class<?> current = target.getClass(); current != null; current = current.getSuperclass()) {
            Method[] methods = current.getDeclaredMethods();
            for (Method method : methods) {
                Class<?>[] parameterTypes = method.getParameterTypes();
                if (parameterTypes.length == 1 && parameterTypes[0].isAssignableFrom(argumentClass)) {
                    method.setAccessible(true);
                    Object result = method.invoke(target, argument);
                    joinIfFuture(result);
                    return;
                }
            }
        }
        throw new IllegalStateException("Could not find entity storage write method on " + target.getClass().getName() + ".");
    }

    private void clearPoiMemory(Object poiStorage, Object chunkPos, World world, ChunkKey key) {
        try {
            long chunkLong = chunkLong(chunkPos);
            List<Long> keys = new ArrayList<Long>();
            keys.add(Long.valueOf(chunkLong));
            keys.addAll(sectionLongs(chunkPos, world));
            for (Class<?> current = poiStorage.getClass(); current != null; current = current.getSuperclass()) {
                Field[] fields = current.getDeclaredFields();
                for (Field field : fields) {
                    if (Modifier.isStatic(field.getModifiers()) || !field.getType().getName().startsWith("it.unimi.dsi.fastutil.longs.")) {
                        continue;
                    }
                    field.setAccessible(true);
                    Object value = field.get(poiStorage);
                    if (value == null) {
                        continue;
                    }
                    for (Long longKey : keys) {
                        invokeRemoveLong(value, longKey.longValue());
                    }
                }
            }
        } catch (Throwable throwable) {
            logger.debug("Could not clear POI memory cache for " + key + ": " + throwable.getMessage());
        }
    }

    private long chunkLong(Object chunkPos) throws Exception {
        Method method = findAnyNoArgLongMethod(chunkPos.getClass(), "toLong", "a", "b");
        if (method == null) {
            throw new IllegalStateException("Could not read chunk long key.");
        }
        return ((Long) method.invoke(chunkPos)).longValue();
    }

    private List<Long> sectionLongs(Object chunkPos, World world) throws Exception {
        Class<?> sectionClass = firstClass(MODERN_SECTION_POSITION_CLASSES);
        if (sectionClass == null) {
            return Collections.emptyList();
        }
        Method fromChunk = findStaticSectionFactory(sectionClass, chunkPos.getClass());
        Method asLong = findAnyNoArgLongMethod(sectionClass, "s", "asLong", "toLong");
        if (fromChunk == null || asLong == null) {
            return Collections.emptyList();
        }
        int minSection = getWorldMinHeight(world) >> 4;
        int maxSection = (getWorldMaxHeight(world) - 1) >> 4;
        List<Long> values = new ArrayList<Long>();
        for (int sectionY = minSection; sectionY <= maxSection; sectionY++) {
            Object section = fromChunk.invoke(null, chunkPos, Integer.valueOf(sectionY));
            values.add((Long) asLong.invoke(section));
        }
        return values;
    }

    private Method findStaticSectionFactory(Class<?> sectionClass, Class<?> chunkPosClass) {
        Method[] methods = sectionClass.getMethods();
        for (Method method : methods) {
            Class<?>[] parameterTypes = method.getParameterTypes();
            if (Modifier.isStatic(method.getModifiers())
                    && method.getReturnType() == sectionClass
                    && parameterTypes.length == 2
                    && parameterTypes[0].isAssignableFrom(chunkPosClass)
                    && parameterTypes[1] == Integer.TYPE) {
                method.setAccessible(true);
                return method;
            }
        }
        return null;
    }

    private int getWorldMinHeight(World world) {
        Object value = invokeOptionalNoArg(world, "getMinHeight");
        return value instanceof Integer ? ((Integer) value).intValue() : 0;
    }

    private int getWorldMaxHeight(World world) {
        Object value = invokeOptionalNoArg(world, "getMaxHeight");
        return value instanceof Integer ? ((Integer) value).intValue() : 256;
    }

    private void invokeRemoveLong(Object target, long key) {
        try {
            Method method = target.getClass().getMethod("remove", Long.TYPE);
            method.invoke(target, Long.valueOf(key));
        } catch (Throwable ignored) {
            // Some fastutil wrappers expose only object removal; those caches will be rebuilt by disk deletion.
        }
    }

    private boolean deleteLegacyStorage(World world, ChunkKey key) throws Exception {
        if (firstLegacyNmsClass("RegionFileCache") == null) {
            return false;
        }
        waitForLegacyFileIo();
        File regionFile = regionFile(world.getWorldFolder(), key);
        if (!regionFile.exists()) {
            return true;
        }

        boolean deleted = deleteLegacyViaRegionCache(world, key, regionFile);
        if (!deleted) {
            deleted = deleteLegacyRegionHeader(regionFile, key);
        }
        waitForLegacyFileIo();
        return deleted;
    }

    private boolean deleteLegacyViaRegionCache(World world, ChunkKey key, File regionFile) {
        Class<?> cacheClass = firstLegacyNmsClass("RegionFileCache");
        if (cacheClass == null) {
            return false;
        }
        synchronized (cacheClass) {
            try {
                Object region = findCachedLegacyRegion(cacheClass, world.getWorldFolder(), key, regionFile);
                return region != null && deleteOpenLegacyRegion(region, key);
            } catch (Throwable throwable) {
                logger.debug("Legacy RegionFileCache deletion failed for " + key + ": " + throwable.getMessage());
                return false;
            }
        }
    }

    private Object findCachedLegacyRegion(Class<?> cacheClass, File worldFolder, ChunkKey key, File regionFile) throws Exception {
        Object mapValue = findStaticMap(cacheClass);
        if (mapValue instanceof Map) {
            for (Map.Entry<?, ?> entry : ((Map<?, ?>) mapValue).entrySet()) {
                Object mapKey = entry.getKey();
                if (mapKey instanceof File && ((File) mapKey).getAbsoluteFile().equals(regionFile.getAbsoluteFile())) {
                    return entry.getValue();
                }
            }
        }

        Method[] methods = cacheClass.getDeclaredMethods();
        for (Method method : methods) {
            Class<?>[] parameterTypes = method.getParameterTypes();
            if (Modifier.isStatic(method.getModifiers())
                    && parameterTypes.length == 3
                    && File.class.isAssignableFrom(parameterTypes[0])
                    && parameterTypes[1] == Integer.TYPE
                    && parameterTypes[2] == Integer.TYPE
                    && method.getReturnType().getSimpleName().equals("RegionFile")) {
                method.setAccessible(true);
                return method.invoke(null, worldFolder, Integer.valueOf(key.getX()), Integer.valueOf(key.getZ()));
            }
        }
        return null;
    }

    private Object findStaticMap(Class<?> type) throws IllegalAccessException {
        Field[] fields = type.getDeclaredFields();
        for (Field field : fields) {
            if (Modifier.isStatic(field.getModifiers()) && Map.class.isAssignableFrom(field.getType())) {
                field.setAccessible(true);
                return field.get(null);
            }
        }
        return null;
    }

    private boolean deleteOpenLegacyRegion(Object region, ChunkKey key) throws Exception {
        Field offsetsField = null;
        Field timestampsField = null;
        List<Field> intArrayFields = new ArrayList<Field>();
        Field sectorFreeField = null;
        Field randomAccessFileField = null;

        for (Class<?> current = region.getClass(); current != null; current = current.getSuperclass()) {
            Field[] fields = current.getDeclaredFields();
            for (Field field : fields) {
                field.setAccessible(true);
                if (field.getType() == int[].class) {
                    intArrayFields.add(field);
                    String name = field.getName().toLowerCase(java.util.Locale.ROOT);
                    if (name.contains("offset")) {
                        offsetsField = field;
                    } else if (name.contains("timestamp")) {
                        timestampsField = field;
                    }
                } else if (List.class.isAssignableFrom(field.getType())) {
                    sectorFreeField = field;
                } else if (RandomAccessFile.class.isAssignableFrom(field.getType())) {
                    randomAccessFileField = field;
                }
            }
        }

        if (offsetsField == null && !intArrayFields.isEmpty()) {
            offsetsField = intArrayFields.get(0);
        }
        if (timestampsField == null && intArrayFields.size() > 1) {
            timestampsField = intArrayFields.get(1);
        }
        if (offsetsField == null || randomAccessFileField == null) {
            return false;
        }

        synchronized (region) {
            int index = localIndex(key);
            int[] offsets = (int[]) offsetsField.get(region);
            int[] timestamps = timestampsField == null ? null : (int[]) timestampsField.get(region);
            int offset = offsets[index];
            offsets[index] = 0;
            if (timestamps != null && timestamps.length > index) {
                timestamps[index] = 0;
            }
            RandomAccessFile file = (RandomAccessFile) randomAccessFileField.get(region);
            writeLegacyHeaderDelete(file, index);
            freeLegacySectors(region, sectorFreeField, offset);
            return true;
        }
    }

    private void freeLegacySectors(Object region, Field sectorFreeField, int offset) throws IllegalAccessException {
        if (sectorFreeField == null || offset == 0) {
            return;
        }
        Object value = sectorFreeField.get(region);
        if (!(value instanceof List)) {
            return;
        }
        int sectorNumber = offset >> 8;
        int sectorCount = offset & 0xFF;
        List<?> sectors = (List<?>) value;
        for (int i = 0; i < sectorCount; i++) {
            int index = sectorNumber + i;
            if (index >= 0 && index < sectors.size()) {
                setListValue(sectors, index, Boolean.TRUE);
            }
        }
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private void setListValue(List list, int index, Object value) {
        list.set(index, value);
    }

    private boolean deleteLegacyRegionHeader(File regionFile, ChunkKey key) throws IOException {
        RandomAccessFile file = new RandomAccessFile(regionFile, "rw");
        try {
            writeLegacyHeaderDelete(file, localIndex(key));
            return true;
        } finally {
            file.close();
        }
    }

    private void writeLegacyHeaderDelete(RandomAccessFile file, int index) throws IOException {
        file.seek(index * 4L);
        file.writeInt(0);
        file.seek(REGION_HEADER_BYTES + index * 4L);
        file.writeInt(0);
        file.getChannel().force(false);
    }

    private int localIndex(ChunkKey key) {
        return (key.getX() & (REGION_SIZE - 1)) + ((key.getZ() & (REGION_SIZE - 1)) * REGION_SIZE);
    }

    private File regionFile(File worldFolder, ChunkKey key) {
        int regionX = key.getX() >> 5;
        int regionZ = key.getZ() >> 5;
        return new File(new File(worldFolder, "region"), "r." + regionX + "." + regionZ + ".mca");
    }

    private void waitForLegacyFileIo() {
        Class<?> fileIoClass = firstLegacyNmsClass("FileIOThread");
        if (fileIoClass == null) {
            return;
        }
        try {
            Object instance = null;
            Method[] methods = fileIoClass.getDeclaredMethods();
            for (Method method : methods) {
                if (Modifier.isStatic(method.getModifiers())
                        && method.getParameterTypes().length == 0
                        && method.getReturnType() == fileIoClass) {
                    method.setAccessible(true);
                    instance = method.invoke(null);
                    break;
                }
            }
            if (instance == null) {
                return;
            }
            for (Method method : methods) {
                if (!Modifier.isStatic(method.getModifiers())
                        && method.getParameterTypes().length == 0
                        && method.getReturnType() == Void.TYPE
                        && "b".equals(method.getName())) {
                    method.setAccessible(true);
                    method.invoke(instance);
                    return;
                }
            }
        } catch (Throwable throwable) {
            logger.debug("Could not drain legacy chunk save queue: " + throwable.getMessage());
        }
    }

    private Class<?> firstLegacyNmsClass(String simpleName) {
        String nmsPackage = legacyNmsPackage();
        if (nmsPackage == null) {
            return null;
        }
        return firstClass(new String[] {nmsPackage + "." + simpleName});
    }

    private String legacyNmsPackage() {
        Package serverPackage = Bukkit.getServer().getClass().getPackage();
        if (serverPackage == null) {
            return null;
        }
        String name = serverPackage.getName();
        int index = name.lastIndexOf('.');
        if (index < 0 || index + 1 >= name.length()) {
            return null;
        }
        String version = name.substring(index + 1);
        if (!version.startsWith("v")) {
            return null;
        }
        if (!version.startsWith("v1_12_")) {
            return null;
        }
        return "net.minecraft.server." + version;
    }

    private Object findNoArgReturnValue(Object target, String... simpleNames) throws Exception {
        for (Class<?> current = target.getClass(); current != null; current = current.getSuperclass()) {
            Method[] methods = current.getDeclaredMethods();
            for (Method method : methods) {
                if (method.getParameterTypes().length == 0 && simpleNameMatches(method.getReturnType(), simpleNames)) {
                    method.setAccessible(true);
                    return method.invoke(target);
                }
            }
        }
        return null;
    }

    private Object findFieldValueBySimpleName(Object target, String... simpleNames) throws Exception {
        if (target == null) {
            return null;
        }
        for (Class<?> current = target.getClass(); current != null; current = current.getSuperclass()) {
            Field[] fields = current.getDeclaredFields();
            for (Field field : fields) {
                if (simpleNameMatches(field.getType(), simpleNames)) {
                    field.setAccessible(true);
                    return field.get(target);
                }
            }
        }
        return null;
    }

    private boolean simpleNameMatches(Class<?> type, String... simpleNames) {
        String simpleName = type.getSimpleName();
        for (String expected : simpleNames) {
            if (simpleName.equals(expected)) {
                return true;
            }
        }
        return false;
    }

    private Object invokeNoArg(Object target, String methodName) throws Exception {
        Method method = target.getClass().getMethod(methodName);
        method.setAccessible(true);
        return method.invoke(target);
    }

    private Object invokeOptionalNoArg(Object target, String methodName) {
        try {
            return invokeNoArg(target, methodName);
        } catch (Throwable ignored) {
            return null;
        }
    }

    private Method findNoArgMethod(Class<?> type, String... names) {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            Method[] methods = current.getDeclaredMethods();
            for (Method method : methods) {
                if (method.getParameterTypes().length == 0 && nameMatches(method.getName(), names)) {
                    method.setAccessible(true);
                    return method;
                }
            }
        }
        return null;
    }

    private Method findAnyNoArgLongMethod(Class<?> type, String... names) {
        for (Class<?> current = type; current != null; current = current.getSuperclass()) {
            Method[] methods = current.getDeclaredMethods();
            for (Method method : methods) {
                if (method.getParameterTypes().length == 0
                        && method.getReturnType() == Long.TYPE
                        && nameMatches(method.getName(), names)) {
                    method.setAccessible(true);
                    return method;
                }
            }
        }
        return null;
    }

    private boolean nameMatches(String actual, String... names) {
        for (String name : names) {
            if (name.equals(actual)) {
                return true;
            }
        }
        return false;
    }

    private void joinIfFuture(Object value) throws Exception {
        if (value instanceof CompletableFuture) {
            ((CompletableFuture<?>) value).join();
        }
    }

    private Class<?> firstClass(String[] names) {
        for (String name : names) {
            try {
                return Class.forName(name);
            } catch (ClassNotFoundException ignored) {
                // Try the next runtime mapping name.
            }
        }
        return null;
    }

    private String rootMessage(Throwable throwable) {
        Throwable current = throwable;
        if (current instanceof InvocationTargetException && ((InvocationTargetException) current).getTargetException() != null) {
            current = ((InvocationTargetException) current).getTargetException();
        }
        while (current.getCause() != null) {
            current = current.getCause();
        }
        String message = current.getMessage();
        return message == null || message.trim().isEmpty() ? current.getClass().getSimpleName() : message;
    }
}
