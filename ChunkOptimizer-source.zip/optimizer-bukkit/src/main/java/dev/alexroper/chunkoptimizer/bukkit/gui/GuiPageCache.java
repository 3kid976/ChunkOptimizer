package dev.alexroper.chunkoptimizer.bukkit.gui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public final class GuiPageCache {
    private final long ttlMillis;
    private final Map<String, CacheEntry> entries = new HashMap<String, CacheEntry>();

    public GuiPageCache(long ttlMillis) {
        this.ttlMillis = Math.max(1000L, ttlMillis);
    }

    public synchronized Object get(String key) {
        CacheEntry entry = entries.get(key);
        if (entry == null) {
            return null;
        }
        if (System.currentTimeMillis() - entry.createdAt > ttlMillis) {
            entries.remove(key);
            return null;
        }
        return entry.value;
    }

    public synchronized void put(String key, Object value) {
        entries.put(key, new CacheEntry(value, System.currentTimeMillis()));
        prune();
    }

    public synchronized void clear() {
        entries.clear();
    }

    private void prune() {
        long now = System.currentTimeMillis();
        Iterator<Map.Entry<String, CacheEntry>> iterator = entries.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<String, CacheEntry> entry = iterator.next();
            if (now - entry.getValue().createdAt > ttlMillis) {
                iterator.remove();
            }
        }
    }

    private static final class CacheEntry {
        private final Object value;
        private final long createdAt;

        private CacheEntry(Object value, long createdAt) {
            this.value = value;
            this.createdAt = createdAt;
        }
    }
}
