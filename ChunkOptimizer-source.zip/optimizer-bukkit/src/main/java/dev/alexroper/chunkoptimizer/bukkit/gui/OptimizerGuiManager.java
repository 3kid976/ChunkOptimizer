package dev.alexroper.chunkoptimizer.bukkit.gui;

import dev.alexroper.chunkoptimizer.bukkit.BukkitOptimizerPlugin;
import dev.alexroper.chunkoptimizer.bukkit.action.ChunkTeleporter;
import dev.alexroper.chunkoptimizer.core.model.ChunkDeletionResult;
import dev.alexroper.chunkoptimizer.core.model.ChunkKey;
import dev.alexroper.chunkoptimizer.core.model.OptimizerStats;
import dev.alexroper.chunkoptimizer.core.model.PagedResult;
import dev.alexroper.chunkoptimizer.core.model.QueuedChunk;
import dev.alexroper.chunkoptimizer.core.model.QueueState;
import dev.alexroper.chunkoptimizer.core.model.WhitelistedChunk;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class OptimizerGuiManager implements Listener {
    private static final int PAGE_SIZE = 28;
    private static final int[] PAGE_SLOTS = new int[]{
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34,
            37, 38, 39, 40, 41, 42, 43
    };
    private static final String PREFIX = ChatColor.DARK_AQUA + "ChunkOptimizer " + ChatColor.GRAY + "» " + ChatColor.RESET;

    private final BukkitOptimizerPlugin plugin;
    private final GuiPageCache cache = new GuiPageCache(8000L);

    public OptimizerGuiManager(BukkitOptimizerPlugin plugin) {
        this.plugin = plugin;
    }

    public void clearCache() {
        cache.clear();
    }

    public void openMain(final Player player) {
        if (!canView(player)) {
            player.sendMessage(PREFIX + ChatColor.RED + "You do not have permission to view ChunkOptimizer.");
            return;
        }
        final GuiMenu menu = baseMenu("ChunkOptimizer", 45);
        menu.setItem(20, ItemBuilder.of(MaterialUtil.item("CLOCK", "WATCH"))
                .name("&bQueued Chunks")
                .lore("&7Browse inactive chunks by world type.", "&7Actions are permission-aware.")
                .build(), (clicked, click) -> openQueueCategories(clicked));
        menu.setItem(24, ItemBuilder.of(MaterialUtil.item("EMERALD_BLOCK", "EMERALD_BLOCK"))
                .name("&aWhitelisted Chunks")
                .lore("&7Review protected manual entries.", "&7Admins can remove or teleport.")
                .build(), (clicked, click) -> openWhitelistPage(clicked, 0));
        menu.setItem(22, ItemBuilder.of(MaterialUtil.item("PAPER", "PAPER"))
                .name("&fOptimizer Stats")
                .lore("&7Tracked chunks, queue depth,", "&7and pending visit writes.")
                .build(), (clicked, click) -> openStats(clicked));
        menu.setItem(40, GuiItems.close(), (clicked, click) -> clicked.closeInventory());
        open(player, menu);
    }

    public void openQueueCategories(final Player player) {
        if (!canView(player)) {
            player.sendMessage(PREFIX + ChatColor.RED + "You do not have permission to view queued chunks.");
            return;
        }
        openLoading(player, "Chunk Queue");
        Object cached = cache.get("queue-categories");
        if (cached instanceof int[]) {
            openQueueCategoriesLoaded(player, (int[]) cached);
            return;
        }
        plugin.runAsync(() -> {
            int[] counts = new int[WorldCategory.values().length];
            for (WorldCategory category : WorldCategory.values()) {
                List<String> worlds = category.getLoadedWorldNames(plugin.getOptimizerConfig());
                counts[category.ordinal()] = worlds.isEmpty()
                        ? 0
                        : plugin.getStorage().countQueuedChunks(worlds, QueueState.QUEUED);
            }
            cache.put("queue-categories", counts);
            plugin.runSync(() -> openQueueCategoriesLoaded(player, counts));
        });
    }

    public void openWhitelistPage(final Player player, final int requestedPage) {
        if (!canView(player)) {
            player.sendMessage(PREFIX + ChatColor.RED + "You do not have permission to view the whitelist.");
            return;
        }
        final int page = Math.max(0, requestedPage);
        final String cacheKey = "whitelist:" + page;
        Object cached = cache.get(cacheKey);
        if (cached instanceof PagedResult) {
            @SuppressWarnings("unchecked")
            PagedResult<WhitelistedChunk> result = (PagedResult<WhitelistedChunk>) cached;
            openWhitelistLoaded(player, result);
            return;
        }
        openLoading(player, "Whitelist");
        plugin.runAsync(() -> {
            int total = plugin.getStorage().countWhitelistedChunks();
            int safePage = clampPage(page, total);
            List<WhitelistedChunk> chunks = plugin.getStorage().listWhitelistedChunks(safePage * PAGE_SIZE, PAGE_SIZE);
            PagedResult<WhitelistedChunk> result = new PagedResult<WhitelistedChunk>(chunks, total, safePage, PAGE_SIZE);
            cache.put("whitelist:" + safePage, result);
            plugin.runSync(() -> openWhitelistLoaded(player, result));
        });
    }

    public void openQueuePage(final Player player, final WorldCategory category, final int requestedPage) {
        if (!canView(player)) {
            player.sendMessage(PREFIX + ChatColor.RED + "You do not have permission to view queued chunks.");
            return;
        }
        final int page = Math.max(0, requestedPage);
        final String cacheKey = "queue:" + category.name() + ":" + page;
        Object cached = cache.get(cacheKey);
        if (cached instanceof PagedResult) {
            @SuppressWarnings("unchecked")
            PagedResult<QueuedChunk> result = (PagedResult<QueuedChunk>) cached;
            openQueueLoaded(player, category, result);
            return;
        }
        openLoading(player, category.getDisplayName() + " Queue");
        plugin.runAsync(() -> {
            List<String> worlds = category.getLoadedWorldNames(plugin.getOptimizerConfig());
            int total = worlds.isEmpty() ? 0 : plugin.getStorage().countQueuedChunks(worlds, QueueState.QUEUED);
            int safePage = clampPage(page, total);
            List<QueuedChunk> chunks = worlds.isEmpty()
                    ? Collections.<QueuedChunk>emptyList()
                    : plugin.getStorage().listQueuedChunks(worlds, QueueState.QUEUED, safePage * PAGE_SIZE, PAGE_SIZE);
            PagedResult<QueuedChunk> result = new PagedResult<QueuedChunk>(chunks, total, safePage, PAGE_SIZE);
            cache.put("queue:" + category.name() + ":" + safePage, result);
            plugin.runSync(() -> openQueueLoaded(player, category, result));
        });
    }

    public void openDeleteConfirmation(Player player, ChunkKey key) {
        if (!isAdmin(player)) {
            player.sendMessage(PREFIX + ChatColor.RED + "You do not have permission to delete chunks.");
            return;
        }
        confirmDelete(player, key, () -> openMain(player));
    }

    private void openQueueCategoriesLoaded(Player player, int[] counts) {
        GuiMenu menu = baseMenu("Chunk Queue", 45);
        addCategory(menu, 20, WorldCategory.OVERWORLD, counts[WorldCategory.OVERWORLD.ordinal()]);
        addCategory(menu, 22, WorldCategory.NETHER, counts[WorldCategory.NETHER.ordinal()]);
        addCategory(menu, 24, WorldCategory.END, counts[WorldCategory.END.ordinal()]);
        menu.setItem(36, GuiItems.back(), (clicked, click) -> openMain(clicked));
        menu.setItem(40, GuiItems.close(), (clicked, click) -> clicked.closeInventory());
        open(player, menu);
    }

    private void addCategory(GuiMenu menu, int slot, final WorldCategory category, int count) {
        ItemStack icon;
        if (category == WorldCategory.NETHER) {
            icon = MaterialUtil.item("NETHERRACK", "NETHERRACK");
        } else if (category == WorldCategory.END) {
            icon = MaterialUtil.item("END_STONE", "ENDER_STONE");
        } else {
            icon = MaterialUtil.item("GRASS_BLOCK", "GRASS");
        }
        menu.setItem(slot, ItemBuilder.of(icon)
                .name("&b" + category.getDisplayName())
                .lore("&7Queued chunks: &f" + count, "", "&eClick to browse.")
                .build(), (clicked, click) -> openQueuePage(clicked, category, 0));
    }

    private void openQueueLoaded(Player player, final WorldCategory category, final PagedResult<QueuedChunk> page) {
        GuiMenu menu = baseMenu(category.getDisplayName() + " Queue", 54);
        List<QueuedChunk> items = page.getItems();
        for (int i = 0; i < items.size() && i < PAGE_SLOTS.length; i++) {
            final QueuedChunk chunk = items.get(i);
            GuiClickAction action = isAdmin(player) ? (clicked, click) -> openQueuedAction(clicked, chunk, category, page.getPage()) : null;
            menu.setItem(PAGE_SLOTS[i], queuedChunkItem(chunk, isAdmin(player)), action);
        }
        if (items.isEmpty()) {
            menu.setItem(22, ItemBuilder.of(MaterialUtil.item("PAPER", "PAPER"))
                    .name("&fNo queued chunks")
                    .lore("&7There are no queued chunks in this category.")
                    .build());
        }
        menu.setItem(45, GuiItems.back(), (clicked, click) -> openQueueCategories(clicked));
        if (page.hasPreviousPage()) {
            menu.setItem(48, GuiItems.previousPage(), (clicked, click) -> openQueuePage(clicked, category, page.getPage() - 1));
        }
        menu.setItem(49, GuiItems.pageInfo(page.getPage(), page.getTotalPages(), page.getTotalItems()));
        if (page.hasNextPage()) {
            menu.setItem(50, GuiItems.nextPage(), (clicked, click) -> openQueuePage(clicked, category, page.getPage() + 1));
        }
        menu.setItem(53, GuiItems.close(), (clicked, click) -> clicked.closeInventory());
        open(player, menu);
    }

    private void openWhitelistLoaded(Player player, final PagedResult<WhitelistedChunk> page) {
        GuiMenu menu = baseMenu("Whitelist", 54);
        List<WhitelistedChunk> items = page.getItems();
        for (int i = 0; i < items.size() && i < PAGE_SLOTS.length; i++) {
            final WhitelistedChunk chunk = items.get(i);
            GuiClickAction action = isAdmin(player) ? (clicked, click) -> openWhitelistAction(clicked, chunk, page.getPage()) : null;
            menu.setItem(PAGE_SLOTS[i], whitelistedChunkItem(chunk, isAdmin(player)), action);
        }
        if (items.isEmpty()) {
            menu.setItem(22, ItemBuilder.of(MaterialUtil.item("PAPER", "PAPER"))
                    .name("&fNo whitelisted chunks")
                    .lore("&7Manual whitelist entries will appear here.")
                    .build());
        }
        menu.setItem(45, GuiItems.back(), (clicked, click) -> openMain(clicked));
        if (isAdmin(player)) {
            menu.setItem(46, ItemBuilder.of(MaterialUtil.item("COMPASS", "COMPASS"))
                    .name("&aWhitelist Current Chunk")
                    .lore("&7Protect the chunk you are standing in.", "&7Also removes it from the queue.")
                    .build(), (clicked, click) -> whitelistCurrentChunk(clicked, page.getPage()));
        }
        if (page.hasPreviousPage()) {
            menu.setItem(48, GuiItems.previousPage(), (clicked, click) -> openWhitelistPage(clicked, page.getPage() - 1));
        }
        menu.setItem(49, GuiItems.pageInfo(page.getPage(), page.getTotalPages(), page.getTotalItems()));
        if (page.hasNextPage()) {
            menu.setItem(50, GuiItems.nextPage(), (clicked, click) -> openWhitelistPage(clicked, page.getPage() + 1));
        }
        menu.setItem(53, GuiItems.close(), (clicked, click) -> clicked.closeInventory());
        open(player, menu);
    }

    private void openQueuedAction(final Player player, final QueuedChunk chunk, final WorldCategory category, final int page) {
        GuiMenu menu = baseMenu("Queued Chunk", 45);
        menu.setItem(13, queuedChunkItem(chunk, false));
        if (isAdmin(player)) {
            menu.setItem(20, ItemBuilder.of(MaterialUtil.item("EMERALD_BLOCK", "EMERALD_BLOCK"))
                    .name("&aWhitelist Chunk")
                    .lore("&7Protect this chunk and remove it", "&7from the deletion queue.")
                    .build(), (clicked, click) -> whitelistQueuedChunk(clicked, chunk, category, page));
            menu.setItem(22, ItemBuilder.of(MaterialUtil.item("TNT", "TNT"))
                    .name("&cDelete / Reset Chunk")
                    .lore("&7Deletes stored data for this chunk.", "&7It will regenerate from seed on visit.", "", "&cRequires confirmation.")
                    .build(), (clicked, click) -> confirmDelete(clicked, chunk.getKey(), () -> openQueuePage(clicked, category, page)));
            menu.setItem(24, ItemBuilder.of(MaterialUtil.item("ENDER_PEARL", "ENDER_PEARL"))
                    .name("&dTeleport")
                    .lore("&7Teleport to the center of this chunk.")
                    .build(), (clicked, click) -> teleport(clicked, chunk.getKey()));
            menu.setItem(31, ItemBuilder.of(MaterialUtil.item("HOPPER", "HOPPER"))
                    .name("&eRemove From Queue")
                    .lore("&7Leaves the world untouched.", "&7Only removes the queued record.")
                    .build(), (clicked, click) -> confirmRemoveQueue(clicked, chunk.getKey(), category, page));
        }
        menu.setItem(36, GuiItems.back(), (clicked, click) -> openQueuePage(clicked, category, page));
        menu.setItem(40, GuiItems.close(), (clicked, click) -> clicked.closeInventory());
        open(player, menu);
    }

    private void openWhitelistAction(final Player player, final WhitelistedChunk chunk, final int page) {
        GuiMenu menu = baseMenu("Whitelist Entry", 45);
        menu.setItem(13, whitelistedChunkItem(chunk, false));
        if (isAdmin(player)) {
            menu.setItem(21, ItemBuilder.of(MaterialUtil.item("ENDER_PEARL", "ENDER_PEARL"))
                    .name("&dTeleport")
                    .lore("&7Teleport to the center of this chunk.")
                    .build(), (clicked, click) -> teleport(clicked, chunk.getKey()));
            menu.setItem(23, ItemBuilder.of(MaterialUtil.item("RED_WOOL", "WOOL", 14))
                    .name("&cRemove Whitelist")
                    .lore("&7This chunk can be queued again", "&7by future scans.", "", "&cRequires confirmation.")
                    .build(), (clicked, click) -> confirmRemoveWhitelist(clicked, chunk.getKey(), page));
        }
        menu.setItem(36, GuiItems.back(), (clicked, click) -> openWhitelistPage(clicked, page));
        menu.setItem(40, GuiItems.close(), (clicked, click) -> clicked.closeInventory());
        open(player, menu);
    }

    private void openStats(final Player player) {
        openLoading(player, "Stats");
        plugin.runAsync(() -> {
            OptimizerStats stats = plugin.getEngine().getStats();
            plugin.runSync(() -> {
                GuiMenu menu = baseMenu("Stats", 45);
                menu.setItem(22, ItemBuilder.of(MaterialUtil.item("PAPER", "PAPER"))
                        .name("&bOptimizer Stats")
                        .lore(
                                "&7Tracked chunks: &f" + stats.getTrackedChunks(),
                                "&7Queued chunks: &f" + stats.getQueuedChunks(),
                                "&7Whitelisted chunks: &f" + stats.getWhitelistedChunks(),
                                "&7Pending visit writes: &f" + stats.getPendingVisitWrites(),
                                "&7Oldest visit: &f" + FormatUtil.timestamp(stats.getOldestVisitTimestamp()))
                        .build());
                menu.setItem(36, GuiItems.back(), (clicked, click) -> openMain(clicked));
                menu.setItem(40, GuiItems.close(), (clicked, click) -> clicked.closeInventory());
                open(player, menu);
            });
        });
    }

    private ItemStack queuedChunkItem(QueuedChunk chunk, boolean actionable) {
        ChunkKey key = chunk.getKey();
        List<String> lore = new ArrayList<String>();
        lore.add("&7World: &f" + key.getWorld());
        lore.add("&7Chunk: &f" + key.getX() + ", " + key.getZ());
        lore.add("&7Last visited: &f" + FormatUtil.timestamp(chunk.getInactiveSince()));
        lore.add("&7Inactive: &f" + FormatUtil.durationSince(chunk.getInactiveSince()));
        lore.add("&7Queued: &f" + FormatUtil.timestamp(chunk.getQueuedAt()));
        lore.add("&7Reason: &f" + fallback(chunk.getReason(), "inactive"));
        lore.add("");
        lore.add(actionable ? "&eClick for actions." : "&8View only.");
        return ItemBuilder.of(MaterialUtil.item("MAP", "EMPTY_MAP"))
                .name("&b" + key.getWorld() + " &7[" + key.getX() + ", " + key.getZ() + "]")
                .lore(lore)
                .build();
    }

    private ItemStack whitelistedChunkItem(WhitelistedChunk chunk, boolean actionable) {
        ChunkKey key = chunk.getKey();
        List<String> lore = new ArrayList<String>();
        lore.add("&7World: &f" + key.getWorld());
        lore.add("&7Chunk: &f" + key.getX() + ", " + key.getZ());
        lore.add("&7Reason: &f" + fallback(chunk.getReason(), "manual whitelist"));
        lore.add("&7Added by: &f" + fallback(chunk.getAddedBy(), "unknown"));
        lore.add("&7Date added: &f" + FormatUtil.timestamp(chunk.getCreatedAt()));
        lore.add("");
        lore.add(actionable ? "&eClick for actions." : "&8View only.");
        return ItemBuilder.of(MaterialUtil.item("EMERALD", "EMERALD"))
                .name("&a" + key.getWorld() + " &7[" + key.getX() + ", " + key.getZ() + "]")
                .lore(lore)
                .build();
    }

    private void whitelistQueuedChunk(final Player player, final QueuedChunk chunk, final WorldCategory category, final int page) {
        plugin.runAsync(() -> {
            plugin.getManagementService().whitelistChunk(chunk.getKey(), "whitelisted from GUI", player.getName());
            cache.clear();
            plugin.runSync(() -> {
                player.sendMessage(PREFIX + ChatColor.GREEN + "Whitelisted " + chunk.getKey() + ".");
                SoundUtil.success(player);
                openQueuePage(player, category, page);
            });
        });
    }

    private void whitelistCurrentChunk(final Player player, final int page) {
        if (!isAdmin(player)) {
            SoundUtil.fail(player);
            return;
        }
        final ChunkKey key = currentChunkKey(player);
        if (key == null) {
            player.sendMessage(PREFIX + ChatColor.RED + "Could not resolve your current chunk.");
            SoundUtil.fail(player);
            return;
        }
        plugin.runAsync(() -> {
            plugin.getManagementService().whitelistChunk(key, "whitelisted current chunk from GUI", player.getName());
            cache.clear();
            plugin.runSync(() -> {
                player.sendMessage(PREFIX + ChatColor.GREEN + "Whitelisted " + key + ".");
                SoundUtil.success(player);
                openWhitelistPage(player, page);
            });
        });
    }

    private void confirmDelete(final Player player, final ChunkKey key, final Runnable afterAction) {
        openConfirmation(player, "Confirm Reset",
                "&7Delete stored chunk data for:",
                "&f" + key.toString(),
                "&cThis cannot be undone.",
                () -> {
                    player.closeInventory();
                    player.sendMessage(PREFIX + ChatColor.YELLOW + "Deletion started for " + key + ".");
                    plugin.getDeletionService().deleteChunk(key, player.getName()).whenComplete((result, throwable) -> plugin.runSync(() -> {
                        cache.clear();
                        if (throwable != null) {
                            player.sendMessage(PREFIX + ChatColor.RED + "Deletion failed: " + throwable.getMessage());
                            SoundUtil.fail(player);
                        } else {
                            sendDeletionMessage(player, result);
                        }
                        afterAction.run();
                    }));
                },
                () -> afterAction.run());
    }

    private void confirmRemoveQueue(final Player player, final ChunkKey key, final WorldCategory category, final int page) {
        openConfirmation(player, "Remove Queue",
                "&7Remove queued record for:",
                "&f" + key.toString(),
                "&7World data is not changed.",
                () -> plugin.runAsync(() -> {
                    plugin.getManagementService().removeFromQueue(key, player.getName());
                    cache.clear();
                    plugin.runSync(() -> {
                        player.sendMessage(PREFIX + ChatColor.GREEN + "Removed " + key + " from queue.");
                        SoundUtil.success(player);
                        openQueuePage(player, category, page);
                    });
                }),
                () -> openQueuePage(player, category, page));
    }

    private void confirmRemoveWhitelist(final Player player, final ChunkKey key, final int page) {
        openConfirmation(player, "Remove Whitelist",
                "&7Remove whitelist entry for:",
                "&f" + key.toString(),
                "&7Future scans may queue it again.",
                () -> plugin.runAsync(() -> {
                    plugin.getManagementService().removeWhitelistedChunk(key, player.getName());
                    cache.clear();
                    plugin.runSync(() -> {
                        player.sendMessage(PREFIX + ChatColor.GREEN + "Removed whitelist entry for " + key + ".");
                        SoundUtil.success(player);
                        openWhitelistPage(player, page);
                    });
                }),
                () -> openWhitelistPage(player, page));
    }

    private void openConfirmation(Player player, String title, String lineOne, String lineTwo, String lineThree, final Runnable confirm, final Runnable cancel) {
        GuiMenu menu = baseMenu(title, 45);
        menu.setItem(13, ItemBuilder.of(MaterialUtil.item("PAPER", "PAPER"))
                .name("&fConfirm Action")
                .lore(lineOne, lineTwo, "", lineThree)
                .build());
        menu.setItem(20, ItemBuilder.of(MaterialUtil.item("LIME_WOOL", "WOOL", 5))
                .name("&aConfirm")
                .lore("&7Proceed with this action.")
                .build(), (clicked, click) -> {
            SoundUtil.click(clicked);
            confirm.run();
        });
        menu.setItem(24, ItemBuilder.of(MaterialUtil.item("RED_WOOL", "WOOL", 14))
                .name("&cCancel")
                .lore("&7Return without changes.")
                .build(), (clicked, click) -> {
            SoundUtil.click(clicked);
            cancel.run();
        });
        open(player, menu);
    }

    private void teleport(Player player, ChunkKey key) {
        if (!isAdmin(player)) {
            SoundUtil.fail(player);
            return;
        }
        if (ChunkTeleporter.teleport(player, key)) {
            player.sendMessage(PREFIX + ChatColor.GREEN + "Teleported to " + key + ".");
            SoundUtil.success(player);
        } else {
            SoundUtil.fail(player);
        }
    }

    private void sendDeletionMessage(Player player, ChunkDeletionResult result) {
        if (result.isDryRun()) {
            player.sendMessage(PREFIX + ChatColor.AQUA + result.getMessage());
            SoundUtil.success(player);
        } else if (result.isSuccess()) {
            player.sendMessage(PREFIX + ChatColor.GREEN + result.getMessage());
            SoundUtil.success(player);
        } else if (result.isPostponed()) {
            player.sendMessage(PREFIX + ChatColor.YELLOW + result.getMessage());
            SoundUtil.fail(player);
        } else {
            player.sendMessage(PREFIX + ChatColor.RED + result.getMessage());
            SoundUtil.fail(player);
        }
    }

    private void openLoading(Player player, String title) {
        GuiMenu menu = baseMenu(title, 27);
        menu.setItem(13, GuiItems.loading());
        open(player, menu);
    }

    private void open(Player player, GuiMenu menu) {
        Inventory inventory = menu.createInventory();
        player.openInventory(inventory);
        SoundUtil.click(player);
    }

    private GuiMenu baseMenu(String title, int size) {
        GuiMenu menu = new GuiMenu(title, size);
        for (int slot = 0; slot < size; slot++) {
            boolean border = slot < 9 || slot >= size - 9 || slot % 9 == 0 || slot % 9 == 8;
            menu.setItem(slot, border ? GuiItems.darkFiller() : GuiItems.filler());
        }
        return menu;
    }

    private int clampPage(int page, int totalItems) {
        int totalPages = totalItems <= 0 ? 1 : (totalItems + PAGE_SIZE - 1) / PAGE_SIZE;
        if (page >= totalPages) {
            return totalPages - 1;
        }
        return Math.max(0, page);
    }

    private boolean canView(Player player) {
        return player.hasPermission("optimizer.view") || player.hasPermission("optimizer.admin");
    }

    private boolean isAdmin(Player player) {
        return player.hasPermission("optimizer.admin");
    }

    private ChunkKey currentChunkKey(Player player) {
        Location location = player.getLocation();
        if (location.getWorld() == null) {
            return null;
        }
        return new ChunkKey(location.getWorld().getName(), location.getBlockX() >> 4, location.getBlockZ() >> 4);
    }

    private String fallback(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value.trim();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Inventory top = event.getView().getTopInventory();
        if (top == null || !(top.getHolder() instanceof OptimizerInventoryHolder)) {
            return;
        }
        event.setCancelled(true);
        if (event.getRawSlot() < 0 || event.getRawSlot() >= top.getSize()) {
            return;
        }
        OptimizerInventoryHolder holder = (OptimizerInventoryHolder) top.getHolder();
        holder.getMenu().handleClick((Player) event.getWhoClicked(), event.getRawSlot(), event.getClick());
    }

    @EventHandler
    public void onInventoryDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (top != null && top.getHolder() instanceof OptimizerInventoryHolder) {
            event.setCancelled(true);
        }
    }
}
