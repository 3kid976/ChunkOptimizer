package dev.alexroper.chunkoptimizer.bukkit.gui;

import org.bukkit.Sound;
import org.bukkit.entity.Player;

public final class SoundUtil {
    private SoundUtil() {
    }

    public static void click(Player player) {
        play(player, "UI_BUTTON_CLICK", "CLICK", 0.7f, 1.2f);
    }

    public static void success(Player player) {
        play(player, "ENTITY_EXPERIENCE_ORB_PICKUP", "ORB_PICKUP", 0.8f, 1.3f);
    }

    public static void fail(Player player) {
        play(player, "BLOCK_NOTE_BLOCK_BASS", "NOTE_BASS", 0.7f, 0.7f);
    }

    private static void play(Player player, String modern, String legacy, float volume, float pitch) {
        if (player == null) {
            return;
        }
        Sound sound = resolve(modern);
        if (sound == null) {
            sound = resolve(legacy);
        }
        if (sound != null) {
            player.playSound(player.getLocation(), sound, volume, pitch);
        }
    }

    private static Sound resolve(String name) {
        try {
            return Sound.valueOf(name);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
